extends Node
## Persistent startup controller. It keeps a readable fallback UI above the game
## until the actual main scene confirms that its menu and graphics are initialized.
## This prevents a startup script error from appearing as a blank blue screen.

const GAME_SCENE := "res://scenes/game.tscn"
const START_TIMEOUT := 25.0

var _canvas: CanvasLayer
var _status_label: Label
var _detail_label: Label
var _progress_bar: ProgressBar
var _retry_button: Button
var _elapsed := 0.0
var _loading_resource := false
var _waiting_for_game := false
var _failed := false
var _game: Node


func _ready() -> void:
	_build_screen()
	_begin_loading()


func _build_screen() -> void:
	_canvas = CanvasLayer.new()
	_canvas.layer = 100
	add_child(_canvas)
	var bg := ColorRect.new()
	bg.color = Color("#111827")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_canvas.add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_canvas.add_child(center)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(320, 0)
	box.add_theme_constant_override("separation", 16)
	center.add_child(box)
	var title := Label.new()
	title.text = "VOXEL SANDBOX"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color("#facc15"))
	box.add_child(title)
	_status_label = Label.new()
	_status_label.text = "Запуск игры..."
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(_status_label)
	_progress_bar = ProgressBar.new()
	_progress_bar.custom_minimum_size = Vector2(300, 18)
	_progress_bar.max_value = 100.0
	box.add_child(_progress_bar)
	_detail_label = Label.new()
	_detail_label.text = "Подготовка главного меню"
	_detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_detail_label.add_theme_color_override("font_color", Color("#cbd5e1"))
	box.add_child(_detail_label)
	_retry_button = Button.new()
	_retry_button.text = "Повторить запуск"
	_retry_button.visible = false
	_retry_button.pressed.connect(_retry_loading)
	box.add_child(_retry_button)


func _begin_loading() -> void:
	_elapsed = 0.0
	_failed = false
	_loading_resource = true
	_waiting_for_game = false
	_retry_button.visible = false
	_progress_bar.visible = true
	_progress_bar.value = 0.0
	_status_label.text = "Загрузка игры..."
	_detail_label.text = "Подготавливаем главное меню. Экран останется здесь, если произойдёт ошибка."
	var err := ResourceLoader.load_threaded_request(GAME_SCENE, "PackedScene", true)
	if err != OK:
		_show_failure("Не удалось начать загрузку игровой сцены.", "Код ResourceLoader: %d" % err)


func _process(delta: float) -> void:
	if _failed:
		return
	_elapsed += delta
	if _loading_resource:
		var progress: Array = []
		var status := ResourceLoader.load_threaded_get_status(GAME_SCENE, progress)
		if not progress.is_empty():
			_progress_bar.value = clampf(float(progress[0]) * 100.0, 0.0, 100.0)
		match status:
			ResourceLoader.THREAD_LOAD_LOADED:
				_loading_resource = false
				_start_game_instance()
			ResourceLoader.THREAD_LOAD_FAILED:
				_show_failure("Godot не смог загрузить игровую сцену.", "Проверьте scenes/game.tscn и scripts/main.gd.")
			ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
				_show_failure("Игровая сцена не найдена.", "Ожидался файл: " + GAME_SCENE)
			_:
				if _elapsed > START_TIMEOUT:
					_show_failure("Загрузка игровой сцены заняла слишком много времени.", "Проверьте APK и журнал ошибок Godot.")
	elif _waiting_for_game and _elapsed > START_TIMEOUT:
		_show_failure("Главное меню не завершило запуск.", _read_startup_log())


func _start_game_instance() -> void:
	var packed := ResourceLoader.load_threaded_get(GAME_SCENE) as PackedScene
	if packed == null:
		_show_failure("Игровая сцена загрузилась неправильно.", "Файл не является PackedScene: " + GAME_SCENE)
		return
	var instance := packed.instantiate()
	if instance == null:
		_show_failure("Не удалось создать игровую сцену.", "Godot вернул пустой экземпляр scenes/game.tscn.")
		return
	if not instance.has_signal("startup_completed"):
		_show_failure("В игровой сцене нет подтверждения запуска.", "Проверь scripts/main.gd: ожидается signal startup_completed.")
		instance.queue_free()
		return
	instance.connect("startup_completed", _on_game_started, CONNECT_ONE_SHOT)
	_game = instance
	_waiting_for_game = true
	_elapsed = 0.0
	_status_label.text = "Подготовка главного меню..."
	_detail_label.text = "Инициализация интерфейса и графики"
	_progress_bar.value = 70.0
	add_child(instance)


func _on_game_started() -> void:
	_waiting_for_game = false
	_loading_resource = false
	_status_label.text = "Готово"
	_progress_bar.value = 100.0
	# Removing the CanvasLayer frees all its controls and reveals the main menu.
	_canvas.queue_free()
	_canvas = null


func _show_failure(message: String, details: String) -> void:
	_failed = true
	_loading_resource = false
	_waiting_for_game = false
	_status_label.text = message
	_status_label.add_theme_color_override("font_color", Color("#fca5a5"))
	_detail_label.text = details
	_progress_bar.visible = false
	_retry_button.visible = true
	push_error("Voxel Sandbox startup: %s | %s" % [message, details])


func _read_startup_log() -> String:
	var path := "user://logs/chunkgen.log"
	if not FileAccess.file_exists(path):
		return "Журнал запуска ещё не создан. Пришлите фото этого экрана и укажите модель телефона."
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return "Не удалось прочитать user://logs/chunkgen.log. Пришлите фото этого экрана."
	var lines := f.get_as_text().split("\n", false)
	f.close()
	var first := maxi(0, lines.size() - 8)
	var tail := "\n".join(lines.slice(first))
	return "Последние записи журнала:\n" + tail if not tail.is_empty() else "Журнал пока пуст. Пришлите фото этого экрана."


func _retry_loading() -> void:
	if is_instance_valid(_game):
		_game.queue_free()
	_game = null
	_loading_resource = false
	_waiting_for_game = false
	_begin_loading()
