class_name Chunk
extends RefCounted
## Runtime state of one 16x64x16 column of blocks.

var pos: Vector2i
var serial := 0        # unique id; jobs carry this int instead of the object
var gen_retries := 0
var t_queued := 0
var blocks := PackedByteArray()
var has_data := false
var gen_pending := false
var mesh_pending := false
var meshed := false
var dirty := false
var inst: MeshInstance3D
var winst: MeshInstance3D


func _init(p: Vector2i) -> void:
	pos = p


func free_nodes() -> void:
	if inst != null and is_instance_valid(inst):
		inst.queue_free()
	if winst != null and is_instance_valid(winst):
		winst.queue_free()
	inst = null
	winst = null
