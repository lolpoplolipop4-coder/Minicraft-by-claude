class_name Mob
extends Node3D
## Simple night-time enemy built from boxes. Chases the player, hops over single
## blocks, burns in daylight. Uses the same voxel collision as the player.

signal died(mob)

const HW := 0.3
const H := 1.8

var world: World
var player: Player
var main: Node
var vel := Vector3.ZERO
var hp := 20.0
var atk_cd := 0.5
var flash := 0.0
var anim := 0.0
var wander_dir := Vector3.ZERO
var wander_t := 0.0
var _dead := false
var _flashing := false
var _mats: Array[StandardMaterial3D] = []
var _legs: Array[Node3D] = []


func _init() -> void:
	_build()


func setup(w: World, p: Player, m: Node) -> void:
	world = w
	player = p
	main = m


func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 1.0
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	_mats.append(mat)


func _build() -> void:
	var skin := Color(0.36, 0.55, 0.30)
	var shirt := Color(0.18, 0.33, 0.62)
	var pants := Color(0.20, 0.20, 0.45)
	_box(self, Vector3(0.5, 0.75, 0.28), Vector3(0, 1.0, 0), shirt)
	_box(self, Vector3(0.5, 0.5, 0.5), Vector3(0, 1.62, 0), skin)
	_box(self, Vector3(0.1, 0.08, 0.02), Vector3(-0.13, 1.66, -0.255), Color(0.05, 0.05, 0.05))
	_box(self, Vector3(0.1, 0.08, 0.02), Vector3(0.13, 1.66, -0.255), Color(0.05, 0.05, 0.05))
	for s in [-1.0, 1.0]:
		var sf: float = s
		var leg := Node3D.new()
		leg.position = Vector3(0.13 * sf, 0.62, 0)
		add_child(leg)
		_box(leg, Vector3(0.24, 0.62, 0.26), Vector3(0, -0.31, 0), pants)
		_legs.append(leg)
		var arm := Node3D.new()
		arm.position = Vector3(0.37 * sf, 1.33, 0)
		arm.rotation.x = PI / 2.0 # arms stretched forward (-Z)
		add_child(arm)
		_box(arm, Vector3(0.22, 0.7, 0.22), Vector3(0, -0.3, 0), skin)


func _process(delta: float) -> void:
	if _dead or world == null or main == null or not is_instance_valid(player) or main.paused:
		return
	var dt := minf(delta, 1.0 / 30.0)

	var to_p := player.position - position
	var flat := Vector3(to_p.x, 0, to_p.z)
	var dist := flat.length()
	var dir := Vector3.ZERO
	var speed := 0.0
	if player.alive and dist < 26.0:
		dir = flat / maxf(dist, 0.01)
		speed = 2.6 if dist > 0.9 else 0.0
	else:
		wander_t -= dt
		if wander_t <= 0.0:
			wander_t = randf_range(2.0, 5.0)
			wander_dir = Vector3.ZERO
			if randf() > 0.4:
				wander_dir = Vector3.FORWARD.rotated(Vector3.UP, randf() * TAU)
		dir = wander_dir
		speed = 1.0

	var tv := dir * speed
	vel.x = move_toward(vel.x, tv.x, 25.0 * dt)
	vel.z = move_toward(vel.z, tv.z, 25.0 * dt)
	vel.y = maxf(vel.y - 28.0 * dt, -24.0)
	if world.get_block(floori(position.x), floori(position.y + 0.3), floori(position.z)) == Blocks.WATER:
		vel.y = move_toward(vel.y, 2.0, 30.0 * dt)

	var r := world.move_box(position, vel, HW, H, dt)
	position = r["pos"]
	vel = r["vel"]
	if r["walled"] and r["grounded"] and speed > 0.0:
		vel.y = 8.0

	if dir.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, 10.0 * dt))
	anim += Vector2(vel.x, vel.z).length() * dt * 3.0
	var swing := sin(anim) * 0.8
	_legs[0].rotation.x = swing
	_legs[1].rotation.x = -swing

	atk_cd -= dt
	var d3 := (player.position + Vector3(0, 0.9, 0)) - (position + Vector3(0, 0.9, 0))
	if player.alive and d3.length() < 1.15 and atk_cd <= 0.0:
		atk_cd = 1.0
		player.damage(3.0, position)

	if main.daylight > 0.75:
		hp -= 2.5 * dt
		flash = 0.2
		_set_flash(true)
		if hp <= 0.0:
			_die()
			return
	elif flash > 0.0:
		flash -= dt
		if flash <= 0.0:
			_set_flash(false)


func hurt(dmg: float, dir: Vector3) -> void:
	hp -= dmg
	vel.x += dir.x * 7.0
	vel.z += dir.z * 7.0
	vel.y = 5.0
	flash = 0.15
	_set_flash(true)
	if hp <= 0.0:
		_die()


func _set_flash(on: bool) -> void:
	if on == _flashing:
		return
	_flashing = on
	for m in _mats:
		m.emission_enabled = on
		m.emission = Color(0.9, 0.1, 0.1)


func _die() -> void:
	if _dead:
		return
	_dead = true
	main.burst(position + Vector3(0, 1.0, 0), Color(0.40, 0.60, 0.30), 18, 4.0)
	died.emit(self)
	queue_free()
