class_name SaveSystem
extends RefCounted
## Atomic file save/load for any path (tmp file + rename, so a crash mid-save never
## corrupts the previous save). The default PATH is the legacy single-world file.

const PATH := "user://world.dat"


static func exists(path: String = PATH) -> bool:
	return FileAccess.file_exists(path)


static func save_game(data: Dictionary, path: String = PATH) -> bool:
	var tmp := path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_warning("Could not open save file: %s" % error_string(FileAccess.get_open_error()))
		return false
	f.store_var(data)
	f.close()
	var dir := DirAccess.open(path.get_base_dir())
	if dir == null:
		return false
	var fname := path.get_file()
	# Try to replace in one step first; only delete the old file if the platform refuses.
	if dir.rename(fname + ".tmp", fname) == OK:
		return true
	if dir.file_exists(fname):
		dir.remove(fname)
	return dir.rename(fname + ".tmp", fname) == OK


static func load_game(path: String = PATH) -> Dictionary:
	if not exists(path):
		return {}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	if f.get_length() < 4:
		f.close()
		return {}
	var v: Variant = f.get_var()
	f.close()
	if v is Dictionary:
		return v
	return {}


static func delete_save(path: String = PATH) -> void:
	var dir := DirAccess.open(path.get_base_dir())
	if dir != null and dir.file_exists(path.get_file()):
		dir.remove(path.get_file())
