class_name WorldStore
extends RefCounted
## Multiple worlds. Each world = user://worlds/<id>.meta (small: name, seed, type, mode,
## dates, used by the list) + <id>.dat (full save). Copies are plain file copies, so they
## are fully independent. The legacy single-world save user://world.dat is imported ONCE
## as the world "legacy" (the original file is never modified or deleted).

const ROOT := "user://worlds"
const LEGACY_FLAG := "user://worlds/legacy_migrated.flag"
const SEED_LIMIT := 2000000000
const MAX_NAME := 32

const TYPE_NAMES := ["Обычный", "Плоский", "Горный", "Суперплоский (творческий)"]
const TYPE_DESC := [
	"Холмы, горы, реки и океаны, пещеры, руды и леса.",
	"Ровная местность с деревьями и рудами под землёй - удобно строить и выживать.",
	"Высокие хребты, глубокие долины с озёрами и крутые склоны.",
	"Бесконечная ровная площадка без деревьев, руд и пещер. Только творческий режим.",
]
const MODE_NAMES := ["Выживание", "Творческий"]
const MODE_DESC := [
	"Пустой инвентарь, голод и урон, ресурсы тратятся.",
	"Неограниченные блоки из каталога, полёт, мгновенное разрушение, без голода и урона.",
]


# ------------------------------------------------------------------ pure helpers

## Parses the seed text field. Returns {ok, random, value} or {ok:false, error}.
static func parse_seed(text: String) -> Dictionary:
	var t := text.strip_edges()
	if t.is_empty():
		return {"ok": true, "random": true, "value": 0}
	var neg := t.begins_with("-")
	var digits := t
	if neg or t.begins_with("+"):
		digits = t.substr(1)
	if digits.is_empty() or digits.length() > 10:
		return {"ok": false, "error": "Сид: целое число от -2000000000 до 2000000000"}
	for i in digits.length():
		var c := digits.unicode_at(i)
		if c < 48 or c > 57:
			return {"ok": false, "error": "Сид должен быть целым числом (например 12345 или -987)"}
	var v := int(digits)
	if neg:
		v = -v
	if absi(v) > SEED_LIMIT:
		return {"ok": false, "error": "Сид слишком велик: допустимо от -2000000000 до 2000000000"}
	return {"ok": true, "random": false, "value": v}


static func random_seed() -> int:
	return randi_range(1, 999999999)


static func sanitize_name(text: String) -> String:
	var out := ""
	for i in text.length():
		var c := text.unicode_at(i)
		if c >= 32 and c != 127:
			out += text[i]
	out = out.strip_edges()
	if out.length() > MAX_NAME:
		out = out.substr(0, MAX_NAME)
	if out.is_empty():
		out = "Новый мир"
	return out


static func valid_id(id: String) -> bool:
	if id.is_empty() or id.length() > 64:
		return false
	for i in id.length():
		var c := id.unicode_at(i)
		var ok := (c >= 48 and c <= 57) or (c >= 65 and c <= 90) or (c >= 97 and c <= 122) or c == 95
		if not ok:
			return false
	return true


static func format_time(unix: int) -> String:
	if unix <= 0:
		return "-"
	var bias := int(Time.get_time_zone_from_system().get("bias", 0))
	return Time.get_datetime_string_from_unix_time(unix + bias * 60, true).substr(0, 16)


static func dat_path(id: String) -> String:
	return "%s/%s.dat" % [ROOT, id]


static func meta_path(id: String) -> String:
	return "%s/%s.meta" % [ROOT, id]


static func _new_id() -> String:
	return "w%d_%04d" % [int(Time.get_unix_time_from_system()), randi() % 10000]


static func ensure_dir() -> void:
	DirAccess.make_dir_recursive_absolute(ROOT)


# ------------------------------------------------------------------ storage

static func read_meta(id: String) -> Dictionary:
	if not valid_id(id):
		return {}
	var d := SaveSystem.load_game(meta_path(id))
	if d.is_empty() or not d.has("seed"):
		return {}
	var now := int(Time.get_unix_time_from_system())
	return {
		"id": id,
		"name": sanitize_name(str(d.get("name", "Мир"))),
		"seed": clampi(int(d.get("seed", 0)), -SEED_LIMIT, SEED_LIMIT),
		"type": clampi(int(d.get("type", 0)), 0, TYPE_NAMES.size() - 1),
		"mode": clampi(int(d.get("mode", 0)), 0, MODE_NAMES.size() - 1),
		"created": int(d.get("created", now)),
		"modified": int(d.get("modified", now)),
	}


static func write_meta(meta: Dictionary) -> bool:
	var id: String = meta.get("id", "")
	if not valid_id(id):
		return false
	var d := {"name": meta["name"], "seed": meta["seed"], "type": meta["type"], "mode": meta["mode"],
		"created": meta["created"], "modified": meta["modified"]}
	return SaveSystem.save_game(d, meta_path(id))


## All worlds, newest first.
static func list() -> Array:
	ensure_dir()
	migrate_legacy()
	var out: Array = []
	var dir := DirAccess.open(ROOT)
	if dir == null:
		return out
	for f in dir.get_files():
		if f.ends_with(".meta"):
			var m := read_meta(f.get_basename())
			if not m.is_empty():
				out.append(m)
	out.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return int(a["modified"]) > int(b["modified"]))
	return out


## Creates the world record (terrain is generated on first play). Returns the id or "".
static func create(name: String, sd: int, type: int, mode: int) -> String:
	ensure_dir()
	var now := int(Time.get_unix_time_from_system())
	var id := _new_id()
	if type == 3:
		mode = 1 # the superflat platform is a creative-only world type
	var meta := {"id": id, "name": sanitize_name(name), "seed": clampi(sd, -SEED_LIMIT, SEED_LIMIT),
		"type": clampi(type, 0, TYPE_NAMES.size() - 1), "mode": clampi(mode, 0, 1), "created": now, "modified": now}
	return id if write_meta(meta) else ""


static func touch(id: String) -> void:
	var m := read_meta(id)
	if m.is_empty():
		return
	m["modified"] = int(Time.get_unix_time_from_system())
	write_meta(m)


static func rename(id: String, new_name: String) -> bool:
	var m := read_meta(id)
	if m.is_empty():
		return false
	m["name"] = sanitize_name(new_name)
	return write_meta(m)


## Independent copy (new id, files copied). Returns the new id or "".
static func copy(id: String) -> String:
	var m := read_meta(id)
	if m.is_empty():
		return ""
	var nid := _new_id()
	if nid == id:
		nid += "c"
	var src := dat_path(id)
	if FileAccess.file_exists(src):
		if DirAccess.copy_absolute(src, dat_path(nid)) != OK:
			return ""
	var now := int(Time.get_unix_time_from_system())
	m["id"] = nid
	m["name"] = sanitize_name(str(m["name"]).substr(0, MAX_NAME - 9) + " (копия)")
	m["created"] = now
	m["modified"] = now
	if not write_meta(m):
		DirAccess.remove_absolute(dat_path(nid))
		return ""
	return nid


static func delete(id: String) -> void:
	if not valid_id(id):
		return
	for p in [dat_path(id), dat_path(id) + ".tmp", meta_path(id), meta_path(id) + ".tmp"]:
		if FileAccess.file_exists(p):
			DirAccess.remove_absolute(p)


## One-time import of the old single-world save. The original file stays untouched.
static func migrate_legacy() -> void:
	if FileAccess.file_exists(LEGACY_FLAG) or not FileAccess.file_exists(SaveSystem.PATH):
		return
	ensure_dir()
	var data := SaveSystem.load_game(SaveSystem.PATH)
	var ok := data.has("seed") and (data["seed"] is int or data["seed"] is float)
	if DirAccess.copy_absolute(SaveSystem.PATH, dat_path("legacy")) != OK:
		return # try again next launch; nothing was changed
	var now := int(Time.get_unix_time_from_system())
	var meta := {"id": "legacy", "name": "Старый мир" if ok else "Старый мир (файл не читается)",
		"seed": clampi(int(data.get("seed", 0)), -SEED_LIMIT, SEED_LIMIT) if ok else 0,
		"type": 0, "mode": 0, "created": now,
		"modified": maxi(int(FileAccess.get_modified_time(SaveSystem.PATH)), 1)}
	if write_meta(meta):
		var f := FileAccess.open(LEGACY_FLAG, FileAccess.WRITE)
		if f != null:
			f.store_string("1")
			f.close()
