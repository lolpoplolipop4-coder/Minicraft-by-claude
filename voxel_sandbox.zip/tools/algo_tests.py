#!/usr/bin/env python3
"""Line-by-line Python ports of the trickiest GDScript algorithms (chunk-border
neighbour indexing, voxel DDA raycast, AABB-vs-voxel collision), tested against
brute-force references. Validates the LOGIC; syntax is validated by Godot itself."""
import math, random

CS, CH = 16, 64
def idx(x, y, z): return (y * CS + z) * CS + x

# ---------------------------------------------------------------- neighbour indexing (mesher.gd)
def neighbours(blocks, nx, px, nz, pz, x, y, z):
    i = idx(x, y, z)
    n0 = blocks[i + 1] if x < CS - 1 else px[i - 15]
    n1 = blocks[i - 1] if x > 0 else nx[i + 15]
    n2 = blocks[i + 256] if y < CH - 1 else 0
    n3 = blocks[i - 256] if y > 0 else 1
    n4 = blocks[i + 16] if z < CS - 1 else pz[i - 240]
    n5 = blocks[i - 16] if z > 0 else nz[i + 240]
    return n0, n1, n2, n3, n4, n5

def world_get(chunks, wx, y, wz):
    if y < 0: return 1
    if y >= CH: return 0
    return chunks[(wx >> 4, wz >> 4)][idx(wx & 15, y, wz & 15)]

def test_neighbours():
    random.seed(1)
    chunks = {(cx, cz): [random.choice([0, 1, 3]) for _ in range(CS * CH * CS)]
              for cx in range(-1, 2) for cz in range(-1, 2)}
    c = chunks[(0, 0)]
    nx, px, nz, pz = chunks[(-1, 0)], chunks[(1, 0)], chunks[(0, -1)], chunks[(0, 1)]
    for _ in range(20000):
        x, z, y = random.randrange(CS), random.randrange(CS), random.randrange(CH)
        got = neighbours(c, nx, px, nz, pz, x, y, z)
        want = (world_get(chunks, x + 1, y, z), world_get(chunks, x - 1, y, z),
                world_get(chunks, x, y + 1, z), world_get(chunks, x, y - 1, z),
                world_get(chunks, x, y, z + 1), world_get(chunks, x, y, z - 1))
        assert got == want, (x, y, z, got, want)
    # negative-coordinate chunk addressing: x >> 4 and x & 15 must floor, not truncate
    assert (-1 >> 4) == -1 and (-1 & 15) == 15 and (-16 >> 4) == -1 and (-17 >> 4) == -2
    print("OK  mesher border-neighbour indexing (20000 random cells, incl. chunk borders)")

# ---------------------------------------------------------------- raycast (world.gd)
def raycast(solid, o, d, max_dist):
    x, y, z = (math.floor(v) for v in o)
    sx = 1 if d[0] > 0 else -1; sy = 1 if d[1] > 0 else -1; sz = 1 if d[2] > 0 else -1
    inf = float("inf")
    dx = abs(1 / d[0]) if d[0] else inf; dy = abs(1 / d[1]) if d[1] else inf; dz = abs(1 / d[2]) if d[2] else inf
    tx = (x + 1 - o[0]) / d[0] if d[0] > 0 else ((o[0] - x) / -d[0] if d[0] < 0 else inf)
    ty = (y + 1 - o[1]) / d[1] if d[1] > 0 else ((o[1] - y) / -d[1] if d[1] < 0 else inf)
    tz = (z + 1 - o[2]) / d[2] if d[2] > 0 else ((o[2] - z) / -d[2] if d[2] < 0 else inf)
    normal = (0, 0, 0); t = 0.0
    while t <= max_dist:
        if solid(x, y, z): return (x, y, z), normal
        if tx < ty and tx < tz: x += sx; t = tx; tx += dx; normal = (-sx, 0, 0)
        elif ty < tz: y += sy; t = ty; ty += dy; normal = (0, -sy, 0)
        else: z += sz; t = tz; tz += dz; normal = (0, 0, -sz)
    return None

def brute_ray(solid, o, d, max_dist, step=0.002):
    t = 0.0; last = tuple(math.floor(v) for v in o)
    while t <= max_dist:
        p = tuple(o[i] + d[i] * t for i in range(3))
        cell = tuple(math.floor(v) for v in p)
        if solid(*cell): return cell
        t += step
    return None

def test_raycast():
    random.seed(2)
    cells = {(random.randrange(-8, 8), random.randrange(-8, 8), random.randrange(-8, 8)) for _ in range(250)}
    solid = lambda x, y, z: (x, y, z) in cells
    bad = 0
    for _ in range(3000):
        o = tuple(random.uniform(-6, 6) for _ in range(3))
        if solid(*[math.floor(v) for v in o]): continue
        d = [random.uniform(-1, 1) for _ in range(3)]
        n = math.sqrt(sum(v * v for v in d)); d = tuple(v / n for v in d)
        a = raycast(solid, o, d, 5.0); b = brute_ray(solid, o, d, 5.0)
        if (a[0] if a else None) != b: bad += 1
        if a:  # the reported face normal must point back toward the ray origin
            p, nrm = a
            assert sum(nrm[i] * d[i] for i in range(3)) < 1e-9, "normal faces away from the viewer"
            assert abs(sum(abs(v) for v in nrm)) == 1 or p == tuple(math.floor(v) for v in o)
    assert bad <= 6, f"{bad} DDA mismatches vs brute force"
    print(f"OK  voxel DDA raycast vs brute force ({bad} sub-step tolerance mismatches of ~3000)")

# ---------------------------------------------------------------- collision (world.gd)
def axis_limit(solid, p, hw, h, axis, d):
    fl = math.floor
    x0, x1 = fl(p[0] - hw), fl(p[0] + hw - 0.0001)
    y0, y1 = fl(p[1]), fl(p[1] + h - 0.0001)
    z0, z1 = fl(p[2] - hw), fl(p[2] + hw - 0.0001)
    best = None
    for bx in range(x0, x1 + 1):
        for by in range(y0, y1 + 1):
            for bz in range(z0, z1 + 1):
                if not solid(bx, by, bz): continue
                if axis == 0: v = (bx - hw - 0.001) if d > 0 else (bx + 1 + hw + 0.001)
                elif axis == 1: v = (by - h - 0.001) if d > 0 else (by + 1.001)
                else: v = (bz - hw - 0.001) if d > 0 else (bz + 1 + hw + 0.001)
                best = v if best is None else (min(best, v) if d > 0 else max(best, v))
    return best

def move_box(solid, pos, vel, hw, h, dt):
    p, v = list(pos), list(vel); grounded = walled = False
    for axis, k in ((0, 0), (2, 2), (1, 1)):
        if v[k] != 0:
            p[k] += v[k] * dt
            l = axis_limit(solid, p, hw, h, axis, v[k])
            if l is not None:
                if axis == 1 and v[k] < 0: grounded = True
                if axis != 1: walled = True
                p[k] = l; v[k] = 0
    return p, v, grounded, walled

def test_collision():
    # flat ground at y<20 (top face at y=20), wall at x>=10
    solid = lambda x, y, z: y < 20 or x >= 10
    HW, H = 0.3, 1.78
    # 1) fall from 40 m with max fall speed at 60 Hz: must land on the floor, never tunnel
    p, v = [0.5, 40.0, 0.5], [0.0, 0.0, 0.0]
    for _ in range(600):
        v[1] = max(v[1] - 30 / 60, -45)
        p, v, g, w = move_box(solid, p, v, HW, H, 1 / 60)
        if g: break
    assert g and 20.0 <= p[1] < 20.01, p
    # 2) at terminal speed, never skip a 1-thick slab
    slab = lambda x, y, z: y == 10
    p, v = [0.5, 30.0, 0.5], [0, -45.0, 0]
    for _ in range(400):
        p, v, g, w = move_box(slab, p, v, HW, H, 1 / 60)
        if g: break
    assert g and p[1] >= 11.0 - 1e-6, p
    # 3) walk into the wall at 6 m/s: stop with the AABB just outside x=10, flagged as walled
    p, v = [8.0, 20.0, 0.5], [6.0, 0, 0]
    for _ in range(120):
        v[1] = -0.5
        p, v, g, w = move_box(solid, p, [6.0, v[1], 0.0], HW, H, 1 / 60)
    assert abs(p[0] - (10 - HW - 0.001)) < 1e-6 and w, p
    # 4) standing still on the floor is stable (no jitter / sinking)
    p = [0.5, 20.001, 0.5]
    for _ in range(300):
        p, v, g, w = move_box(solid, p, [0, -0.5, 0], HW, H, 1 / 60)
        assert g and 20.0 <= p[1] < 20.0011, p
    # 5) head-bump: jumping under a ceiling stops the rise
    ceil = lambda x, y, z: y < 20 or y == 22
    p, v = [0.5, 20.001, 0.5], [0, 8.6, 0]
    for _ in range(60):
        v[1] -= 30 / 60
        p, v, g, w = move_box(ceil, p, v, HW, H, 1 / 60)
    assert p[1] + H <= 22.0 + 1e-6, p
    print("OK  AABB-vs-voxel collision (landing, no tunnelling at terminal speed, walls, resting, ceiling)")

if __name__ == "__main__":
    test_neighbours(); test_raycast(); test_collision()
    print("All algorithm tests passed.")


# ---------------------------------------------------------------- tree/chunk-border consistency (terrain_gen.gd)
def tree_blocks(ox, oz, size, hfun, hashfun):
    """Port of the tree pass: returns {(x,y,z): block} for the region [ox,ox+size) x [oz,oz+size)."""
    AIR, WOOD, LEAVES = 0, 5, 6
    out = {}
    def put(x, y, z, b, only_air):
        if ox <= x < ox + size and oz <= z < oz + size and 0 <= y < CH:
            if only_air and (x, y, z) in out: return
            out[(x, y, z)] = b
    # trunks first for every candidate (matches placing trunk unconditionally, leaves only into air)
    cands = []
    for tz in range(oz - 2, oz + size + 2):
        for tx in range(ox - 2, ox + size + 2):
            r = hashfun(tx, tz); f = r % 1000
            if f >= 45 or f >= 6 + (29 if (tx * 7 + tz) % 5 == 0 else 0): continue
            h = hfun(tx, tz)
            cands.append((tx, tz, h, 4 + (r // 1000) % 3))
    return cands

def test_tree_borders():
    # Each tree is a pure function of (tx,tz); a chunk only *selects* the blocks inside it.
    # Verify: the set of candidate roots evaluated by two adjacent chunks agrees on the overlap.
    hfun = lambda x, z: 24 + ((x * 31 + z * 17) % 7)
    def hashfun(x, z):
        h = (x * 374761393 + 9157 * 668265263 + z * 1274126177 + 12345 * 2147483629) & 0xFFFFFFFFFFFFFFFF
        h = ((h ^ (h >> 13)) * 1103515245) & 0xFFFFFFFFFFFFFFFF
        h ^= h >> 16
        return h & 0x7fffffff
    a = {(tx, tz): (h, th) for tx, tz, h, th in tree_blocks(0, 0, 16, hfun, hashfun)}
    b = {(tx, tz): (h, th) for tx, tz, h, th in tree_blocks(16, 0, 16, hfun, hashfun)}
    whole = {(tx, tz): (h, th) for tx, tz, h, th in tree_blocks(0, 0, 32, hfun, hashfun)}
    for k, v in whole.items():
        inz = -2 <= k[1] < 18
        if -2 <= k[0] < 18 and inz:       # roots chunk A evaluates
            assert k in a and a[k] == v, ("A", k)
        if 14 <= k[0] < 34 and inz:       # roots chunk B evaluates
            assert k in b and b[k] == v, ("B", k)
    # the overlap strip (x in 14..17) must be seen identically by both chunks
    for k in a:
        if 14 <= k[0] < 18: assert b.get(k) == a[k], ("overlap", k)
    assert len(a) > 0 and len(b) > 0
    # leaf footprint radius is 2, candidate window is chunk +-2, so every canopy block inside a chunk is covered
    print(f"OK  tree candidates agree across the chunk border ({len(a)} + {len(b)} roots checked)")

if __name__ == "__main__":
    test_tree_borders()
    print("Border tests passed.")
