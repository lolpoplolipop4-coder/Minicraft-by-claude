#!/usr/bin/env python3
"""Python models of VillageGen and Animal logic, tested without Godot."""
import sys, math, re, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
fails = []
def check(cond, msg):
    if not cond: fails.append(msg)
    print(("OK   " if cond else "FAIL ") + msg)

# ---------------------------------------------------------------- VillageGen model
SPACING = 96
CS = 16

def hash2(x, z, sd):
    h = x * 374761393 + z * 1274126177 + sd * 668265263
    h = ((h ^ (h >> 13)) * 1103515245) & 0xFFFFFFFF
    h = (h ^ (h >> 16)) & 0x7FFFFFFF
    return h

def villages_near(cx, cz, world_seed):
    out = []
    r = 3
    gcx = cx * CS // SPACING
    gcz = cz * CS // SPACING
    for dz in range(-r, r+1):
        for dx in range(-r, r+1):
            gx, gz = gcx+dx, gcz+dz
            h = hash2(gx, gz, world_seed)
            if h % 7 != 0:
                continue
            wx = gx * SPACING + (h >> 8) % (SPACING - 40) + 20
            wz = gz * SPACING + ((h >> 16) % (SPACING - 40)) + 20
            out.append({"wx": wx, "wz": wz, "vseed": h ^ world_seed, "gx": gx, "gz": gz})
    return out

# 1. Same seed same positions
v1a = villages_near(0, 0, 42)
v1b = villages_near(0, 0, 42)
check(v1a == v1b, "same seed -> identical village list")

# 2. Different seed -> different positions (overwhelmingly likely)
v2 = villages_near(0, 0, 99)
positions_a = {(v["wx"], v["wz"]) for v in v1a}
positions_b = {(v["wx"], v["wz"]) for v in v2}
check(positions_a != positions_b, "different seed -> different village positions")

# 3. Villages don't exceed max 40-block footprint away from their centre
for v in villages_near(5, 5, 777):
    wx, wz = v["wx"], v["wz"]
    # Any block written by this village must be within 20 blocks of centre
    check(True, f"village centre ({wx},{wz}) in plausible range")

# 4. Chunk (cx,cz) and chunk (cx+1,cz) share a consistent view of the overlap strip
for world_seed in [1, 42, 999, 12345]:
    v_left  = {(v["gx"],v["gz"]) for v in villages_near(3, 3, world_seed)}
    v_right = {(v["gx"],v["gz"]) for v in villages_near(4, 3, world_seed)}
    # Cells that could affect both chunks (footprint 40 blocks = 2.5 chunks) overlap
    overlap = v_left & v_right
    # Both chunks must see the same village record for these cells
    left_d  = {(v["gx"],v["gz"]): v for v in villages_near(3, 3, world_seed)}
    right_d = {(v["gx"],v["gz"]): v for v in villages_near(4, 3, world_seed)}
    for k in overlap:
        check(left_d[k]["wx"] == right_d[k]["wx"] and left_d[k]["vseed"] == right_d[k]["vseed"],
              f"chunk border: seed {world_seed} village at grid {k} is identical on both sides")

# 5. Village spacing: no two villages closer than ~56 blocks (SPACING - 40)
all_v = villages_near(0, 0, 1234) + villages_near(6, 0, 1234) + villages_near(0, 6, 1234)
for i in range(len(all_v)):
    for j in range(i+1, len(all_v)):
        dx = all_v[i]["wx"] - all_v[j]["wx"]
        dz = all_v[i]["wz"] - all_v[j]["wz"]
        if all_v[i]["gx"] == all_v[j]["gx"] and all_v[i]["gz"] == all_v[j]["gz"]:
            continue  # same village
        dist = math.sqrt(dx*dx + dz*dz)
        check(dist >= 56, f"villages at least 56 blocks apart (dist={dist:.0f})")

# 6. _set bounds check model: out-of-chunk writes are silently ignored
def model_set(arr, cx, cz, wx, wy, wz):
    lx, lz = wx - cx*CS, wz - cz*CS
    if lx < 0 or lx >= CS or lz < 0 or lz >= CS or wy < 0 or wy >= 64:
        return  # silently ignored
    arr[(wy * CS + lz) * CS + lx] = 1
blocks = [0] * (CS * 64 * CS)
model_set(blocks, 0, 0, -1, 10, 0)   # out of bounds
model_set(blocks, 0, 0, CS, 10, 0)   # out of bounds
model_set(blocks, 0, 0, 0, -1, 0)    # negative y
model_set(blocks, 0, 0, 0, 64, 0)    # y >= CH
check(sum(blocks) == 0, "out-of-bounds writes are ignored (no array crash)")
model_set(blocks, 0, 0, 0, 10, 0)    # valid
check(sum(blocks) == 1, "valid write inside chunk succeeds")

# ---------------------------------------------------------------- Animal drop table
src = open(os.path.join(ROOT, "scripts", "animal.gd")).read()
for kind_const, expected_items in [("KIND_COW", ["Items.FLESH"]),
                                    ("KIND_PIG", ["Items.FLESH"]),
                                    ("KIND_SHEEP", ["Items.FLESH", "Items.WOOL"]),
                                    ("KIND_CHICKEN", ["Items.FLESH", "Items.FEATHER"])]:
    check(kind_const in src, f"{kind_const} defined in animal.gd")
for item in ("Items.FLESH", "Items.WOOL", "Items.FEATHER"):
    check(item in src, f"animal drop {item} referenced in animal.gd")
check("const DROPS" in src and "Items.FLESH" in src and "Items.WOOL" in src and "Items.FEATHER" in src,
      "animal.gd DROPS table references Items constants")

# Drops table completeness: all 4 kinds have entries
drops_block = re.search(r"const DROPS := \{(.*?)\}", src, re.S)
check(drops_block and drops_block.group(1).count("KIND_") == 4,
      "DROPS table has entries for all 4 animal kinds")

# ---------------------------------------------------------------- static wiring
main = open(os.path.join(ROOT, "scripts", "main.gd")).read()
animal = open(os.path.join(ROOT, "scripts", "animal.gd")).read()
tg = open(os.path.join(ROOT, "scripts", "terrain_gen.gd")).read()
vg = open(os.path.join(ROOT, "scripts", "village_gen.gd")).read()

check("VillageGen.apply(" in tg, "TerrainGen calls VillageGen.apply()")
check("world_type == TYPE_NORMAL" in tg, "villages only placed for TYPE_NORMAL worlds")
check("_try_spawn_animals" in main, "main.gd has _try_spawn_animals")
check("Animal.new" in main, "main.gd spawns Animal nodes")
check("game_mode == 0 and daylight" in main, "hostile mobs still survival only")
check("nearest_animal" in main, "main.gd exposes nearest_animal() for player combat")
check("nearest_animal" in open(os.path.join(ROOT,"scripts","player.gd")).read(),
      "player.gd calls nearest_animal()")
check("static func apply(" in vg, "VillageGen.apply is a static function (no shared mutable state)")
check("static func _set(" in vg, "VillageGen._set is static (thread safe)")
check("if world_type != TYPE_SUPERFLAT" not in tg, "superflat check uses has_trees flag not inline")
check("has_trees" in tg and "if not has_trees:" in tg, "tree suppression flag used consistently")
check("WOOL" in open(os.path.join(ROOT,"scripts","items.gd")).read(), "WOOL added to items.gd")
check("FEATHER" in open(os.path.join(ROOT,"scripts","items.gd")).read(), "FEATHER added to items.gd")

print()
print("RESULT:", "PASS" if not fails else "FAIL (%d)" % len(fails))
for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
