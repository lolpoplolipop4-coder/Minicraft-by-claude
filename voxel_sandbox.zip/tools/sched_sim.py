#!/usr/bin/env python3
"""Discrete-time model of the chunk scheduler in scripts/world.gd (same state flags,
same conditions, same per-frame limits). It runs the UPLOADED logic ("old") and the
FIXED logic ("new") on identical random job durations / failures / player paths and
reports: duplicate mesh jobs, chunks never meshed, stale results, deadlocks.
This validates the state machine, not Godot itself."""
import random, itertools

def offsets(r):
    lim = r + 2; dl = r * r + 2 * r + 3
    o = [(dx, dz) for dz in range(-lim, lim + 1) for dx in range(-lim, lim + 1) if dx * dx + dz * dz <= dl]
    return sorted(o, key=lambda p: p[0] ** 2 + p[1] ** 2)

class Chunk:
    _s = itertools.count(1)
    def __init__(s):
        s.serial = next(Chunk._s); s.has_data = s.gen_pending = s.mesh_pending = s.meshed = s.dirty = False
        s.mesh_jobs = 0; s.retries = 0

def simulate(new, radius, seed, frames=1500, fail_rate=0.0, workers=2, path=True):
    rnd = random.Random(seed)
    chunks = {}; tasks = []; results = []; ready = []
    mesh_limit = radius * radius + 1; data_limit = radius * radius + 2 * radius + 3
    offs = offsets(radius); center = None
    dup = stale = started_mesh = 0; fb = 0
    def nb_ok(k): return all(chunks.get((k[0] + dx, k[1] + dz)) and chunks[(k[0] + dx, k[1] + dz)].has_data for dx, dz in ((1,0),(-1,0),(0,1),(0,-1)))
    for f in range(frames):
        pos = (min(f, 400) // 60, 0) if path else (0, 0)   # walks 1 chunk / 60 frames for 400 frames, then stands still
        # finished jobs -> results
        for t in tasks[:]:
            if t[0] <= f:
                tasks.remove(t)
                kind, k, ser = t[1], t[2], t[3]
                ok = not (kind == 'gen' and rnd.random() < fail_rate)
                results.append((kind, k, ser, ok))
        # collect
        res, results = results, []
        for kind, k, ser, ok in res:
            ch = chunks.get(k)
            if ch is None or ch.serial != ser:
                stale += 1; continue
            if kind == 'gen':
                ch.gen_pending = False
                if ok: ch.has_data = True
                elif new:
                    ch.retries += 1
                    if ch.retries >= 3: ch.has_data = True; fb += 1
            else:
                if not new: ch.mesh_pending = False       # OLD: cleared when computed
                ready.append((ch, ser))
        # center / unload
        if pos != center:
            center = pos
            for k in [k for k in chunks if (k[0]-center[0])**2 + (k[1]-center[1])**2 > data_limit + 8]:
                del chunks[k]
        # schedule
        def start_mesh(ch, k):
            nonlocal dup, started_mesh
            if ch.meshed and not ch.dirty: dup += 1           # re-meshing an already-meshed, clean chunk
            if ch.mesh_jobs > 0 and not ch.dirty and any(r[0] is ch for r in ready): dup += 1   # result still waiting to be applied
            ch.mesh_pending = True; ch.dirty = False; ch.mesh_jobs += 1; started_mesh += 1
            tasks.append((f + rnd.randint(3, 12), 'mesh', k, ch.serial))
        for dx, dz in offs:
            if len(tasks) >= workers: break
            k = (center[0] + dx, center[1] + dz); ch = chunks.get(k)
            if ch is None:
                ch = Chunk(); chunks[k] = ch; ch.gen_pending = True
                tasks.append((f + rnd.randint(3, 12), 'gen', k, ch.serial))
            elif new and not ch.has_data and not ch.gen_pending:
                ch.gen_pending = True; tasks.append((f + rnd.randint(3, 12), 'gen', k, ch.serial))
            elif ch.has_data and (not ch.meshed or ch.dirty) and not ch.mesh_pending and dx*dx + dz*dz <= mesh_limit and nb_ok(k):
                start_mesh(ch, k)
        # apply (old: 2/frame; new: up to 3/frame)
        for _ in range(3 if new else 2):
            if not ready: break
            ch, ser = ready.pop(0)
            if new: ch.mesh_pending = False
            if ch.serial == ser and any(c is ch for c in chunks.values()):
                ch.meshed = True
    want = [(center[0]+dx, center[1]+dz) for dx, dz in offs if dx*dx+dz*dz <= mesh_limit]
    missing = [k for k in want if not (chunks.get(k) and chunks[k].meshed)]
    return dict(dup=dup, mesh_jobs=started_mesh, stale=stale, missing=len(missing), want=len(want), fallback=fb)

if __name__ == "__main__":
    ok = True
    print(f"{'radius':>6} {'logic':>5} {'mesh_jobs':>9} {'duplicates':>10} {'stale':>5} {'missing':>7}/{'want':<4}")
    tot = {False: 0, True: 0}
    for r in (2, 3, 4, 5, 6, 8):
        for new in (False, True):
            agg = dict(dup=0, mesh_jobs=0, stale=0, missing=0, want=0)
            for seed in range(40):
                s = simulate(new, r, seed, frames=500 + r * r * 70, path=True, fail_rate=0.0)
                for k in agg: agg[k] += s[k]
            tot[new] += agg['dup']
            print(f"{r:>6} {'NEW' if new else 'OLD':>5} {agg['mesh_jobs']:>9} {agg['dup']:>10} {agg['stale']:>5} {agg['missing']:>7}/{agg['want']:<4}")
            if new and (agg['dup'] or agg['missing']): ok = False
    # (after the player stops, EVERY chunk in the mesh radius must end up meshed)
    # failure injection: 15% of generation jobs return invalid data
    bad_old = sum(simulate(False, 4, s, fail_rate=0.15)['missing'] for s in range(40))
    bad_new = sum(simulate(True, 4, s, fail_rate=0.15)['missing'] for s in range(40))
    fb = sum(simulate(True, 4, s, fail_rate=0.15)['fallback'] for s in range(40))
    print(f"\n15% failed generations: chunks left unmeshed OLD={bad_old} NEW={bad_new} (fallback terrain used {fb}x)")
    if bad_new: ok = False
    # safe-mode style: single worker
    one = sum(simulate(True, 4, s, workers=1)['missing'] for s in range(40))
    print(f"single worker, radius 4: unmeshed NEW={one}")
    if one: ok = False
    print("\nduplicate mesh jobs total: OLD =", tot[False], " NEW =", tot[True])
    print("RESULT:", "PASS" if ok and tot[True] == 0 and tot[False] > 0 else "FAIL")
    raise SystemExit(0 if ok and tot[True] == 0 and tot[False] > 0 else 1)
