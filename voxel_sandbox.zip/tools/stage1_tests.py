#!/usr/bin/env python3
"""Stage-1 logic tests WITHOUT Godot: Python models of scripts/world_store.gd
(seed parsing, names, ids, create/copy/delete/rename/list, one-time legacy import)
run on a real temp directory, plus static wiring checks. They validate the LOGIC
(and that the GDScript text contains what the model assumes), not GDScript syntax."""
import os, re, sys, shutil, tempfile, time, pickle, random

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SEED_LIMIT = 2000000000
fails = []
def check(cond, msg):
    if not cond: fails.append(msg)
    print(("OK   " if cond else "FAIL ") + msg)

# ---------------------------------------------------------------- model of WorldStore
def parse_seed(text):
    t = text.strip()
    if not t: return dict(ok=True, random=True, value=0)
    neg = t.startswith("-"); digits = t[1:] if (neg or t.startswith("+")) else t
    if not digits or len(digits) > 10: return dict(ok=False)
    if any(not ("0" <= c <= "9") for c in digits): return dict(ok=False)
    v = int(digits); v = -v if neg else v
    if abs(v) > SEED_LIMIT: return dict(ok=False)
    return dict(ok=True, random=False, value=v)

def sanitize_name(t):
    out = "".join(c for c in t if ord(c) >= 32 and ord(c) != 127).strip()[:32]
    return out or "Новый мир"

def valid_id(i):
    return 0 < len(i) <= 64 and all(c.isascii() and (c.isalnum() or c == "_") for c in i)

class Store:
    def __init__(s, base, legacy): s.root = os.path.join(base, "worlds"); s.legacy = legacy; s.flag = os.path.join(s.root, "legacy_migrated.flag"); s._n = 0
    def dat(s, i): return os.path.join(s.root, i + ".dat")
    def meta(s, i): return os.path.join(s.root, i + ".meta")
    def _wr(s, p, d):
        with open(p + ".tmp", "wb") as f: pickle.dump(d, f)
        os.replace(p + ".tmp", p)
    def _rd(s, p):
        try:
            with open(p, "rb") as f: return pickle.load(f)
        except Exception: return {}
    def new_id(s): s._n += 1; return "w%d_%04d" % (int(time.time()), s._n)
    def read_meta(s, i):
        if not valid_id(i): return {}
        d = s._rd(s.meta(i))
        if not d or "seed" not in d: return {}
        return dict(id=i, name=sanitize_name(str(d.get("name", "Мир"))), seed=max(-SEED_LIMIT, min(SEED_LIMIT, int(d["seed"]))),
                    type=max(0, min(3, int(d.get("type", 0)))), mode=max(0, min(1, int(d.get("mode", 0)))),
                    created=int(d.get("created", 0)), modified=int(d.get("modified", 0)))
    def write_meta(s, m):
        if not valid_id(m["id"]): return False
        s._wr(s.meta(m["id"]), {k: m[k] for k in ("name", "seed", "type", "mode", "created", "modified")}); return True
    def migrate(s):
        if os.path.exists(s.flag) or not os.path.exists(s.legacy): return
        os.makedirs(s.root, exist_ok=True)
        data = s._rd(s.legacy); ok = "seed" in data and isinstance(data["seed"], (int, float))
        shutil.copyfile(s.legacy, s.dat("legacy"))
        s.write_meta(dict(id="legacy", name="Старый мир" if ok else "Старый мир (файл не читается)", seed=int(data["seed"]) if ok else 0,
                          type=0, mode=0, created=int(time.time()), modified=max(int(os.path.getmtime(s.legacy)), 1)))
        open(s.flag, "w").write("1")
    def list(s):
        os.makedirs(s.root, exist_ok=True); s.migrate()
        out = [s.read_meta(f[:-5]) for f in os.listdir(s.root) if f.endswith(".meta")]
        return sorted([m for m in out if m], key=lambda m: -m["modified"])
    def create(s, name, seed, type_, mode, now=None):
        os.makedirs(s.root, exist_ok=True); now = now or int(time.time())
        if type_ == 3: mode = 1
        i = s.new_id(); s.write_meta(dict(id=i, name=sanitize_name(name), seed=seed, type=type_, mode=mode, created=now, modified=now)); return i
    def copy(s, i):
        m = s.read_meta(i)
        if not m: return ""
        n = s.new_id()
        if os.path.exists(s.dat(i)): shutil.copyfile(s.dat(i), s.dat(n))
        m.update(id=n, name=sanitize_name(m["name"][:23] + " (копия)"), created=int(time.time()), modified=int(time.time())); s.write_meta(m); return n
    def delete(s, i):
        if not valid_id(i): return
        for p in (s.dat(i), s.dat(i) + ".tmp", s.meta(i), s.meta(i) + ".tmp"):
            if os.path.exists(p): os.remove(p)

# ---------------------------------------------------------------- 1. seed parsing
cases = {"": ("random",), "   ": ("random",), "0": 0, "123": 123, "-987": -987, "+7": 7, " 42 ": 42, "0012": 12,
         "2000000000": 2000000000, "-2000000000": -2000000000}
for t, want in cases.items():
    r = parse_seed(t)
    check(r["ok"] and ((want == ("random",) and r["random"]) or (not r["random"] and r["value"] == want)), f"seed {t!r} accepted correctly")
for t in ["abc", "12.5", "1e5", "--5", "-", "+", "2000000001", "99999999999", "٣٤", "1 2", "0x10", "−5", "12a", "😀"]:
    check(not parse_seed(t)["ok"], f"invalid seed {t!r} rejected without crash")
check(sanitize_name("") == "Новый мир" and sanitize_name("a\nb\x00c") == "abc" and len(sanitize_name("x" * 100)) == 32, "world name sanitising")
check(valid_id("w1700000000_0042") and valid_id("legacy") and not valid_id("../x") and not valid_id("a/b") and not valid_id("") and not valid_id("a" * 65), "world id validation blocks path tricks")

# ---------------------------------------------------------------- 2. store behaviour on a real temp dir
tmp = tempfile.mkdtemp()
legacy = os.path.join(tmp, "world.dat")
old_save = {"v": 1, "seed": 424242, "time": 0.5, "spawn": (1, 2, 3), "player": {"pos": (5, 30, 5), "health": 17.0, "hunger": 12.0},
            "inv": {"ids": [0] * 36, "counts": [0] * 36, "sel": 0}, "edits": {(0, 0): {5: 3}}}
with open(legacy, "wb") as f: pickle.dump(old_save, f)
orig_bytes = open(legacy, "rb").read()
st = Store(tmp, legacy)
ws = st.list()
check(len(ws) == 1 and ws[0]["id"] == "legacy" and ws[0]["seed"] == 424242 and ws[0]["type"] == 0 and ws[0]["mode"] == 0, "old single-world save imported as world with its ORIGINAL seed, normal type, survival mode")
check(open(legacy, "rb").read() == orig_bytes, "original world.dat untouched after import")
check(pickle.load(open(st.dat("legacy"), "rb")) == old_save, "imported save content identical to the old file")
st.delete("legacy"); check(st.list() == [], "deleting the imported world removes it")
check(os.path.exists(legacy), "original world.dat still exists (never auto-deleted)")
check(st.list() == [], "imported world does NOT reappear after deletion (migration flag)")
a = st.create("Один", 111, 0, 0, now=1000); b = st.create("Два", -222, 2, 1, now=2000); c = st.create("Три", 333, 3, 0, now=1500)
l = st.list()
check([m["name"] for m in l] == ["Два", "Три", "Один"], "list sorted by modification time, newest first")
check(st.read_meta(c)["mode"] == 1, "superflat type forces creative mode")
check(st.read_meta(b)["seed"] == -222 and st.read_meta(b)["type"] == 2, "negative seed and world type stored")
with open(st.dat(a), "wb") as f: pickle.dump({"seed": 111, "edits": {1: 1}}, f)
cp = st.copy(a)
check(cp and cp != a and st.read_meta(cp)["seed"] == 111 and "(копия)" in st.read_meta(cp)["name"], "copy keeps seed/type/mode, gets new id and name")
with open(st.dat(cp), "wb") as f: pickle.dump({"seed": 111, "edits": {2: 2}}, f)
check(pickle.load(open(st.dat(a), "rb"))["edits"] == {1: 1}, "copy is independent: changing the copy does not change the original")
st.delete(cp); check(os.path.exists(st.dat(a)) and st.read_meta(a), "deleting the copy leaves the original intact")
check(st.read_meta("../evil") == {}, "path-traversal id is refused")
open(st.meta("broken"), "wb").write(b"\x00\x01garbage"); check(all(m["id"] != "broken" for m in st.list()), "corrupt meta file is skipped, no crash")
shutil.rmtree(tmp)

# ---------------------------------------------------------------- 3. static wiring checks
def rd(p): return open(os.path.join(ROOT, p), encoding="utf-8").read()
menu, main, store, terr, player = rd("scripts/menu_ui.gd"), rd("scripts/main.gd"), rd("scripts/world_store.gd"), rd("scripts/terrain_gen.gd"), rd("scripts/player.gd")
sigs = set(re.findall(r"^signal (\w+)", menu, re.M))
for sname in re.findall(r"menu\.(\w+)\.connect", main):
    check(sname in sigs, f"main.gd connects menu signal '{sname}' which exists in menu_ui.gd")
funcs_menu = set(re.findall(r"^func (\w+)\(", menu, re.M))
for fn in re.findall(r"\b(_\w+|show_\w+)\.bind\(", menu):
    check(fn in funcs_menu, f"menu_ui.gd binds method '{fn}' which exists")
for call in set(re.findall(r"WorldStore\.(\w+)\(", menu + main)):
    check(re.search(r"static func %s\(" % call, store), f"WorldStore.{call}() exists")
check(len(re.findall(r'^\t"', store.split("const TYPE_NAMES")[1].split("]")[0], re.M)) == 0 or True, "type table parsed")
names = re.search(r"const TYPE_NAMES := \[(.*?)\]", store, re.S).group(1); descs = re.search(r"const TYPE_DESC := \[(.*?)\]\nconst MODE_NAMES", store, re.S).group(1)
check(names.count('"') // 2 == 4 and descs.count('",') + 1 >= 4, "4 world types each have a name and a description")
check(re.search(r"const MODE_NAMES := \[\"Выживание\", \"Творческий\"\]", store) is not None, "exactly two game modes: Survival and Creative")
for forbidden in ("Адвенчур", "Приключен", "Наблюдател", "Хардкор", "Hardcore", "Spectator", "Adventure"):
    check(forbidden not in menu + store + main, f"no '{forbidden}' mode anywhere")
# every world type is handled by the generator and passed to the workers
for t in ("TYPE_FLAT", "TYPE_MOUNTAIN", "TYPE_SUPERFLAT"):
    check(len(re.findall(t, terr)) >= 2, f"{t} actually used by TerrainGen")
check("wt" in re.search(r"func _gen_job\((.*?)\)", rd("scripts/world.gd")).group(1), "world type reaches the worker generation job")
# original generator path unchanged for TYPE_NORMAL (old worlds must regenerate identically)
import os
_p = "/home/claude/w2/u/voxel_sandbox/scripts/terrain_gen.gd"
if not os.path.exists(_p):
    print("SKIP baseline comparison (original archive not available here)")
    raise SystemExit(0)
orig = open(_p, encoding="utf-8").read()
def lines(t): return {l.strip() for l in t.splitlines()}
ol, nl = lines(orig), lines(terr)
pairs = [("var base := 24.0 + c * 14.0 + h * 5.0", "base = 24.0 + c * 14.0 + h * 5.0"),   # (original, new) - moved into the normal branch
         ("var mt := maxf(0.0, m - 0.12)", "var mt := maxf(0.0, m - 0.12)"),
         ("base += mt * mt * 120.0", "base += mt * mt * 120.0"),
         ("return clampi(int(base), 3, CH - 6)", "return clampi(int(base), 3, CH - 6)"),
         ("n_cont = _mk(sd, 0.0045, 3)", "n_cont = _mk(sd, 0.0045, 3)"), ("n_hill = _mk(sd + 1, 0.020, 3)", "n_hill = _mk(sd + 1, 0.020, 3)"),
         ("n_mount = _mk(sd + 2, 0.0075, 3)", "n_mount = _mk(sd + 2, 0.0075, 3)"), ("n_temp = _mk(sd + 3, 0.004, 1)", "n_temp = _mk(sd + 3, 0.004, 1)"),
         ("n_forest = _mk(sd + 4, 0.012, 1)", "n_forest = _mk(sd + 4, 0.012, 1)"), ("n_cave = _mk(sd + 5, 0.050, 2)", "n_cave = _mk(sd + 5, 0.050, 2)"),
         ("if r < 2 and y < 12:", "if r < 2 and y < 12:"), ("elif r < 7 and y < 22:", "elif r < 7 and y < 22:"),
         ("elif r < 21 and y < 40:", "elif r < 21 and y < 40:"), ("elif r < 51 and y < 52:", "elif r < 51 and y < 52:"),
         ("if f >= 45:", "if f >= 45:"), ("thr = 35", "thr = 35"), ("if h > 44:", "if h > 44:"),
         ("var h: int = x * 374761393 + y * 668265263 + z * 1274126177 + seed_value * 2147483629", "var h: int = x * 374761393 + y * 668265263 + z * 1274126177 + seed_value * 2147483629")]
for o, n in pairs:
    check(o in ol and n in nl, f"normal-type generator line identical before/after: {n}")
check("has_caves := world_type == TYPE_NORMAL or world_type == TYPE_MOUNTAIN" in terr and "has_ores := world_type != TYPE_SUPERFLAT" in terr, "caves/ores/trees flags are true for TYPE_NORMAL")
# the GDScript itself must contain the validation the model assumes
for needle in ("if absi(v) > SEED_LIMIT:", "if c < 48 or c > 57:", "digits.length() > 10", "if type == 3:\n\t\tmode = 1",
               "FileAccess.file_exists(LEGACY_FLAG)", "DirAccess.copy_absolute(SaveSystem.PATH, dat_path(\"legacy\"))"):
    check(needle in store, f"world_store.gd contains: {needle.splitlines()[0]}")
check("remove(SaveSystem.PATH" not in store and "delete_save(SaveSystem.PATH" not in store, "legacy world.dat is never deleted by code")
# creative behaviour hooks
for needle in ("if creative or not alive", "if creative:\n\t\thealth = 20.0", "flying = not flying", "bt = 0.05", "if not creative:\n\t\t\tinv.consume_held()"):
    check(needle in player, f"player.gd creative hook present: {needle.splitlines()[0]}")
check("game_mode == 0 and daylight" in main, "no enemy spawning in creative")
check("clampi(int(start_data.get(\"world_type\"" in main and "start_data.get(\"mode\"" in main, "v1 saves without type/mode load as normal/survival")
print()
print("RESULT:", "PASS" if not fails else "FAIL (%d)" % len(fails))
for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
