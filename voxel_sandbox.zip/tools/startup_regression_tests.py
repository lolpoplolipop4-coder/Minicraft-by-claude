#!/usr/bin/env python3
"""Regression checks for startup ordering and Android build validation.
These checks are static; Godot runtime validation is performed by CI.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
main = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")
gen_log = (ROOT / "scripts/gen_log.gd").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/android.yml").read_text(encoding="utf-8")
local_build = (ROOT / "tools/build_android.sh").read_text(encoding="utf-8")
boot = (ROOT / "scripts/boot.gd").read_text(encoding="utf-8")
main_scene = (ROOT / "scenes/main.tscn").read_text(encoding="utf-8")

checks = []
def check(ok: bool, message: str) -> None:
    checks.append((ok, message))
    print(("OK   " if ok else "FAIL ") + message)

ready = main.split("func _ready() -> void:", 1)[1].split("\n\n# Small procedural", 1)[0]
check(ready.find("_setup_ui()") >= 0 and ready.find("menu.show_main()") >= 0,
      "startup creates and displays the menu before graphics initialization")
check(ready.find("menu.show_main()") < ready.find("Atlas.build()"),
      "menu is shown before procedural atlas generation")
check(ready.find("menu.show_main()") < ready.find("_setup_environment()"),
      "menu is shown before environment and cloud creation")
check("signal startup_completed" in main and "startup_completed.emit()" in ready,
      "main scene confirms successful startup only after UI and environment setup")
check("instance.connect(\"startup_completed\"" in boot,
      "boot controller waits for an explicit successful-startup signal")
check("_canvas.queue_free()" in boot and "_show_failure" in boot,
      "startup overlay is removed on success and retained on failure")
check("change_scene_to_packed" not in boot and 'type=\"Node\"' in main_scene,
      "boot controller stays alive instead of abandoning diagnostics at scene switch")
check("ProjectSettings.globalize_path(DIR)" in gen_log,
      "diagnostic log directory is normalized before creation")
check('godot --headless --path "$GITHUB_WORKSPACE" --editor --quit' in workflow,
      "Android workflow runs Godot editor validation")
validation_step = workflow.split("- name: Import and validate project scripts", 1)[1].split("- name: Export debug APK", 1)[0]
check("|| true" not in validation_step,
      "Android workflow does not swallow validation failures")
check("Run logic regression tests" in workflow,
      "Android workflow runs project regression tests before export")
check("Run game startup smoke test" in workflow and "--quit-after 120" in workflow
      and "ready; main menu initialized" in workflow,
      "GitHub Actions boots the actual main scene and requires startup completion")
check("--quit-after 120" in local_build and "ready; main menu initialized" in local_build,
      "local Android build also runs the actual game startup before export")
check("|| true" not in local_build and "validate_project" in local_build,
      "local Android build also refuses to export after validation errors")

if not all(ok for ok, _ in checks):
    sys.exit(1)
print(f"All {len(checks)} startup regression checks passed.")
