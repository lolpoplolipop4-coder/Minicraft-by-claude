import re,sys,os,glob
D=sys.argv[1]
builtins=set("""true false null self super PI TAU INF NAN str int float bool abs absf absi sin cos tan atan2 sqrt pow floor floori ceil ceili round roundi min max mini maxi minf maxf clamp clampi clampf lerp lerpf lerp_angle move_toward smoothstep fposmod posmod randi randf randi_range randf_range randomize print push_warning push_error printerr range len is_finite is_nan is_instance_valid error_string var_to_str load preload typeof signed_to_unsigned absf sign signf signi snappedf log exp wrapf wrapi remap inverse_lerp ease deg_to_rad rad_to_deg hash weakref Vector2 Vector3 Color Rect2 Basis Transform3D Callable and or not in is as if elif else for while match pass return break continue var const func class extends static signal enum await void""".split())
files=glob.glob(D+'/*.gd')
classes=set()
members={}
for f in files:
    s=open(f,encoding='utf-8').read()
    m=re.search(r'^class_name\s+(\w+)',s,re.M)
    if m: classes.add(m.group(1))
for f in files:
    s=open(f,encoding='utf-8').read()
    mem=set()
    for m in re.finditer(r'^(?:static\s+)?(?:var|const)\s+(\w+)',s,re.M): mem.add(m.group(1))
    for m in re.finditer(r'^(?:static\s+)?func\s+(\w+)',s,re.M): mem.add(m.group(1))
    for m in re.finditer(r'^signal\s+(\w+)',s,re.M): mem.add(m.group(1))
    for m in re.finditer(r'^enum\s+(\w+)\s*\{([^}]*)\}',s,re.M|re.S):
        mem.add(m.group(1))
        for x in re.findall(r'\w+',m.group(2)): mem.add(x)
    ext=re.search(r'^extends\s+(\w+)',s,re.M)
    members[f]=mem
def strip(line):
    line=re.sub(r'"(?:\\.|[^"\\])*"','""',line)
    line=re.sub(r"'(?:\\.|[^'\\])*'","''",line)
    line=line.split('#')[0]
    return line
for f in files:
    s=open(f,encoding='utf-8').read().split('\n')
    mem=members[f]
    # split into functions
    i=0
    cur=None; declared=set(); startln=0
    intriple=False
    for ln,raw in enumerate(s,1):
        if raw.count('"""')%2==1: intriple=not intriple; continue
        if intriple: continue
        line=strip(raw)
        m=re.match(r'^(?:static\s+)?func\s+\w+\s*\((.*)',line)
        if m:
            declared=set()
            # params may span lines; collect until ')'
            params=m.group(1)
            j=ln
            while ')' not in params and j<len(s):
                params+=strip(s[j]); j+=1
            for p in re.findall(r'(\w+)\s*(?::|=|,|\))',params.split(')')[0]+')'):
                declared.add(p)
            cur=True
            continue
        if not line.strip(): continue
        if not raw.startswith('\t'):
            cur=None; continue
        if cur is None: continue
        for m in re.finditer(r'\bvar\s+(\w+)',line): declared.add(m.group(1))
        for m in re.finditer(r'\bfor\s+(\w+)\s+in\b',line): declared.add(m.group(1))
        for m in re.finditer(r'func\s*\(([^)]*)\)',line):
            for p in re.findall(r'(\w+)',m.group(1)):
                declared.add(p)
        m=re.match(r'\s*match\b',line)
        for m in re.finditer(r'\bvar\s+(\w+)',line): declared.add(m.group(1))
        # identifiers not preceded by . or $ and not followed by (? include calls
        for m in re.finditer(r'(?<![\w.$@%&])([A-Za-z_]\w*)',line):
            n=m.group(1)
            if n in declared or n in mem or n in builtins or n in classes: continue
            if n[0].isupper(): continue
            # skip dict keys? e.g. {"a": x}; strings already stripped
            print(f"{os.path.basename(f)}:{ln}: {n}   | {line.strip()[:90]}")


# ---- extra check: GDScript has no tuples. `"%s %s" % (a, b)` is a PARSE ERROR (use [a, b]).
def _tuple_check(d):
    for f in sorted(glob.glob(d + '/*.gd')):
        for ln, raw in enumerate(open(f, encoding='utf-8').read().split('\n'), 1):
            line = strip(raw)
            i = 0
            while True:
                i = line.find('% (', i)
                if i < 0:
                    break
                depth = 0
                j = i + 2
                comma = False
                while j < len(line):
                    ch = line[j]
                    if ch in '([{':
                        depth += 1
                    elif ch in ')]}':
                        depth -= 1
                        if depth == 0:
                            break
                    elif ch == ',' and depth == 1:
                        comma = True
                    j += 1
                if comma:
                    print(f"{os.path.basename(f)}:{ln}: TUPLE after % (parse error) | {raw.strip()[:90]}")
                i += 3


_tuple_check(D)
