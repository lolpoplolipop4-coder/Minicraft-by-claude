# Voxel Sandbox — Android voxel game (Godot 4.3+)

An original Minecraft-style survival sandbox: procedural terrain, mining/building,
crafting, hunger/health, day/night, weather, night enemies, local saves — with a
full touch UI. Native Android app, package `com.example.voxelsandbox`.

## ⚠️ Honest status

* **No APK is included.** The environment this was written in had no Godot, no
  Android SDK and no internet, so nothing could be compiled or run.
* The code has **not been opened in the Godot editor yet**. It was reviewed line by line
  and checked with `tools/verify_project.py` / `tools/algo_tests.py` (see "Checks that were
  run"), but expect that the first import may still show a small GDScript error or two.
  Please report them (the exact message + file/line) and they are quick fixes.

## Revision notes (bug-fix pass)

Fixes made after a full code review — all aimed at crashes, freezes and corrupt-save cases:

* **Endless loading screen** with a small view distance (2 chunks): the loading check waited
  for chunks that are never meshed at that setting. It now only waits for reachable chunks
  (`World.ready_progress`), plus a 90 s safety timeout in `main.gd`.
* **Damaged / old save no longer crashes the game**: `main.gd` validates the save
  (`_valid_save`, `_sanitize_edits`), `Inventory.from_dict` accepts only known items and sane
  counts, `TerrainGen` ignores out-of-range block edits, `SaveSystem.load_game` ignores empty
  files. An unreadable save starts a new world and shows a toast.
* **Stale worker-thread results** (chunk unloaded and re-created while a job was running) are
  now dropped by chunk identity (`world.gd`), and the task counter is read under the mutex.
* **Falling into the void on spawn/respawn**: the player now waits while the chunk under their
  feet is not loaded, and respawn lifts the player out of a spawn spot that was built over.
* **Save writing** replaces `world.dat` in one step first and only deletes the old file if the
  platform refuses, so a failed write cannot lose the previous save.
* `main.gd` no longer sets 3D resolution scaling on the Compatibility renderer (unsupported there).
* Freed enemies can no longer break the respawn loop (`_remove_mob` accepts any instance).
* Android Back on the main menu now quits the app; enemy flash effect no longer re-applies
  every frame; view distance is clamped to 2..8 everywhere; export excludes `tools/`, `.github/`.

## Get the APK (pick one)

### A) Cloud build — nothing to install (works from a phone browser)

1. Create a GitHub repository and upload **the contents** of this folder (so
   `project.godot` is at the repo root and `.github/workflows/android.yml` exists).
2. Repo → **Actions** → **Build Android APK** → **Run workflow**.
3. When it finishes (~5 min) open the run → **Artifacts** → `VoxelSandbox-debug-apk`.
   Download, unzip, install `VoxelSandbox-debug.apk` (see "Install" below).

### B) On your own computer (Windows / macOS / Linux)

1. Install **Godot 4.3** (standard, not .NET) and its **export templates**
   (Godot → Editor → Manage Export Templates → Download).
2. Install **JDK 17** and the **Android SDK** command-line tools, then:
   ```
   sdkmanager "platform-tools" "build-tools;34.0.0" "platforms;android-34" "cmdline-tools;latest"
   ```
3. Godot → Editor → Editor Settings → Export → Android: set **Android SDK Path**
   and **Java SDK Path** (JDK 17 folder).
4. Debug keystore (once):
   ```
   keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android \
     -keystore ~/.android/debug.keystore -storepass android \
     -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
   ```
   and set it in Editor Settings → Export → Android → Debug Keystore
   (user `androiddebugkey`, password `android`).
5. Build: open the project in Godot → **Project → Export → Android → Export Project**
   with **Export With Debug** ticked → `VoxelSandbox-debug.apk`.
   Or from a terminal: `tools/build_android.sh debug` (Linux/macOS/Git-Bash).

## Release APK

```
keytool -genkeypair -v -keystore release.keystore -alias voxel -keyalg RSA -keysize 2048 -validity 10000
export GODOT_ANDROID_KEYSTORE_RELEASE_PATH=$PWD/release.keystore
export GODOT_ANDROID_KEYSTORE_RELEASE_USER=voxel
export GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD=your-password
tools/build_android.sh release          # -> build/VoxelSandbox-release.apk
```
In the GitHub workflow, add repository secrets `RELEASE_KEYSTORE_BASE64`
(`base64 -w0 release.keystore`), `RELEASE_KEY_ALIAS`, `RELEASE_KEYSTORE_PASSWORD`
and a signed release APK is produced automatically. **Back up the keystore** —
you cannot update an installed app without it. Before publishing anywhere,
change the package ID `com.example.voxelsandbox` (Project → Export → Android).

## Install on your phone

1. Copy the APK to the phone (cloud drive, USB, messaging to yourself).
2. Open it; if prompted, allow **Install unknown apps** for the app you opened it from.
3. Or with USB debugging: `adb install -r build/VoxelSandbox-debug.apk`.

## Controls

| Touch | Action |
|---|---|
| Left side, drag | Floating virtual joystick (follows your thumb) |
| Right side, drag | Look (smoothed) — never triggered by buttons/hotbar |
| BREAK (hold) | Mine block / attack enemy |
| PLACE (tap or hold) | Place block, or eat food if held |
| JUMP / SNEAK (hold) / RUN (toggle) | Movement (auto-jumps 1-block steps) |
| Hotbar slot (tap) | Select item |
| BAG | Inventory + crafting (tap slot → tap target slot; tap recipe to craft) |
| MENU / Android back | Pause: shadows, view distance, look speed, Save & Quit |

Desktop test controls: WASD, Space, Shift (sneak), Ctrl (run); left-mouse drag on the
right half looks around (mouse is emulated as touch).

**How to play:** punch a tree trunk (hold BREAK) → Logs → craft Planks → craft a
Crafting Table, place it → craft tools near it. Iron/gold/diamond ores drop ingots/gems
directly (there is no furnace). Enemies appear at night and burn at dawn. Eat apples
(from leaves) and rotten flesh (from enemies) to keep hunger up. The world auto-saves
every 90 s, on pause, and when the app goes to the background.

## What is implemented

| Requirement | Where |
|---|---|
| Chunk streaming, load/unload | `scripts/world.gd` (16×64×16 chunks, `WorkerThreadPool`, max 2 mesh uploads/frame) |
| Visible-face-only meshes | `scripts/mesher.gd` (one mesh per chunk + one water mesh, vertex-colour shading, cave darkening) |
| Collision | Direct voxel-grid AABB collision (`World.move_box`), **zero collision shapes / physics bodies** |
| Terrain: hills, mountains, caves, oceans, beaches, deserts, trees, ores | `scripts/terrain_gen.gd` (deterministic from seed) |
| Textures | `scripts/atlas.gd` — original procedural pixel art generated at start-up |
| Lighting/shadows, sky, day/night, rain, water, particles | `scripts/main.gd`, `world.gd` (water shader), `mesher.gd` |
| Block outline + crack overlay | `scripts/player.gd` (shader) |
| Touch UI | `scripts/hud.gd` (per-finger routing; scales to any aspect ratio) |
| Inventory (36), 9-slot hotbar, crafting, tools | `inventory.gd`, `inventory_ui.gd`, `crafting.gd`, `items.gd` |
| Health, hunger, fall/starve damage, respawn | `player.gd` |
| Enemies | `mob.gd` (spawn at night near the player, burn in daylight) |
| Save/load | `save_system.gd` — stores seed + player + inventory + **only block edits** |
| Android config | `export_presets.cfg`, `project.godot` |

Android setup: landscape (sensor landscape), no permissions requested (saves go to the
app's private storage), arm64-v8a, immersive mode, icon + splash included, Compatibility
(OpenGL ES 3) renderer for broad device support. Not included: sound (no audio assets
were created), furnace/smelting, fluid flow, multiplayer.

## Performance notes

* All terrain/meshing work is off the main thread; only 1–3 workers are used so the
  render thread is never starved.
* Default view distance is 4 chunks (64 blocks) on mobile — change in the pause menu.
* Shadows are one orthogonal split, 48 m. Turn them off in the pause menu on weak phones.
* If you want the Vulkan "Mobile" renderer: change `renderer/rendering_method.mobile`
  in `project.godot` to `mobile` (adds 3D resolution scaling, needs Vulkan devices).

## Checks that were run (without Godot)

```
python3 tools/verify_project.py   # indentation, bracket balance, mesher winding & UV orientation,
                                  # table sizes, class references, resource paths
python3 tools/algo_tests.py       # Python ports of chunk-border indexing, voxel raycast,
                                  # collision and tree-across-border logic vs brute force
```
Both pass. They validate geometry/logic, **not** GDScript syntax or engine behaviour.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Parse Error` / `Identifier "Blocks" not declared` on first open | Open the project once in the editor (or run `godot --headless --import`) so `class_name` scripts are registered, then export. |
| `Could not find Android SDK / Java SDK` | Set both paths in Editor Settings → Export → Android. JDK must be **17**. |
| `Invalid debug keystore` | Create `debug.keystore` (command above) and point to it, or set `GODOT_ANDROID_KEYSTORE_DEBUG_*` env vars. |
| `Android build tools 34.0.0 missing` | `sdkmanager "build-tools;34.0.0"` (Godot 4.3 wants exactly this version). |
| `No export template found` | Install templates matching the **exact** editor version (Editor → Manage Export Templates). |
| `Target platform requires 'ETC2/ASTC' texture compression` | Already enabled in `project.godot`; if you reset settings, tick Rendering → Textures → VRAM Compression → Import ETC2 ASTC. |
| App crashes at start / black screen | `adb logcat -s godot`; try lowering view distance, or ensure device supports OpenGL ES 3.0. |
| "App not installed" | Uninstall an older build signed with a different key, or enable Install unknown apps. |
| World looks dark/foggy | It's night, raining, or underwater; fog is tied to view distance. |
| Slow chunk loading | Lower view distance to 3; first load of a new world does the heaviest work. |
| GitHub Action fails at "Android SDK" | Check the runner image still provides `cmdline-tools/latest`; adjust `ANDROID_HOME` in the workflow. |
