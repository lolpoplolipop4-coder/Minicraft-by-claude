class_name Animal
extends Node3D
## Passive animal built from boxes (same zero-import approach as Mob).
## Supported kinds: 0=Cow, 1=Pig, 2=Sheep, 3=Chicken.
## Animals graze, wander, flee when hit, and drop items on death.
## Uses the same voxel AABB collision as the player (World.move_box).

signal died(animal)

const KIND_COW     := 0
const KIND_PIG     := 1
const KIND_SHEEP   := 2
const KIND_CHICKEN := 3

const HW := 0.35
const H_FULL := 1.4   # cow/sheep/pig body height
const H_CHICK := 0.6  # chicken

const DROPS := {
	KIND_COW:     [[Items.FLESH, 1, 3]],                          # 1-3 raw beef (use FLESH)
	KIND_PIG:     [[Items.FLESH, 1, 2]],
	KIND_SHEEP:   [[Items.FLESH, 1, 2], [Items.WOOL, 1, 2]],
	KIND_CHICKEN: [[Items.FLESH, 1, 1], [Items.FEATHER, 1, 2]],
}

const PALETTE := {
	KIND_COW:     {"body": Color(0.22,0.18,0.12), "legs": Color(0.18,0.14,0.09), "face": Color(0.72,0.68,0.62)},
	KIND_PIG:     {"body": Color(0.92,0.62,0.60), "legs": Color(0.85,0.52,0.50), "face": Color(0.98,0.70,0.68)},
	KIND_SHEEP:   {"body": Color(0.78,0.78,0.76), "legs": Color(0.50,0.45,0.40), "face": Color(0.62,0.55,0.48)},
	KIND_CHICKEN: {"body": Color(0.94,0.92,0.88), "legs": Color(0.92,0.72,0.18), "face": Color(0.94,0.82,0.76)},
}

var kind := KIND_COW
var world: World
var player: Node   # Player (duck typed)
var main: Node
var hp := 10.0
var vel := Vector3.ZERO
var on_ground := false
var _h := H_FULL

var _dead := false
var _flash := 0.0
var _anim := 0.0
var _wander_dir := Vector3.ZERO
var _wander_t := 0.0
var _flee_t := 0.0
var _idle_t := 0.0
var _legs: Array[Node3D] = []
var _mats: Array[StandardMaterial3D] = []


func _init(k: int = KIND_COW) -> void:
	kind = k
	_h = H_CHICK if k == KIND_CHICKEN else H_FULL
	_build()


func setup(w: World, p: Node, m: Node) -> void:
	world = w
	player = p
	main = m


# ------------------------------------------------------------------ build

func _box(parent: Node3D, sz: Vector3, pos: Vector3, col: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = sz
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.roughness = 1.0
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	_mats.append(mat)


func _build() -> void:
	var p: Dictionary = PALETTE[kind]
	var bc: Color = p["body"]
	var lc: Color = p["legs"]
	var fc: Color = p["face"]
	match kind:
		KIND_COW, KIND_SHEEP:
			_box(self, Vector3(0.80, 0.60, 0.45), Vector3(0, 0.82, 0), bc)
			_box(self, Vector3(0.42, 0.42, 0.42), Vector3(0, 1.28, 0), fc)
			_box(self, Vector3(0.10, 0.08, 0.02), Vector3(-0.12,1.33,-0.22), Color(0.05,0.05,0.06))
			_box(self, Vector3(0.10, 0.08, 0.02), Vector3( 0.12,1.33,-0.22), Color(0.05,0.05,0.06))
			if kind == KIND_COW:
				_box(self, Vector3(0.08,0.16,0.08), Vector3(-0.10,0.84,-0.24), Color(0.88,0.82,0.76))
			for sx in [-1.0, 1.0]:
				for sz2 in [-1.0, 1.0]:
					var leg := Node3D.new()
					leg.position = Vector3(0.22*sx, 0.42, 0.14*sz2)
					add_child(leg)
					_box(leg, Vector3(0.18,0.44,0.18), Vector3(0,-0.22,0), lc)
					_legs.append(leg)
		KIND_PIG:
			_box(self, Vector3(0.72, 0.52, 0.40), Vector3(0, 0.72, 0), bc)
			_box(self, Vector3(0.40, 0.38, 0.38), Vector3(0, 1.14, 0), fc)
			_box(self, Vector3(0.18, 0.10, 0.12), Vector3(0, 1.06, -0.25), bc.lightened(0.08))
			for sx in [-1.0, 1.0]:
				for sz2 in [-1.0, 1.0]:
					var leg := Node3D.new()
					leg.position = Vector3(0.20*sx, 0.36, 0.12*sz2)
					add_child(leg)
					_box(leg, Vector3(0.16,0.36,0.16), Vector3(0,-0.18,0), lc)
					_legs.append(leg)
		KIND_CHICKEN:
			_box(self, Vector3(0.32, 0.28, 0.28), Vector3(0, 0.36, 0), bc)
			_box(self, Vector3(0.24, 0.24, 0.24), Vector3(0, 0.58, 0), fc)
			_box(self, Vector3(0.10, 0.06, 0.06), Vector3(0, 0.54,-0.15), Color(0.92,0.68,0.12))
			_box(self, Vector3(0.28, 0.08, 0.14), Vector3(-0.22, 0.40, 0), bc.darkened(0.1))
			_box(self, Vector3(0.28, 0.08, 0.14), Vector3( 0.22, 0.40, 0), bc.darkened(0.1))
			for sx in [-1.0, 1.0]:
				var leg := Node3D.new()
				leg.position = Vector3(0.07*sx, 0.18, 0)
				add_child(leg)
				_box(leg, Vector3(0.06,0.20,0.06), Vector3(0,-0.10,0), lc)
				_legs.append(leg)


# ------------------------------------------------------------------ logic

func _process(delta: float) -> void:
	if _dead or world == null or main == null or main.paused:
		return
	var dt := minf(delta, 1.0 / 30.0)

	_idle_t -= dt
	_flee_t -= dt
	_wander_t -= dt
	_flash -= dt
	if _flash <= 0.0 and _flash > -1.0:
		_set_flash(false)
		_flash = -99.0

	# Movement direction
	var dir := Vector3.ZERO
	var speed := 0.0

	if _flee_t > 0.0 and is_instance_valid(player):
		# Flee from player
		var away := (position - (player as Node3D).position)
		away.y = 0.0
		if away.length() > 0.1:
			dir = away.normalized()
		speed = 3.8
	elif _idle_t > 0.0:
		# Standing still - graze
		speed = 0.0
	else:
		# Wander
		if _wander_t <= 0.0:
			_wander_t = randf_range(2.0, 6.0)
			if randf() < 0.35:
				_idle_t = randf_range(1.5, 4.0)
			else:
				_wander_dir = Vector3(randf_range(-1,1), 0, randf_range(-1,1)).normalized()
		dir = _wander_dir
		speed = 1.4

	var tv := dir * speed
	var accel := 14.0 if on_ground else 5.0
	vel.x = move_toward(vel.x, tv.x, accel * dt)
	vel.z = move_toward(vel.z, tv.z, accel * dt)

	# Chickens flutter; others just fall
	if kind == KIND_CHICKEN and not on_ground:
		vel.y = maxf(vel.y - 10.0 * dt, -3.0)
	else:
		vel.y = maxf(vel.y - 28.0 * dt, -24.0)

	var r := world.move_box(position, vel, HW, _h, dt)
	position = r["pos"]
	vel = r["vel"]
	on_ground = r["grounded"]

	# Auto-hop single blocks
	if r["walled"] and on_ground and dir.length() > 0.1:
		vel.y = 6.0

	# Kill if fallen into void
	if position.y < -30.0:
		_die()
		return

	# Rotate toward movement
	if dir.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, 8.0 * dt))

	# Walk animation
	_anim += Vector2(vel.x, vel.z).length() * dt * 4.0
	var sw := sin(_anim) * 0.6
	for li in _legs.size():
		_legs[li].rotation.x = sw if li % 2 == 0 else -sw


func hurt(dmg: float, dir: Vector3) -> void:
	if _dead:
		return
	hp -= dmg
	vel.x += dir.x * 5.0
	vel.z += dir.z * 5.0
	vel.y = 4.0
	_flee_t = 3.0
	_flash = 0.18
	_set_flash(true)
	if hp <= 0.0:
		_die()


func _set_flash(on: bool) -> void:
	for mat in _mats:
		mat.emission_enabled = on
		mat.emission = Color(0.8, 0.1, 0.1)


func _die() -> void:
	if _dead:
		return
	_dead = true
	if main != null:
		main.burst(position + Vector3(0, 0.7, 0), Color(0.7, 0.5, 0.3), 10, 3.0)
		var drops: Array = DROPS.get(kind, [])
		for drop in drops:
			var cnt := randi_range(int(drop[1]), int(drop[2]))
			(main as Node).get("inv").add(int(drop[0]), cnt)
			main.hud.show_toast("+%d %s" % [cnt, Items.item_name(int(drop[0]))])
	died.emit(self)
	queue_free()
