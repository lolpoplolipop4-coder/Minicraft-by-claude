class_name Atlas
extends RefCounted
## Generates every texture at startup (16x16 pixel tiles in a 256x256 atlas).
## All art is original and procedural - no external image files are needed.
##
## Tile layout:
##   0 grass top   1 grass side  2 dirt      3 stone     4 sand      5 log side
##   6 log top     7 leaves      8 water     9 coal ore 10 iron ore 11 gold ore
##  12 diamond ore 13 planks    14 cobble   15 bedrock  16 table top 17 table side
##  32 stick 33 coal 34 iron ingot 35 gold ingot 36 diamond 37 apple 38 flesh
##  40..55 tools: 40 + material*4 + kind (pickaxe, axe, shovel, sword)

const TILE := 16
const SIZE := 256

const PAT_PICK := ["..hhhh..", ".hh..hhh", "h.....sh", ".....s..", "....s...", "...s....", "..s.....", ".s......"]
const PAT_AXE := ["....hhh.", "...hhhhh", "....hhs.", ".....s..", "....s...", "...s....", "..s.....", ".s......"]
const PAT_SHOVEL := [".....hhh", ".....hhh", "......s.", ".....s..", "....s...", "...s....", "..s.....", ".s......"]
const PAT_SWORD := ["......hh", ".....hh.", "....hh..", ".g.hh...", "..gg....", ".sg.....", "s.......", "........"]
const PAT_STICK := ["........", "......s.", ".....s..", "....s...", "...s....", "..s.....", ".s......", "........"]
const PAT_BLOB := ["........", "..bbbb..", ".bbbbbb.", ".bbbbbb.", ".bbbbbb.", ".bbbbbb.", "..bbbb..", "........"]
const PAT_APPLE := ["....l...", "..bbbb..", ".bbbbbb.", ".bbbbbb.", ".bbbbbb.", ".bbbbbb.", "..bbbb..", "........"]
const PAT_INGOT := ["........", "........", "..bbbbbb", ".bbbbbbb", ".bbbbbb.", ".bbbbbb.", "........", "........"]
const PAT_GEM := ["........", "...bb...", "..bbbb..", ".bbbbbb.", "..bbbb..", "...bb...", "........", "........"]

static var image: Image
static var texture: ImageTexture
static var moon_texture: ImageTexture
static var _avg_cache: Dictionary = {}


static func build() -> void:
	if image != null:
		return
	image = Image.create(SIZE, SIZE, false, Image.FORMAT_RGBA8)
	image.fill(Color(0, 0, 0, 0))
	var rng := RandomNumberGenerator.new()
	rng.seed = 20240607
	_terrain(rng)
	_items()
	texture = ImageTexture.create_from_image(image)
	moon_texture = _make_moon()


# ------------------------------------------------------------------ helpers

static func _px(t: int, x: int, y: int, c: Color) -> void:
	image.set_pixel((t & 15) * TILE + x, (t >> 4) * TILE + y, c)


static func _get(t: int, x: int, y: int) -> Color:
	return image.get_pixel((t & 15) * TILE + x, (t >> 4) * TILE + y)


static func _fill(t: int, base: Color, amp: float, rng: RandomNumberGenerator) -> void:
	for y in TILE:
		for x in TILE:
			var n := (rng.randf() - 0.5) * 2.0 * amp
			_px(t, x, y, Color(base.r + n, base.g + n, base.b + n, 1.0))


static func _speckle(t: int, col: Color, n: int, rng: RandomNumberGenerator) -> void:
	for k in n:
		_px(t, rng.randi_range(0, TILE - 1), rng.randi_range(0, TILE - 1), col)


static func _copy(dst: int, src: int) -> void:
	for y in TILE:
		for x in TILE:
			_px(dst, x, y, _get(src, x, y))


static func _ore(t: int, col: Color, rng: RandomNumberGenerator) -> void:
	_copy(t, 3)
	for k in 5:
		var cx := rng.randi_range(2, 12)
		var cy := rng.randi_range(2, 12)
		for dx in 2:
			for dy in 2:
				_px(t, cx + dx, cy + dy, col if (dx + dy) % 2 == 0 else col.darkened(0.15))


# ------------------------------------------------------------------ terrain

static func _terrain(rng: RandomNumberGenerator) -> void:
	# 0 grass top, 2 dirt, 1 grass side
	_fill(0, Color(0.36, 0.64, 0.24), 0.06, rng)
	_fill(2, Color(0.47, 0.33, 0.20), 0.05, rng)
	_speckle(2, Color(0.34, 0.23, 0.13), 14, rng)
	_copy(1, 2)
	for x in TILE:
		var d := 3
		if rng.randf() < 0.35:
			d += 1
		if rng.randf() < 0.15:
			d += 1
		for y in d:
			_px(1, x, y, _get(0, x, y))
	# 3 stone
	_fill(3, Color(0.52, 0.52, 0.53), 0.05, rng)
	_speckle(3, Color(0.38, 0.38, 0.40), 16, rng)
	_speckle(3, Color(0.62, 0.62, 0.63), 10, rng)
	# 4 sand
	_fill(4, Color(0.86, 0.80, 0.56), 0.035, rng)
	_speckle(4, Color(0.93, 0.88, 0.66), 12, rng)
	# 5 log side
	for y in TILE:
		for x in TILE:
			var s := 0.0
			if x % 4 == 0 or x % 7 == 3:
				s = 0.06
			var n := (rng.randf() - 0.5) * 0.05
			_px(5, x, y, Color(0.42 - s + n, 0.30 - s + n, 0.17 - s * 0.6 + n))
	# 6 log top (rings)
	for y in TILE:
		for x in TILE:
			var d := maxf(absf(x - 7.5), absf(y - 7.5))
			var c := Color(0.42, 0.30, 0.17)
			if d <= 6.5:
				c = Color(0.72, 0.57, 0.35) if int(d) % 2 == 0 else Color(0.62, 0.47, 0.28)
			var n := (rng.randf() - 0.5) * 0.04
			_px(6, x, y, Color(c.r + n, c.g + n, c.b + n))
	# 7 leaves (transparent holes -> alpha scissor)
	for y in TILE:
		for x in TILE:
			var n := (rng.randf() - 0.5) * 0.16
			var a := 1.0
			if rng.randf() < 0.16:
				a = 0.0
			_px(7, x, y, Color(0.18 + n, 0.50 + n, 0.14 + n, a))
	# 8 water
	_fill(8, Color(0.18, 0.38, 0.78), 0.03, rng)
	_speckle(8, Color(0.35, 0.55, 0.90), 18, rng)
	# 9..12 ores
	_ore(9, Color(0.10, 0.10, 0.11), rng)
	_ore(10, Color(0.85, 0.62, 0.50), rng)
	_ore(11, Color(0.96, 0.80, 0.20), rng)
	_ore(12, Color(0.35, 0.92, 0.92), rng)
	# 13 planks
	for y in TILE:
		for x in TILE:
			var s := 0.0
			if y % 4 == 3:
				s = 0.10
			elif (x + (y >> 2) * 5) % 11 == 0:
				s = 0.05
			var n := (rng.randf() - 0.5) * 0.04
			_px(13, x, y, Color(0.72 - s + n, 0.56 - s + n, 0.33 - s + n))
	# 14 cobblestone
	for y in TILE:
		for x in TILE:
			var row := y / 5
			var xo := x + (3 if row % 2 == 1 else 0)
			var cell := xo / 5
			var shade := 0.42 + float((cell * 7 + row * 13) % 5) * 0.045 + (rng.randf() - 0.5) * 0.04
			if xo % 5 == 0 or y % 5 == 0:
				shade -= 0.14
			_px(14, x, y, Color(shade, shade, shade + 0.01))
	# 15 bedrock
	_fill(15, Color(0.16, 0.16, 0.17), 0.08, rng)
	_speckle(15, Color(0.32, 0.32, 0.34), 20, rng)
	# 16 table top, 17 table side
	_fill(16, Color(0.66, 0.50, 0.28), 0.04, rng)
	for i in TILE:
		for k in [5, 10]:
			_px(16, k, i, Color(0.42, 0.30, 0.17))
			_px(16, i, k, Color(0.42, 0.30, 0.17))
	_copy(17, 13)
	for x in TILE:
		for y in 3:
			_px(17, x, y, Color(0.40, 0.28, 0.15))
	for x in range(5, 10):
		_px(17, x, 6, Color(0.62, 0.62, 0.65))
		_px(17, x, 7, Color(0.50, 0.50, 0.54))
	for y in range(8, 13):
		_px(17, 7, y, Color(0.45, 0.30, 0.15))
		_px(17, 8, y, Color(0.45, 0.30, 0.15))


# ------------------------------------------------------------------ items

static func _pattern(t: int, rows: Array, pal: Dictionary) -> void:
	for y in 8:
		var row: String = rows[y]
		for x in 8:
			var ch := row[x]
			if pal.has(ch):
				var c: Color = pal[ch]
				for dy in 2:
					for dx in 2:
						_px(t, x * 2 + dx, y * 2 + dy, c)


static func _items() -> void:
	var stick := Color(0.45, 0.30, 0.14)
	var guard := Color(0.35, 0.24, 0.12)
	_pattern(32, PAT_STICK, {"s": stick})
	_pattern(33, PAT_BLOB, {"b": Color(0.13, 0.13, 0.14)})
	_pattern(34, PAT_INGOT, {"b": Color(0.86, 0.86, 0.90)})
	_pattern(35, PAT_INGOT, {"b": Color(0.96, 0.80, 0.22)})
	_pattern(36, PAT_GEM, {"b": Color(0.35, 0.92, 0.92)})
	_pattern(37, PAT_APPLE, {"b": Color(0.82, 0.14, 0.14), "l": Color(0.25, 0.65, 0.2)})
	_pattern(38, PAT_BLOB, {"b": Color(0.52, 0.42, 0.28)})
	var mats := [Color(0.65, 0.48, 0.26), Color(0.58, 0.58, 0.60), Color(0.88, 0.88, 0.92), Color(0.35, 0.92, 0.92)]
	var pats := [PAT_PICK, PAT_AXE, PAT_SHOVEL, PAT_SWORD]
	for m in 4:
		for k in 4:
			_pattern(40 + m * 4 + k, pats[k], {"h": mats[m], "s": stick, "g": guard})


static func _make_moon() -> ImageTexture:
	var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in 16:
		for x in 16:
			var d := Vector2(x - 7.5, y - 7.5).length()
			if d <= 6.5:
				var c := Color(0.93, 0.94, 0.98)
				if (x * 7 + y * 13) % 11 == 0:
					c = Color(0.78, 0.80, 0.88)
				img.set_pixel(x, y, c)
	return ImageTexture.create_from_image(img)


# ------------------------------------------------------------------ queries

static func average(tile: int) -> Color:
	if _avg_cache.has(tile):
		return _avg_cache[tile]
	var r := 0.0
	var g := 0.0
	var b := 0.0
	var n := 0.0
	for y in TILE:
		for x in TILE:
			var c := _get(tile, x, y)
			if c.a > 0.5:
				r += c.r
				g += c.g
				b += c.b
				n += 1.0
	var out := Color(0.5, 0.5, 0.5)
	if n > 0.0:
		out = Color(r / n, g / n, b / n)
	_avg_cache[tile] = out
	return out


## Draws an item icon (and stack count) into a rectangle of any CanvasItem.
static func draw_item(ci: CanvasItem, r: Rect2, id: int, count: int, font: Font) -> void:
	if id == 0:
		return
	var t := Items.icon_tile(id)
	var src := Rect2((t & 15) * TILE, (t >> 4) * TILE, TILE, TILE)
	var pad := r.size.x * 0.12
	ci.draw_texture_rect_region(texture, r.grow(-pad), src)
	if count > 1:
		var fs := int(maxf(12.0, r.size.x * 0.28))
		var p := r.position + Vector2(0.0, r.size.y - 3.0)
		ci.draw_string(font, p + Vector2(1.5, 1.5), str(count), HORIZONTAL_ALIGNMENT_RIGHT, r.size.x - 3.0, fs, Color(0, 0, 0, 0.85))
		ci.draw_string(font, p, str(count), HORIZONTAL_ALIGNMENT_RIGHT, r.size.x - 4.0, fs, Color.WHITE)
