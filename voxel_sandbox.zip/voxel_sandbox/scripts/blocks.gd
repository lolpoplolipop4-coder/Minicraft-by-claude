class_name Blocks
extends RefCounted
## Block registry: ids, atlas tiles, hardness, tool requirements and drops.

const AIR := 0
const GRASS := 1
const DIRT := 2
const STONE := 3
const SAND := 4
const WOOD := 5
const LEAVES := 6
const WATER := 7
const COAL_ORE := 8
const IRON_ORE := 9
const GOLD_ORE := 10
const DIAMOND_ORE := 11
const PLANKS := 12
const COBBLE := 13
const BEDROCK := 14
const TABLE := 15
const FURNACE := 16
const GLASS := 17
const DOOR := 18
const SAPLING := 19
const BED := 20
const DOOR_OPEN := 21 # an opened door: walk-through, drawn as the door leaf seen edge-on
const TORCH := 22
const CHEST := 23
const LEVER := 24
const REDSTONE := 25
const RAIL := 26
const PISTON := 27
const ENCHANT_TABLE := 28
const BOOKSHELF := 29
const PRESSURE_PLATE := 30
const BUTTON := 31
const LEVER_ON := 32
const FARMLAND := 33
const FARMLAND_WET := 34
const COMPOSTER := 35
const WHEAT_SEEDLING := 36
const WHEAT_GROWING := 37
const WHEAT_RIPE := 38
const WHEAT_MATURE := 39
const COUNT := 40

const NAMES := ["Air", "Grass", "Dirt", "Stone", "Sand", "Log", "Leaves", "Water",
	"Coal Ore", "Iron Ore", "Gold Ore", "Diamond Ore", "Planks", "Cobblestone",
	"Bedrock", "Crafting Table", "Furnace", "Glass", "Door", "Sapling", "Bed", "Open Door", "Torch", "Chest", "Lever", "Redstone Dust", "Rail", "Piston", "Enchanting Table", "Bookshelf", "Pressure Plate", "Button", "Lever On", "Farmland", "Wet Farmland", "Composter", "Wheat Stage 1", "Wheat Stage 2", "Wheat Stage 3", "Wheat Mature"]

# Atlas tile indices per face group (see atlas.gd for the tile layout).
const TILE_TOP := [0, 0, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 26, 27, 26, 61, 62, 63, 64, 65, 66, 67]
const TILE_SIDE := [0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 26, 27, 26, 61, 62, 63, 64, 65, 66, 67]
const TILE_BOTTOM := [0, 2, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 13, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 26, 27, 26, 61, 62, 63, 64, 65, 66, 67]

# 1 = fully opaque cube (hides neighbouring faces). Air, leaves and water are see-through.
const OPAQUE := [0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0]

# Seconds to break by hand (-1 = unbreakable).
const HARDNESS := [0.0, 0.9, 0.75, 3.0, 0.75, 3.0, 0.3, 0.0, 4.5, 5.0, 5.0, 5.5, 2.5, 3.5, -1.0, 3.0, 3.5, 0.3, 1.2, 0.1, 0.5, 1.2, 0.2, 2.5, 0.4, 0.1, 0.5, 2.5, 3.5, 1.5, 0.4, 0.4, 0.4, 0.5, 0.5, 2.0, 0.0, 0.0, 0.0, 0.0]
# Preferred tool kind: 0 pickaxe, 1 axe, 2 shovel, -1 none.
const PREF_TOOL := [-1, 2, 2, 0, 2, 1, -1, -1, 0, 0, 0, 0, 1, 0, -1, 1, 0, -1, 1, -1, -1, 1, -1, 1, -1, -1, 0, 0, 1, 1, -1, -1, -1, 2, 2, 1, -1, -1, -1, -1]
# Minimum pickaxe tier needed to get a drop (-1 = anything works). 0 wood, 1 stone, 2 iron, 3 diamond.
const REQ_TIER := [-1, -1, -1, 0, -1, -1, -1, -1, 0, 1, 2, 2, -1, 0, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]
const TIER_SPEED := [2.0, 4.0, 6.0, 8.0]


static func is_solid(id: int) -> bool:
	return id != AIR and id != WATER and id != SAPLING and id != DOOR_OPEN and id != TORCH and id != LEVER and id != REDSTONE and id != RAIL and id != PRESSURE_PLATE and id != BUTTON and id != LEVER_ON and id != WHEAT_SEEDLING and id != WHEAT_GROWING and id != WHEAT_RIPE and id != WHEAT_MATURE


static func break_time(id: int, tool_id: int) -> float:
	var h: float = HARDNESS[id]
	if h < 0.0:
		return -1.0
	var kind := Items.tool_kind(tool_id)
	var tier := Items.tool_tier(tool_id)
	var pref: int = PREF_TOOL[id]
	var t := h
	if kind >= 0 and kind == pref:
		t = h / float(TIER_SPEED[tier])
	var req: int = REQ_TIER[id]
	if req >= 0 and (kind != 0 or tier < req):
		t *= 3.0
	return maxf(t, 0.1)


static func can_harvest(id: int, tool_id: int) -> bool:
	var req: int = REQ_TIER[id]
	if req < 0:
		return true
	return Items.tool_kind(tool_id) == 0 and Items.tool_tier(tool_id) >= req


## Item id that is dropped when this block is mined (0 = nothing).
static func drop_for(id: int) -> int:
	match id:
		GRASS:
			return DIRT
		STONE:
			return COBBLE
		COAL_ORE:
			return Items.COAL
		IRON_ORE:
			return IRON_ORE
		GOLD_ORE:
			return GOLD_ORE
		DIAMOND_ORE:
			return DIAMOND_ORE
		DOOR_OPEN:
			return DOOR
		WHEAT_SEEDLING, WHEAT_GROWING, WHEAT_RIPE:
			return Items.SEEDS
		WHEAT_MATURE:
			return Items.WHEAT
		TORCH:
			return TORCH
		LEAVES, WATER, AIR:
			return 0
	return id


static func particle_color(id: int) -> Color:
	return Atlas.average(TILE_SIDE[id])
