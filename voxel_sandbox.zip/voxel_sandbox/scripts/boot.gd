extends Control
## Minimal boot screen. Loads the actual 3D game as a separate scene so startup
## script/resource errors can be shown instead of leaving only the blue clear color.

const GAME_SCENE := "res://scenes/game.tscn"

var status_label: Label
var detail_label: Label
var progress_bar: ProgressBar
var retry_button: Button
var elapsed := 0.0
var loading_started := false
var failed := false

func _ready() -> void:
	_build_screen()
	_begin_loading()

func _build_screen() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color("#111827")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var box := VBoxContainer.new()
	box.custom_minimum_size = Vector2(300, 0)
	box.add_theme_constant_override("separation", 16)
	center.add_child(box)
	var title := Label.new()
	title.text = "VOXEL SANDBOX"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color("#facc15"))
	box.add_child(title)
	status_label = Label.new()
	status_label.text = "Запуск игры..."
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(status_label)
	progress_bar = ProgressBar.new()
	progress_bar.custom_minimum_size = Vector2(280, 18)
	progress_bar.min_value = 0.0
	progress_bar.max_value = 100.0
	progress_bar.value = 0.0
	box.add_child(progress_bar)
	detail_label = Label.new()
	detail_label.text = "Подготовка ресурсов"
	detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	detail_label.add_theme_color_override("font_color", Color("#cbd5e1"))
	box.add_child(detail_label)
	retry_button = Button.new()
	retry_button.text = "Повторить загрузку"
	retry_button.visible = false
	retry_button.pressed.connect(_retry_loading)
	box.add_child(retry_button)

func _begin_loading() -> void:
	elapsed = 0.0
	failed = false
	loading_started = true
	retry_button.visible = false
	status_label.text = "Загрузка игры..."
	detail_label.text = "Если возникнет ошибка, она появится здесь вместо синего экрана."
	progress_bar.value = 0.0
	var err := ResourceLoader.load_threaded_request(GAME_SCENE, "PackedScene", true)
	if err != OK:
		_show_failure("Не удалось начать загрузку сцены.", "Код ошибки ResourceLoader: %d" % err)

func _process(delta: float) -> void:
	if not loading_started or failed:
		return
	elapsed += delta
	var progress: Array = []
	var load_status := ResourceLoader.load_threaded_get_status(GAME_SCENE, progress)
	if not progress.is_empty():
		progress_bar.value = float(progress[0]) * 100.0
	match load_status:
		ResourceLoader.THREAD_LOAD_LOADED:
			loading_started = false
			status_label.text = "Запускаем 3D-мир..."
			var packed := ResourceLoader.load_threaded_get(GAME_SCENE) as PackedScene
			if packed == null:
				_show_failure("Сцена игры загрузилась, но не является PackedScene.", "Проверь scenes/game.tscn и прикреплённый к нему scripts/main.gd.")
			else:
				var err := get_tree().change_scene_to_packed(packed)
				if err != OK:
					_show_failure("Не удалось открыть игровую сцену.", "Код change_scene_to_packed: %d" % err)
		ResourceLoader.THREAD_LOAD_FAILED:
			_show_failure("Godot не смог загрузить игровую сцену.", "Открой в редакторе Debugger → Errors и пришли скриншот ошибок. Частая причина — ошибка GDScript или неимпортированный ресурс.")
		ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
			_show_failure("Игровая сцена не найдена или недоступна.", "Ожидался файл: " + GAME_SCENE)
		_:
			if elapsed > 45.0:
				_show_failure("Загрузка длится слишком долго (45 секунд).", "Это не подтверждает причину сбоя. Открой Debugger → Errors в Godot и пришли скриншот.")

func _show_failure(message: String, details: String) -> void:
	failed = true
	loading_started = false
	status_label.text = message
	status_label.add_theme_color_override("font_color", Color("#fca5a5"))
	detail_label.text = details
	progress_bar.visible = false
	retry_button.visible = true
	push_error("Voxel Sandbox boot: %s | %s" % [message, details])

func _retry_loading() -> void:
	progress_bar.visible = true
	_begin_loading()
