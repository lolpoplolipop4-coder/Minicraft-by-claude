class_name Crafting
extends RefCounted
## Recipe book. Shown as a tap-to-craft list. Tool recipes need a nearby Crafting Table.

static var _cache: Array = []


static func recipes() -> Array:
	if not _cache.is_empty():
		return _cache
	_add(Blocks.PLANKS, 4, {Blocks.WOOD: 1}, false)
	_add(Items.STICK, 4, {Blocks.PLANKS: 2}, false)
	_add(Blocks.TABLE, 1, {Blocks.PLANKS: 4}, false)
	_add(Blocks.FURNACE, 1, {Blocks.COBBLE: 8}, true, "table")
	_add(Blocks.CHEST, 1, {Blocks.PLANKS: 8}, true, "table")
	_add(Blocks.DOOR, 1, {Blocks.PLANKS: 6}, true, "table")
	_add(Blocks.GLASS, 4, {Blocks.SAND: 1, Items.COAL: 1}, true, "furnace")
	_add(Blocks.SAPLING, 1, {Blocks.LEAVES: 2}, false)
	_add(Blocks.BED, 1, {Items.WOOL: 3, Blocks.PLANKS: 3}, true, "table")
	_add(Blocks.TORCH, 4, {Items.COAL: 1, Items.STICK: 1}, true, "table")
	_add(Items.COOKED_MEAT, 1, {Items.FLESH: 1, Items.COAL: 1}, true, "furnace")
	_add(Items.IRON_INGOT, 1, {Blocks.IRON_ORE: 1, Items.COAL: 1}, true, "furnace")
	_add(Items.GOLD_INGOT, 1, {Blocks.GOLD_ORE: 1, Items.COAL: 1}, true, "furnace")
	_add(Items.DIAMOND, 1, {Blocks.DIAMOND_ORE: 1, Items.COAL: 1}, true, "furnace")
	var mats := [Blocks.PLANKS, Blocks.COBBLE, Items.IRON_INGOT, Items.DIAMOND]
	for m in 4:
		_add(Items.tool_id(m, 0), 1, {mats[m]: 3, Items.STICK: 2}, true)
		_add(Items.tool_id(m, 1), 1, {mats[m]: 3, Items.STICK: 2}, true)
		_add(Items.tool_id(m, 2), 1, {mats[m]: 1, Items.STICK: 2}, true)
		_add(Items.tool_id(m, 3), 1, {mats[m]: 2, Items.STICK: 1}, true)
	return _cache


static func _add(out: int, n: int, ing: Dictionary, table: bool, station: String = "") -> void:
	_cache.append({"out": out, "n": n, "ing": ing, "table": table, "station": station})


static func can_craft(inv: Inventory, r: Dictionary, near_table: bool, near_furnace: bool = false) -> bool:
	if r["table"] and not near_table and str(r.get("station", "")) != "furnace":
		return false
	if str(r.get("station", "")) == "furnace" and not near_furnace:
		return false
	var ing: Dictionary = r["ing"]
	for id in ing:
		if inv.count_of(int(id)) < int(ing[id]):
			return false
	# Simulate on a copy so we know the result will actually fit.
	var sim := Inventory.new()
	sim.ids = inv.ids.duplicate()
	sim.counts = inv.counts.duplicate()
	for id in ing:
		sim.remove(int(id), int(ing[id]))
	return sim.free_space_for(int(r["out"])) >= int(r["n"])


static func craft(inv: Inventory, r: Dictionary, near_table: bool, near_furnace: bool = false) -> bool:
	if not can_craft(inv, r, near_table, near_furnace):
		return false
	var ing: Dictionary = r["ing"]
	for id in ing:
		inv.remove(int(id), int(ing[id]))
	inv.add(int(r["out"]), int(r["n"]))
	return true
