class_name GenLog
extends RefCounted
## Thread-safe diagnostic log (chunk generation, meshing, task errors, timings, memory).
##
## * Every line is flushed immediately, so after a native crash (SIGSEGV) the LAST
##   "begin" line without a matching "done" shows which chunk / phase was running.
## * Also printed to the engine log:  adb logcat -s godot
## * Files (app-private storage, user://):  logs/chunkgen.log (current run),
##   logs/chunkgen.prev.log (previous run), logs/chunkgen.crash.log (kept when the
##   previous run died while loading).
## * Contains only engine/OS name, CPU count, chunk coordinates, timings and memory
##   numbers - no account, location, device-ID or personal data.
## Must be touched once on the main thread (start_session) before workers use it.

const DIR := "user://logs"
const PATH := "user://logs/chunkgen.log"
const PREV := "user://logs/chunkgen.prev.log"
const CRASH := "user://logs/chunkgen.crash.log"
const GUARD := "user://load_guard.flag"
const MAX_BYTES := 600000

static var _mutex := Mutex.new()
static var _file: FileAccess = null
static var _bytes := 0
static var _t0 := 0
static var previous_crash := false
static var guard_on := false


static func start_session() -> void:
	_t0 = Time.get_ticks_msec()
	DirAccess.make_dir_recursive_absolute(DIR)
	previous_crash = FileAccess.file_exists(GUARD)
	var d := DirAccess.open(DIR)
	if d != null and d.file_exists("chunkgen.log"):
		if d.file_exists("chunkgen.prev.log"):
			d.remove("chunkgen.prev.log")
		d.rename("chunkgen.log", "chunkgen.prev.log")
		if previous_crash:
			if d.file_exists("chunkgen.crash.log"):
				d.remove("chunkgen.crash.log")
			d.copy(PREV, CRASH)
	_mutex.lock()
	_file = FileAccess.open(PATH, FileAccess.WRITE)
	_bytes = 0
	_mutex.unlock()
	info("session", "start godot=%s os=%s cpus=%d debug=%s previous_run_crashed_while_loading=%s" % [
		Engine.get_version_info().get("string", "?"), OS.get_name(), OS.get_processor_count(),
		str(OS.is_debug_build()), str(previous_crash)])


static func mem_mb() -> float:
	return float(OS.get_static_memory_usage()) / 1048576.0


static func peak_mb() -> float:
	return float(OS.get_static_memory_peak_usage()) / 1048576.0


static func info(tag: String, msg: String) -> void:
	_write("I", tag, msg)


static func warn(tag: String, msg: String) -> void:
	_write("W", tag, msg)


static func error(tag: String, msg: String) -> void:
	_write("E", tag, msg)


static func _write(level: String, tag: String, msg: String) -> void:
	var line := "%7d [%s][t%d] %s: %s" % [Time.get_ticks_msec() - _t0, level, OS.get_thread_caller_id(), tag, msg]
	print("[VOXEL] ", line)
	_mutex.lock()
	if _file != null:
		_file.store_line(line)
		_file.flush()
		_bytes += line.length() + 1
		if _bytes > MAX_BYTES:
			_file.close()
			_file = FileAccess.open(PATH, FileAccess.WRITE)
			_bytes = 0
			if _file != null:
				_file.store_line("--- log truncated (size cap) ---")
	_mutex.unlock()


## The guard file exists while a world is loading / just started. If it is still there
## at the next launch, the previous run died during that time.
static func set_guard(on: bool) -> void:
	guard_on = on
	if on:
		var f := FileAccess.open(GUARD, FileAccess.WRITE)
		if f != null:
			f.store_string("1")
			f.close()
	else:
		var d := DirAccess.open("user://")
		if d != null and d.file_exists("load_guard.flag"):
			d.remove("load_guard.flag")


## Last `n` lines of a log file (for the in-game Diagnostics screen).
static func tail(path: String, n: int) -> String:
	if not FileAccess.file_exists(path):
		return "(no log yet)"
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return "(cannot open log)"
	var lines: PackedStringArray = f.get_as_text().split("\n", false)
	f.close()
	var start := maxi(0, lines.size() - n)
	return "\n".join(lines.slice(start))
