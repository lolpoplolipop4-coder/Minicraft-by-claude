class_name HUD
extends Control
## All touch controls are drawn and hit-tested here, with per-finger tracking so
## the joystick, camera drag and buttons work simultaneously and never fight:
##   * Left 40% of the screen (outside buttons): floating virtual joystick
##   * Everywhere else that is not a button / hotbar slot: camera look
## Layout is computed from the viewport size, so any aspect ratio works.

signal inventory_pressed
signal menu_pressed
signal respawn_pressed

const HEART := ["..##.##..", ".#######.", ".#######.", "..#####..", "...###...", "....#...."]
const FOOD := ["...###...", "..#####..", "..#####..", "...###...", "....#....", "...##...."]
const STICK_R := 90.0

var active := false
var modal := false
var dead := false
var underwater := false
var hurt_flash := 0.0

var move_vec := Vector2.ZERO
var jump_held := false
var sneak_held := false
var sprint_on := false
var break_held := false
var place_held := false

var inv: Inventory
var player: Node # the Player (duck-typed to avoid a class cycle)

var _look_accum := Vector2.ZERO
var _place_tap := false
var _fingers: Dictionary = {}
var _stick_id := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _btn: Dictionary = {}
var _top: Dictionary = {}
var _hotbar: Array[Rect2] = []
var _last_size := Vector2.ZERO
var _font: Font
var _toast := ""
var _toast_t := 0.0


func _ready() -> void:
	_font = ThemeDB.fallback_font
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func consume_look() -> Vector2:
	var v := _look_accum
	_look_accum = Vector2.ZERO
	return v


func consume_place_tap() -> bool:
	var t := _place_tap
	_place_tap = false
	return t


func show_toast(text: String) -> void:
	_toast = text
	_toast_t = 2.2



func reset_inputs() -> void:
	_fingers.clear()
	_stick_id = -1
	move_vec = Vector2.ZERO
	jump_held = false
	sneak_held = false
	break_held = false
	place_held = false
	_look_accum = Vector2.ZERO
	_place_tap = false


# ------------------------------------------------------------------ layout

func _layout() -> void:
	var w := size.x
	var h := size.y
	var m := maxf(36.0, w * 0.03) # keeps buttons clear of rounded corners / notches
	_btn = {
		"break": {"c": Vector2(w - m - 100.0, h - 150.0), "r": 66.0, "label": "BREAK"},
		"jump": {"c": Vector2(w - m - 100.0, h - 295.0), "r": 52.0, "label": "JUMP"},
		"place": {"c": Vector2(w - m - 245.0, h - 105.0), "r": 52.0, "label": "PLACE"},
		"sprint": {"c": Vector2(w - m - 245.0, h - 235.0), "r": 42.0, "label": "RUN"},
		"sneak": {"c": Vector2(w - m - 365.0, h - 175.0), "r": 42.0, "label": "SNEAK"},
	}
	_top = {
		"bag": Rect2(w - m - 120.0, 16.0, 120.0, 54.0),
		"menu": Rect2(w - m - 250.0, 16.0, 120.0, 54.0),
	}
	_hotbar.clear()
	var slot := 58.0
	var gap := 5.0
	var total := 9.0 * slot + 8.0 * gap
	var x0 := (w - total) * 0.5
	for i in 9:
		_hotbar.append(Rect2(x0 + i * (slot + gap), h - slot - 14.0, slot, slot))


func _process(delta: float) -> void:
	if size != _last_size:
		_last_size = size
		_layout()
	_toast_t -= delta
	queue_redraw()


# ------------------------------------------------------------------ input

func _input(event: InputEvent) -> void:
	if not active or modal:
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			_on_press(t.index, t.position)
		else:
			_on_release(t.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_on_drag(d.index, d.position, d.relative)


func _on_press(idx: int, p: Vector2) -> void:
	if dead:
		respawn_pressed.emit()
		return
	for key in _btn:
		var b: Dictionary = _btn[key]
		if p.distance_to(b["c"]) <= float(b["r"]) + 12.0:
			_fingers[idx] = str(key)
			_set_btn(str(key), true)
			return
	for key in _top:
		var r: Rect2 = _top[key]
		if r.grow(6.0).has_point(p):
			_fingers[idx] = "top"
			if key == "bag":
				inventory_pressed.emit()
			else:
				menu_pressed.emit()
			return
	for i in _hotbar.size():
		if _hotbar[i].grow(3.0).has_point(p):
			_fingers[idx] = "hotbar"
			if inv != null:
				inv.selected = i
				inv.changed.emit()
				var nm := Items.item_name(inv.ids[i])
				if nm != "":
					show_toast(nm)
			return
	if p.x < size.x * 0.4 and p.y > size.y * 0.15 and _stick_id == -1:
		_stick_id = idx
		_stick_origin = p
		_stick_pos = p
		_fingers[idx] = "stick"
		return
	_fingers[idx] = "look"


func _on_drag(idx: int, p: Vector2, rel: Vector2) -> void:
	var role: String = _fingers.get(idx, "")
	if role == "stick":
		var d := p - _stick_origin
		if d.length() > STICK_R:
			_stick_origin += d.normalized() * (d.length() - STICK_R) # base follows the thumb
		_stick_pos = p
		var v := (p - _stick_origin) / STICK_R
		move_vec = v if v.length() > 0.12 else Vector2.ZERO
	elif role == "look":
		_look_accum += rel


func _on_release(idx: int) -> void:
	var role: String = _fingers.get(idx, "")
	_fingers.erase(idx)
	if role == "stick":
		_stick_id = -1
		move_vec = Vector2.ZERO
	elif role != "" and _btn.has(role):
		_set_btn(role, false)


func _set_btn(key: String, down: bool) -> void:
	match key:
		"break":
			break_held = down
		"jump":
			jump_held = down
		"place":
			place_held = down
			if down:
				_place_tap = true
		"sneak":
			sneak_held = down
		"sprint":
			if down:
				sprint_on = not sprint_on


# ------------------------------------------------------------------ drawing

func _draw() -> void:
	if not active:
		return
	var w := size.x
	var h := size.y
	if modal:
		return
	if underwater:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.1, 0.3, 0.6, 0.35))
	if hurt_flash > 0.0:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.8, 0.0, 0.0, hurt_flash * 0.6))

	# crosshair
	var c := size * 0.5
	draw_line(c + Vector2(-11, 0), c + Vector2(11, 0), Color(0, 0, 0, 0.6), 4.0)
	draw_line(c + Vector2(0, -11), c + Vector2(0, 11), Color(0, 0, 0, 0.6), 4.0)
	draw_line(c + Vector2(-10, 0), c + Vector2(10, 0), Color(1, 1, 1, 0.9), 2.0)
	draw_line(c + Vector2(0, -10), c + Vector2(0, 10), Color(1, 1, 1, 0.9), 2.0)

	# joystick (faint ring when idle, follows the thumb when active)
	if _stick_id == -1:
		var idle := Vector2(maxf(36.0, w * 0.03) + 170.0, h - 170.0)
		draw_arc(idle, STICK_R, 0.0, TAU, 40, Color(1, 1, 1, 0.22), 4.0)
	else:
		draw_circle(_stick_origin, STICK_R, Color(1, 1, 1, 0.14))
		draw_arc(_stick_origin, STICK_R, 0.0, TAU, 40, Color(1, 1, 1, 0.45), 4.0)
		var knob := _stick_origin + (_stick_pos - _stick_origin).limit_length(STICK_R)
		draw_circle(knob, 38.0, Color(1, 1, 1, 0.45))

	for key in _btn:
		var b: Dictionary = _btn[key]
		var down := false
		match str(key):
			"break":
				down = break_held
			"jump":
				down = jump_held
			"place":
				down = place_held
			"sneak":
				down = sneak_held
			"sprint":
				down = sprint_on
		var bc: Vector2 = b["c"]
		var r: float = b["r"]
		draw_circle(bc, r, Color(1, 1, 1, 0.38 if down else 0.16))
		draw_arc(bc, r, 0.0, TAU, 40, Color(1, 1, 1, 0.6), 3.0)
		var fs := 18 if r > 50.0 else 15
		draw_string(_font, bc + Vector2(-r, fs * 0.35), str(b["label"]), HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color(1, 1, 1, 0.95))

	for key in _top:
		var rr: Rect2 = _top[key]
		draw_rect(rr, Color(0, 0, 0, 0.45))
		draw_rect(rr, Color(1, 1, 1, 0.55), false, 2.0)
		draw_string(_font, rr.position + Vector2(0, 34), "BAG" if key == "bag" else "MENU", HORIZONTAL_ALIGNMENT_CENTER, rr.size.x, 20, Color.WHITE)

	# hotbar
	if inv != null:
		for i in _hotbar.size():
			var sr := _hotbar[i]
			draw_rect(sr, Color(0, 0, 0, 0.5))
			draw_rect(sr, Color(1, 1, 1, 0.9) if i == inv.selected else Color(1, 1, 1, 0.25), false, 4.0 if i == inv.selected else 2.0)
			Atlas.draw_item(self, sr, inv.ids[i], inv.counts[i], _font)

	# vitals
	if player != null and not player.creative and not _hotbar.is_empty():
		var left := _hotbar[0].position.x
		var right := _hotbar[8].end.x
		var vy := _hotbar[0].position.y - 30.0
		for i in 10:
			_draw_pip(Vector2(left + i * 27.0, vy), HEART, player.health, i, Color(0.88, 0.12, 0.15))
			_draw_pip(Vector2(right - (i + 1) * 27.0 + 2.0, vy), FOOD, player.hunger, i, Color(0.85, 0.55, 0.15))

	if _toast_t > 0.0 and _toast != "":
		var a := clampf(_toast_t, 0.0, 1.0)
		draw_string(_font, Vector2(0, h - 128.0 + 2.0), _toast, HORIZONTAL_ALIGNMENT_CENTER, w, 24, Color(0, 0, 0, a))
		draw_string(_font, Vector2(0, h - 128.0), _toast, HORIZONTAL_ALIGNMENT_CENTER, w, 24, Color(1, 1, 1, a))

	if dead:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.5, 0.0, 0.0, 0.55))
		draw_string(_font, Vector2(0, h * 0.45), "You died", HORIZONTAL_ALIGNMENT_CENTER, w, 64, Color.WHITE)
		draw_string(_font, Vector2(0, h * 0.45 + 50.0), "Tap to respawn", HORIZONTAL_ALIGNMENT_CENTER, w, 28, Color(1, 1, 1, 0.9))


func _draw_pip(pos: Vector2, pattern: Array, value: float, i: int, col: Color) -> void:
	var cell := 2.6
	var full := value >= (i + 1) * 2.0
	var half := not full and value >= i * 2.0 + 1.0
	for y in pattern.size():
		var row: String = pattern[y]
		for x in row.length():
			if row[x] != "#":
				continue
			var c := Color(0.15, 0.02, 0.02, 0.65)
			if full or (half and x < 5):
				c = col
			draw_rect(Rect2(pos + Vector2(x, y) * cell, Vector2(cell + 0.4, cell + 0.4)), c)
