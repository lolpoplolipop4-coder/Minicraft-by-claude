class_name Inventory
extends RefCounted
## 36 slots. Slots 0-8 are the hotbar.

signal changed

const SLOTS := 36

var ids := PackedInt32Array()
var counts := PackedInt32Array()
var selected := 0


func _init() -> void:
	ids.resize(SLOTS)
	counts.resize(SLOTS)


func held_id() -> int:
	return ids[selected]


func count_of(id: int) -> int:
	var n := 0
	for i in SLOTS:
		if ids[i] == id:
			n += counts[i]
	return n


func has(id: int, n: int) -> bool:
	return count_of(id) >= n


func free_space_for(id: int) -> int:
	var maxs := Items.max_stack(id)
	var space := 0
	for i in SLOTS:
		if ids[i] == 0:
			space += maxs
		elif ids[i] == id:
			space += maxs - counts[i]
	return space


## Adds items; returns how many did NOT fit.
func add(id: int, n: int) -> int:
	if id == 0 or n <= 0:
		return 0
	var maxs := Items.max_stack(id)
	for i in SLOTS:
		if n <= 0:
			break
		if ids[i] == id and counts[i] < maxs:
			var t := mini(n, maxs - counts[i])
			counts[i] += t
			n -= t
	for i in SLOTS:
		if n <= 0:
			break
		if ids[i] == 0:
			var t := mini(n, maxs)
			ids[i] = id
			counts[i] = t
			n -= t
	changed.emit()
	return n


func remove(id: int, n: int) -> bool:
	if count_of(id) < n:
		return false
	for i in range(SLOTS - 1, -1, -1):
		if n <= 0:
			break
		if ids[i] == id:
			var t := mini(n, counts[i])
			counts[i] -= t
			n -= t
			if counts[i] <= 0:
				ids[i] = 0
				counts[i] = 0
	changed.emit()
	return true


func consume_held() -> void:
	if ids[selected] == 0:
		return
	counts[selected] -= 1
	if counts[selected] <= 0:
		ids[selected] = 0
		counts[selected] = 0
	changed.emit()


func move(a: int, b: int) -> void:
	if a == b or ids[a] == 0:
		return
	if ids[b] == ids[a]:
		var maxs := Items.max_stack(ids[a])
		var t := mini(counts[a], maxs - counts[b])
		counts[b] += t
		counts[a] -= t
		if counts[a] <= 0:
			ids[a] = 0
			counts[a] = 0
	else:
		var ti := ids[a]
		var tc := counts[a]
		ids[a] = ids[b]
		counts[a] = counts[b]
		ids[b] = ti
		counts[b] = tc
	changed.emit()


func to_dict() -> Dictionary:
	return {"ids": ids.duplicate(), "counts": counts.duplicate(), "sel": selected}


func from_dict(d: Dictionary) -> void:
	var i2: PackedInt32Array = d.get("ids", PackedInt32Array())
	var c2: PackedInt32Array = d.get("counts", PackedInt32Array())
	if i2.size() == SLOTS and c2.size() == SLOTS:
		ids = i2.duplicate()
		counts = c2.duplicate()
	selected = clampi(int(d.get("sel", 0)), 0, 8)
	changed.emit()
