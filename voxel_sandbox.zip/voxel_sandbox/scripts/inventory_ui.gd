class_name InventoryUI
extends Control
## Inventory grid (tap a slot, then tap another to move/swap/merge) and a
## tap-to-craft recipe list. Tool recipes need a Crafting Table within 4 blocks.

signal closed

var inv: Inventory
var near_table := false
var near_furnace := false
var station_mode := "bag"
var _picked := -1
var _slot_rects: Array[Rect2] = []
var _recipe_rects: Array[Rect2] = []
var _recipes: Array = []
var _panel := Rect2()
var _close := Rect2()
var _font: Font
var _last_size := Vector2.ZERO
var creative := false
var _cat_rects: Array[Rect2] = []
var _cat_ids: Array[int] = []
var _cat_heads: Array = []
var _clear_rect := Rect2()
var _cat_prev := Rect2()
var _cat_next := Rect2()
var _cat_page := 0
var _cat_page_size := 24
var _catalog_ids: Array[int] = []
var _opened_ms := 0
var _touch_start := Vector2.ZERO
var _touch_active := false
var _station_page := 0
var _station_page_size := 8
var _station_prev := Rect2()
var _station_next := Rect2()


func _ready() -> void:
	_font = ThemeDB.fallback_font
	_recipes = Crafting.recipes()
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false


func open(i: Inventory, table: bool, creative_mode: bool = false, furnace: bool = false, mode: String = "bag") -> void:
	inv = i
	station_mode = mode
	creative = creative_mode
	near_table = table
	near_furnace = furnace
	var all_recipes := Crafting.recipes()
	_recipes = []
	for rec in all_recipes:
		var out_id := int(rec["out"])
		var station := str(rec.get("station", ""))
		if mode == "bag":
			if out_id in [Blocks.PLANKS, Items.STICK, Blocks.TABLE]: _recipes.append(rec)
		elif mode == "table":
			if bool(rec["table"]) and station != "furnace": _recipes.append(rec)
		elif mode == "furnace":
			if station == "furnace": _recipes.append(rec)
		elif mode == "chest":
			pass
	_picked = -1
	_cat_page = 0
	_station_page = 0
	_opened_ms = Time.get_ticks_msec()
	visible = true
	_last_size = Vector2.ZERO
	queue_redraw()


func close() -> void:
	visible = false
	closed.emit()


func _layout() -> void:
	var w := size.x
	var h := size.y
	# Keep the panel inside even short/narrow phone screens.
	var pw := clampf(w - 16.0, 1.0, 1180.0)
	var ph := clampf(h - 16.0, 1.0, 760.0)
	_panel = Rect2((w - pw) * 0.5, (h - ph) * 0.5, pw, ph)
	_close = Rect2(_panel.end.x - 52.0, _panel.position.y + 8.0, 42.0, 42.0)
	_slot_rects.clear()
	_slot_rects.resize(Inventory.SLOTS)
	_recipe_rects.clear()
	_cat_rects.clear()
	_cat_ids.clear()
	_cat_heads.clear()
	_catalog_ids.clear()
	_clear_rect = Rect2()
	_cat_prev = Rect2()
	_cat_next = Rect2()
	if creative:
		for sec in _catalog_sections():
			for cid in sec["ids"]:
				_catalog_ids.append(int(cid))
		var cols := clampi(floori((pw - 32.0) / 66.0), 3, 10)
		var cell := minf(58.0, (pw - 32.0 - float(cols - 1) * 5.0) / float(cols))
		var gap := 5.0
		var top := _panel.position.y + 72.0
		var bottom_space := 62.0
		var rows := maxi(1, floori((_panel.end.y - top - bottom_space) / (cell + gap)))
		_cat_page_size = cols * rows
		var max_page := maxi(0, ceili(float(_catalog_ids.size()) / float(_cat_page_size)) - 1)
		_cat_page = clampi(_cat_page, 0, max_page)
		for j in range(_cat_page * _cat_page_size, mini((_cat_page + 1) * _cat_page_size, _catalog_ids.size())):
			var k := j - _cat_page * _cat_page_size
			var col := k % cols
			var row := k / cols
			_cat_rects.append(Rect2(_panel.position.x + 16.0 + col * (cell + gap), top + row * (cell + gap), cell, cell))
			_cat_ids.append(_catalog_ids[j])
		_cat_prev = Rect2(_panel.position.x + 16.0, _panel.end.y - 48.0, 100.0, 36.0)
		_cat_next = Rect2(_panel.end.x - 116.0, _panel.end.y - 48.0, 100.0, 36.0)
		_clear_rect = Rect2(_panel.position.x + 126.0, _panel.end.y - 48.0, 140.0, 36.0)
		return
	if station_mode == "table" or station_mode == "furnace":
		var top := _panel.position.y + 76.0
		var bottom := _panel.end.y - 58.0
		var row_h := 56.0
		var gap_y := 5.0
		_station_page_size = maxi(1, floori((bottom - top + gap_y) / (row_h + gap_y)) * 2)
		var max_page := maxi(0, ceili(float(_recipes.size()) / float(_station_page_size)) - 1)
		_station_page = clampi(_station_page, 0, max_page)
		var card_w := (_panel.size.x - 36.0) / 2.0
		for j in range(_station_page * _station_page_size, mini((_station_page + 1) * _station_page_size, _recipes.size())):
			var k := j - _station_page * _station_page_size
			var col := k % 2
			var row := k / 2
			_recipe_rects.append(Rect2(_panel.position.x + 12.0 + col * (card_w + 8.0), top + row * (row_h + gap_y), card_w, row_h))
		_station_prev = Rect2(_panel.position.x + 12.0, _panel.end.y - 48.0, 104.0, 36.0)
		_station_next = Rect2(_panel.end.x - 116.0, _panel.end.y - 48.0, 104.0, 36.0)
		return
	var slot := 48.0
	var gap := 4.0
	var gx := _panel.position.x + 16.0
	var gy := _panel.position.y + 70.0
	for i in Inventory.SLOTS:
		var row: int
		var col: int
		if i < 9:
			row = 3
			col = i
		else:
			row = (i - 9) / 9
			col = (i - 9) % 9
		var y := gy + row * (slot + gap) + (10.0 if row == 3 else 0.0)
		_slot_rects[i] = Rect2(gx + col * (slot + gap), y, slot, slot)
	var rx := gx + 9.0 * (slot + gap) + 24.0
	var cw := maxf(70.0, (_panel.end.x - 16.0 - rx - 12.0) / 3.0)
	for k in _recipes.size():
		var col2 := k % 3
		var row2 := k / 3
		_recipe_rects.append(Rect2(rx + col2 * (cw + 5.0), gy + row2 * 42.0, cw, 38.0))


## Creative catalog: every block (except water), every item and every tool, by category.
func _catalog_sections() -> Array:
	var blocks: Array = []
	# Include every placeable block, including water and the open door variant.
	for bid in range(1, Blocks.COUNT):
		blocks.append(bid)
	var items: Array = [
		Items.STICK, Items.COAL, Items.IRON_INGOT, Items.GOLD_INGOT,
		Items.DIAMOND, Items.APPLE, Items.FLESH, Items.WOOL, Items.FEATHER,
		Items.COOKED_MEAT, Items.FISH, Items.COOKED_FISH, Items.FISHING_ROD,
		Items.BOW, Items.ARROW, Items.MINECART, Items.BOAT, Items.BOOK,
		Items.ENCHANTED_BOOK, Items.EXPERIENCE_BOTTLE, Items.EMERALD,
		Items.ENDER_PEARL, Items.NETHER_STAR, Items.QUARTZ, Items.LAPIS,
		Items.BLAZE_ROD, Items.SLIMEBALL, Items.BONE, Items.STRING, Items.SUGAR_CANE
	]
	var tools: Array = []
	for t in range(16):
		tools.append(Items.TOOL_BASE + t)
	return [{"title": "Блоки", "ids": blocks}, {"title": "Предметы", "ids": items}, {"title": "Инструменты", "ids": tools}]


func _yes_no(v: bool) -> String:
	return "YES" if v else "NO"


func _gui_input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT and mb.pressed:
			_tap(mb.position)
			accept_event()
		elif creative and mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_change_page(1)
			accept_event()
		elif creative and mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_change_page(-1)
			accept_event()
	elif event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			_touch_start = touch.position
			_touch_active = true
		else:
			if _touch_active and (creative or station_mode == "table" or station_mode == "furnace"):
				var delta_y := touch.position.y - _touch_start.y
				if absf(delta_y) >= 36.0 and _panel.has_point(_touch_start):
					_change_page(1 if delta_y < 0.0 else -1)
			_touch_active = false
		accept_event()


func _change_page(direction: int) -> void:
	if creative:
		var max_page := maxi(0, ceili(float(_catalog_ids.size()) / float(maxi(1, _cat_page_size))) - 1)
		var next_page := clampi(_cat_page + direction, 0, max_page)
		if next_page != _cat_page:
			_cat_page = next_page
			_layout()
			queue_redraw()
	elif station_mode == "table" or station_mode == "furnace":
		var max_station_page := maxi(0, ceili(float(_recipes.size()) / float(maxi(1, _station_page_size))) - 1)
		var next_station_page := clampi(_station_page + direction, 0, max_station_page)
		if next_station_page != _station_page:
			_station_page = next_station_page
			_layout()
			queue_redraw()


func _tap(p: Vector2) -> void:
	# Ignore the emulated mouse event of the very touch that opened this screen.
	if Time.get_ticks_msec() - _opened_ms < 300:
		return
	if _close.grow(8.0).has_point(p) or not _panel.has_point(p):
		close()
		return
	if station_mode == "table" or station_mode == "furnace":
		if _station_prev.has_point(p):
			_change_page(-1)
			return
		if _station_next.has_point(p):
			_change_page(1)
			return
		for k in _recipe_rects.size():
			if _recipe_rects[k].has_point(p):
				Crafting.craft(inv, _recipes[_station_page * _station_page_size + k], near_table, near_furnace)
				queue_redraw()
				return
		return
	if creative:
		if _cat_prev.has_point(p):
			_change_page(-1)
			return
		if _cat_next.has_point(p):
			_change_page(1)
			return
		if _clear_rect.has_point(p):
			inv.ids[inv.selected] = 0
			inv.counts[inv.selected] = 0
			inv.changed.emit()
			queue_redraw()
			return
		for k in _cat_rects.size():
			if _cat_rects[k].has_point(p):
				var cid := _cat_ids[k]
				inv.ids[inv.selected] = cid
				inv.counts[inv.selected] = Items.max_stack(cid)
				inv.changed.emit()
				queue_redraw()
				return
		return
	for i in _slot_rects.size():
		if _slot_rects[i].has_point(p):
			if _picked == -1:
				if inv.ids[i] != 0:
					_picked = i
			elif _picked == i:
				_picked = -1
			else:
				inv.move(_picked, i)
				_picked = -1
			queue_redraw()
			return
	else:
		for k in _recipe_rects.size():
			if _recipe_rects[k].has_point(p):
				Crafting.craft(inv, _recipes[k], near_table, near_furnace)
				queue_redraw()
				return
	queue_redraw()


func _process(_d: float) -> void:
	if visible and size != _last_size:
		_last_size = size
		_layout()
		queue_redraw()


func _draw() -> void:
	if not visible or inv == null or _slot_rects.is_empty():
		return
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.55))
	draw_rect(_panel, Color(0.12, 0.14, 0.2, 0.97))
	draw_rect(_panel, Color(1, 1, 1, 0.5), false, 3.0)
	var px := _panel.position.x
	var py := _panel.position.y
	var title := "Инвентарь"
	match station_mode:
		"table": title = "Верстак · крафты"
		"furnace": title = "Печь · плавка и готовка"
		"chest": title = "Сундук деревни · добыча"
	draw_string(_font, Vector2(px + 24.0, py + 46.0), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color.WHITE)
	if not _recipe_rects.is_empty():
		draw_string(_font, Vector2(_recipe_rects[0].position.x, py + 46.0), ("Креатив: каталог (нажмите - предмет в выбранный слот)" if creative else "Нажми на рецепт, чтобы создать предмет"), HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 1, 1, 0.9))
	draw_rect(_close, Color(0.6, 0.15, 0.15, 0.9))
	draw_string(_font, _close.position + Vector2(0, 29.0), "X", HORIZONTAL_ALIGNMENT_CENTER, _close.size.x, 24, Color.WHITE)
	if station_mode == "table" or station_mode == "furnace":
		draw_string(_font, Vector2(px + 18.0, py + 66.0), "Нажми на рецепт. Зелёный — хватает ресурсов.", HORIZONTAL_ALIGNMENT_LEFT, _panel.size.x - 36.0, 16, Color(1, 1, 1, 0.9))
		for k in _recipe_rects.size():
			var rec: Dictionary = _recipes[_station_page * _station_page_size + k]
			var rr := _recipe_rects[k]
			var ok := Crafting.can_craft(inv, rec, near_table, near_furnace)
			draw_rect(rr, Color(0.12, 0.42, 0.2, 0.95) if ok else Color(0.04, 0.05, 0.07, 0.9))
			draw_rect(rr, Color(1, 1, 1, 0.4), false, 2.0)
			var out_id := int(rec["out"])
			Atlas.draw_item(self, Rect2(rr.position + Vector2(4, 8), Vector2(38, 38)), out_id, int(rec["n"]), _font)
			var label := Items.item_name(out_id)
			draw_string(_font, rr.position + Vector2(46, 20), label, HORIZONTAL_ALIGNMENT_LEFT, rr.size.x - 50.0, 14, Color.WHITE)
			var ing: Dictionary = rec["ing"]
			var text_line := ""
			for id in ing:
				if not text_line.is_empty(): text_line += " · "
				text_line += "%s %d/%d" % [Items.item_name(int(id)), inv.count_of(int(id)), int(ing[id])]
			draw_string(_font, rr.position + Vector2(46, 42), text_line, HORIZONTAL_ALIGNMENT_LEFT, rr.size.x - 50.0, 11, Color(0.75, 1.0, 0.75) if ok else Color(1, 0.72, 0.65))
		draw_rect(_station_prev, Color(0.18, 0.32, 0.48, 0.95))
		draw_rect(_station_next, Color(0.18, 0.32, 0.48, 0.95))
		draw_string(_font, _station_prev.position + Vector2(4, 24), "◀ Назад", HORIZONTAL_ALIGNMENT_CENTER, _station_prev.size.x - 8, 15, Color.WHITE)
		draw_string(_font, _station_next.position + Vector2(4, 24), "Вперёд ▶", HORIZONTAL_ALIGNMENT_CENTER, _station_next.size.x - 8, 15, Color.WHITE)
		var total_pages := maxi(1, ceili(float(_recipes.size()) / float(_station_page_size)))
		draw_string(_font, Vector2(px + 120.0, _panel.end.y - 25.0), "%d / %d" % [_station_page + 1, total_pages], HORIZONTAL_ALIGNMENT_CENTER, _panel.size.x - 240.0, 14, Color.WHITE)
		return
	if creative:
		draw_string(_font, Vector2(px + 18.0, py + 42.0), "ТВОРЧЕСКИЙ РЕЖИМ · БЛОКИ И ПРЕДМЕТЫ", HORIZONTAL_ALIGNMENT_LEFT, _panel.size.x - 100.0, 22, Color.WHITE)
		for k in _cat_rects.size():
			var cr := _cat_rects[k]
			draw_rect(cr, Color(0.04, 0.06, 0.08, 0.96))
			draw_rect(cr, Color(1, 1, 1, 0.5), false, 2.0)
			Atlas.draw_item(self, cr, _cat_ids[k], 0, _font)
		draw_rect(_cat_prev, Color(0.18, 0.32, 0.48, 0.95))
		draw_rect(_cat_next, Color(0.18, 0.32, 0.48, 0.95))
		draw_rect(_clear_rect, Color(0.48, 0.16, 0.16, 0.95))
		draw_string(_font, _cat_prev.position + Vector2(8, 24), "▲ НАЗАД", HORIZONTAL_ALIGNMENT_CENTER, _cat_prev.size.x - 16, 16, Color.WHITE)
		draw_string(_font, _cat_next.position + Vector2(8, 24), "ВПЕРЁД ▼", HORIZONTAL_ALIGNMENT_CENTER, _cat_next.size.x - 16, 16, Color.WHITE)
		draw_string(_font, _clear_rect.position + Vector2(4, 24), "Очистить слот", HORIZONTAL_ALIGNMENT_CENTER, _clear_rect.size.x - 8, 15, Color.WHITE)
		var pages := maxi(1, ceili(float(_catalog_ids.size()) / float(_cat_page_size)))
		draw_string(_font, Vector2(_panel.position.x, _panel.end.y - 8.0), "Страница %d / %d · свайп вверх/вниз для прокрутки" % [_cat_page + 1, pages], HORIZONTAL_ALIGNMENT_CENTER, _panel.size.x, 14, Color(1, 1, 1, 0.9))
		return

	for i in _slot_rects.size():
		var r := _slot_rects[i]
		draw_rect(r, Color(0, 0, 0, 0.5))
		var border := Color(1, 1, 1, 0.25)
		if i == _picked:
			border = Color(1.0, 0.85, 0.2, 1.0)
		elif i == inv.selected:
			border = Color(1, 1, 1, 0.8)
		draw_rect(r, border, false, 4.0 if i == _picked else 2.0)
		Atlas.draw_item(self, r, inv.ids[i], inv.counts[i], _font)

	var hint := "Tap a slot, then another slot to move it."
	if _picked != -1:
		hint = "%s selected - tap a destination slot." % Items.item_name(inv.ids[_picked])
	var bottom := _slot_rects[0].end.y + 24.0
	draw_string(_font, Vector2(px + 24.0, bottom), hint, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 1, 1, 0.8))
	draw_string(_font, Vector2(px + 24.0, bottom + 30.0), "Слоты быстрого доступа — нижний ряд.", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 1, 1, 0.6))
	var tcol := Color(0.5, 1.0, 0.5) if near_table else Color(1.0, 0.6, 0.4)
	if not creative:
		draw_string(_font, Vector2(px + 24.0, bottom + 58.0), "Table: %s   Furnace: %s" % [_yes_no(near_table), _yes_no(near_furnace)], HORIZONTAL_ALIGNMENT_LEFT, -1, 20, tcol)

	for k in _recipe_rects.size():
		var rec: Dictionary = _recipes[k]
		var rr := _recipe_rects[k]
		var ok := Crafting.can_craft(inv, rec, near_table, near_furnace)
		draw_rect(rr, Color(0.15, 0.45, 0.2, 0.75) if ok else Color(0, 0, 0, 0.45))
		draw_rect(rr, Color(1, 1, 1, 0.45 if ok else 0.18), false, 2.0)
		var out_id := int(rec["out"])
		Atlas.draw_item(self, Rect2(rr.position + Vector2(4, 4), Vector2(34, 34)), out_id, int(rec["n"]), _font)
		draw_string(_font, rr.position + Vector2(42, 17), Items.item_name(out_id), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color.WHITE if ok else Color(1, 1, 1, 0.6))
		var ing: Dictionary = rec["ing"]
		var ix := rr.position.x + 42.0
		for id in ing:
			var have := inv.count_of(int(id))
			var need := int(ing[id])
			var ir := Rect2(ix, rr.position.y + 24.0, 18, 18)
			Atlas.draw_item(self, ir, int(id), 0, _font)
			draw_string(_font, ir.position + Vector2(18, 14), "%d/%d" % [mini(have, need), need], HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.6, 1, 0.6) if have >= need else Color(1, 0.6, 0.5))
			ix += 66.0
		if rec["table"]:
			var station := "FURNACE" if str(rec.get("station", "")) == "furnace" else "TABLE"
			draw_string(_font, Vector2(rr.end.x - 70, rr.position.y + 16), station, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(1, 0.85, 0.4))
