class_name InventoryUI
extends Control
## Inventory grid (tap a slot, then tap another to move/swap/merge) and a
## tap-to-craft recipe list. Tool recipes need a Crafting Table within 4 blocks.

signal closed

var inv: Inventory
var near_table := false
var _picked := -1
var _slot_rects: Array[Rect2] = []
var _recipe_rects: Array[Rect2] = []
var _recipes: Array = []
var _panel := Rect2()
var _close := Rect2()
var _font: Font
var _last_size := Vector2.ZERO
var _opened_ms := 0


func _ready() -> void:
	_font = ThemeDB.fallback_font
	_recipes = Crafting.recipes()
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false


func open(i: Inventory, table: bool) -> void:
	inv = i
	near_table = table
	_picked = -1
	_opened_ms = Time.get_ticks_msec()
	visible = true
	_last_size = Vector2.ZERO
	queue_redraw()


func close() -> void:
	visible = false
	closed.emit()


func _layout() -> void:
	var w := size.x
	var h := size.y
	var pw := minf(w - 40.0, 1180.0)
	var ph := minf(h - 30.0, 680.0)
	_panel = Rect2((w - pw) * 0.5, (h - ph) * 0.5, pw, ph)
	_close = Rect2(_panel.end.x - 64.0, _panel.position.y + 8.0, 56.0, 56.0)
	var slot := 62.0
	var gap := 5.0
	var gx := _panel.position.x + 24.0
	var gy := _panel.position.y + 76.0
	_slot_rects.clear()
	_slot_rects.resize(Inventory.SLOTS)
	for i in Inventory.SLOTS:
		var row: int
		var col: int
		if i < 9:
			row = 3
			col = i
		else:
			row = (i - 9) / 9
			col = (i - 9) % 9
		var y := gy + row * (slot + gap) + (14.0 if row == 3 else 0.0)
		_slot_rects[i] = Rect2(gx + col * (slot + gap), y, slot, slot)
	_recipe_rects.clear()
	var rx := gx + 9.0 * (slot + gap) + 30.0
	var cw := (_panel.end.x - 24.0 - rx - 6.0) * 0.5
	var ch := 56.0
	for k in _recipes.size():
		var col2 := k % 2
		var row2 := k / 2
		_recipe_rects.append(Rect2(rx + col2 * (cw + 6.0), gy + row2 * (ch + 4.0), cw, ch))


func _gui_input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT and mb.pressed:
			_tap(mb.position)
			accept_event()


func _tap(p: Vector2) -> void:
	# Ignore the emulated mouse event of the very touch that opened this screen.
	if Time.get_ticks_msec() - _opened_ms < 300:
		return
	if _close.grow(8.0).has_point(p) or not _panel.has_point(p):
		close()
		return
	for i in _slot_rects.size():
		if _slot_rects[i].has_point(p):
			if _picked == -1:
				if inv.ids[i] != 0:
					_picked = i
			elif _picked == i:
				_picked = -1
			else:
				inv.move(_picked, i)
				_picked = -1
			queue_redraw()
			return
	for k in _recipe_rects.size():
		if _recipe_rects[k].has_point(p):
			Crafting.craft(inv, _recipes[k], near_table)
			queue_redraw()
			return
	queue_redraw()


func _process(_d: float) -> void:
	if visible and size != _last_size:
		_last_size = size
		_layout()
		queue_redraw()


func _draw() -> void:
	if not visible or inv == null or _slot_rects.is_empty() or _recipe_rects.is_empty():
		return
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.55))
	draw_rect(_panel, Color(0.12, 0.14, 0.2, 0.97))
	draw_rect(_panel, Color(1, 1, 1, 0.5), false, 3.0)
	var px := _panel.position.x
	var py := _panel.position.y
	draw_string(_font, Vector2(px + 24.0, py + 46.0), "Inventory", HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color.WHITE)
	draw_string(_font, Vector2(_recipe_rects[0].position.x, py + 46.0), "Crafting  -  tap a recipe", HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(1, 1, 1, 0.9))
	draw_rect(_close, Color(0.6, 0.15, 0.15, 0.9))
	draw_string(_font, _close.position + Vector2(0, 38.0), "X", HORIZONTAL_ALIGNMENT_CENTER, _close.size.x, 30, Color.WHITE)

	for i in _slot_rects.size():
		var r := _slot_rects[i]
		draw_rect(r, Color(0, 0, 0, 0.5))
		var border := Color(1, 1, 1, 0.25)
		if i == _picked:
			border = Color(1.0, 0.85, 0.2, 1.0)
		elif i == inv.selected:
			border = Color(1, 1, 1, 0.8)
		draw_rect(r, border, false, 4.0 if i == _picked else 2.0)
		Atlas.draw_item(self, r, inv.ids[i], inv.counts[i], _font)

	var hint := "Tap a slot, then another slot to move it."
	if _picked != -1:
		hint = "%s selected - tap a destination slot." % Items.item_name(inv.ids[_picked])
	var bottom := _slot_rects[0].end.y + 24.0
	draw_string(_font, Vector2(px + 24.0, bottom), hint, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 1, 1, 0.8))
	draw_string(_font, Vector2(px + 24.0, bottom + 30.0), "Hotbar = bottom row. Tools need a Crafting Table nearby.", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 1, 1, 0.6))
	var tcol := Color(0.5, 1.0, 0.5) if near_table else Color(1.0, 0.6, 0.4)
	draw_string(_font, Vector2(px + 24.0, bottom + 58.0), "Crafting Table nearby: %s" % ("YES" if near_table else "NO"), HORIZONTAL_ALIGNMENT_LEFT, -1, 20, tcol)

	for k in _recipe_rects.size():
		var rec: Dictionary = _recipes[k]
		var rr := _recipe_rects[k]
		var ok := Crafting.can_craft(inv, rec, near_table)
		draw_rect(rr, Color(0.15, 0.45, 0.2, 0.75) if ok else Color(0, 0, 0, 0.45))
		draw_rect(rr, Color(1, 1, 1, 0.45 if ok else 0.18), false, 2.0)
		var out_id := int(rec["out"])
		Atlas.draw_item(self, Rect2(rr.position + Vector2(6, 8), Vector2(40, 40)), out_id, int(rec["n"]), _font)
		draw_string(_font, rr.position + Vector2(52, 20), Items.item_name(out_id), HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color.WHITE if ok else Color(1, 1, 1, 0.6))
		var ing: Dictionary = rec["ing"]
		var ix := rr.position.x + 52.0
		for id in ing:
			var have := inv.count_of(int(id))
			var need := int(ing[id])
			var ir := Rect2(ix, rr.position.y + 26.0, 24, 24)
			Atlas.draw_item(self, ir, int(id), 0, _font)
			draw_string(_font, ir.position + Vector2(25, 18), "%d/%d" % [mini(have, need), need], HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(0.6, 1, 0.6) if have >= need else Color(1, 0.6, 0.5))
			ix += 66.0
		if rec["table"]:
			draw_string(_font, Vector2(rr.end.x - 56, rr.position.y + 16), "TABLE", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(1, 0.85, 0.4))
