class_name Items
extends RefCounted
## Item registry. Ids 1..15 are blocks, 100+ are non-block items, 110..125 are tools.

const STICK := 100
const COAL := 101
const IRON_INGOT := 102
const GOLD_INGOT := 103
const DIAMOND := 104
const APPLE := 105
const FLESH := 106
const WOOL := 107
const FEATHER := 108
const TOOL_BASE := 110 # tool id = TOOL_BASE + material * 4 + kind

const MAT_NAMES := ["Wooden", "Stone", "Iron", "Diamond"]
const KIND_NAMES := ["Pickaxe", "Axe", "Shovel", "Sword"]


static func tool_id(mat: int, kind: int) -> int:
	return TOOL_BASE + mat * 4 + kind


static func is_tool(id: int) -> bool:
	return id >= TOOL_BASE and id < TOOL_BASE + 16


static func tool_kind(id: int) -> int:
	if not is_tool(id):
		return -1
	return (id - TOOL_BASE) & 3


static func tool_tier(id: int) -> int:
	if not is_tool(id):
		return -1
	return (id - TOOL_BASE) >> 2


static func is_block(id: int) -> bool:
	return id > 0 and id < Blocks.COUNT


static func is_food(id: int) -> bool:
	return id == APPLE or id == FLESH


static func food_value(id: int) -> int:
	if id == APPLE:
		return 4
	if id == FLESH:
		return 3
	return 0


static func max_stack(id: int) -> int:
	return 1 if is_tool(id) else 64


static func attack_damage(id: int) -> float:
	var kind := tool_kind(id)
	if kind < 0:
		return 1.0
	var tier := tool_tier(id)
	match kind:
		3:
			return 4.0 + tier
		1:
			return 3.0 + tier
		0:
			return 2.0 + tier
	return 1.0 + tier


static func item_name(id: int) -> String:
	if is_block(id):
		return Blocks.NAMES[id]
	if is_tool(id):
		return "%s %s" % [MAT_NAMES[tool_tier(id)], KIND_NAMES[tool_kind(id)]]
	match id:
		STICK:
			return "Stick"
		COAL:
			return "Coal"
		IRON_INGOT:
			return "Iron Ingot"
		GOLD_INGOT:
			return "Gold Ingot"
		DIAMOND:
			return "Diamond"
		APPLE:
			return "Apple"
		FLESH:
			return "Rotten Flesh"
		WOOL:
			return "Wool"
		FEATHER:
			return "Feather"
	return ""


## Atlas tile used to draw this item in the UI.
static func icon_tile(id: int) -> int:
	if is_block(id):
		return Blocks.TILE_SIDE[id]
	if is_tool(id):
		return 40 + (id - TOOL_BASE)
	match id:
		STICK:
			return 32
		COAL:
			return 33
		IRON_INGOT:
			return 34
		GOLD_INGOT:
			return 35
		DIAMOND:
			return 36
		APPLE:
			return 37
		FLESH:
			return 38
		WOOL:
			return 39
		FEATHER:
			return 56
	return 0
