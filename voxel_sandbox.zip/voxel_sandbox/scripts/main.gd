extends Node3D
## Game root. Builds the environment and UI in code, runs the menu -> loading ->
## playing flow, the day/night cycle, weather, enemy spawning and saving.

enum State { MENU, LOADING, PLAYING }

const DAY_LENGTH := 600.0 # seconds for a full day/night cycle
const AUTOSAVE_EVERY := 90.0

var state := State.MENU
var paused := false
var daylight := 1.0
var mobs: Array = []

var world: World
var player: Player
var inv := Inventory.new()
var hud: HUD
var inv_ui: InventoryUI
var menu: MenuUI
var ui: CanvasLayer

var env: Environment
var sky_mat: ProceduralSkyMaterial
var sun: DirectionalLight3D
var moon: MeshInstance3D
var rain: CPUParticles3D
var menu_cam: Camera3D
var _particle_mesh: BoxMesh

var seed_value := 0
var time_of_day := 0.3
var is_new := true
var start_data: Dictionary = {}
var start_pos := Vector3.ZERO
var spawn_point := Vector3.ZERO

var raining := false
var rain_level := 0.0
var weather_t := 120.0
var mob_t := 2.0
var autosave_t := AUTOSAVE_EVERY
var env_t := 0.0
var loading_t := 0.0
var save_failed := false


func _ready() -> void:
	Settings.load_settings()
	Atlas.build()
	DisplayServer.screen_set_keep_on(true)
	randomize()
	# 3D resolution scaling is not supported by the Compatibility renderer (the default
	# here), so only touch it when the project was switched to the Mobile renderer.
	var method := str(ProjectSettings.get_setting("rendering/renderer/rendering_method.mobile", "mobile"))
	if OS.has_feature("mobile") and method != "gl_compatibility":
		get_viewport().scaling_3d_scale = 0.85
	_particle_mesh = BoxMesh.new()
	_particle_mesh.size = Vector3(0.12, 0.12, 0.12)
	_setup_environment()
	_setup_ui()
	menu.show_main(SaveSystem.exists())


# ------------------------------------------------------------------ setup

func _setup_environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	sky_mat = ProceduralSkyMaterial.new()
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.62, 0.66, 0.74)
	env.fog_enabled = true
	env.fog_sky_affect = 0.0
	env.fog_density = 0.02
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.shadow_enabled = Settings.shadows
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 48.0
	sun.shadow_bias = 0.08
	sun.shadow_normal_bias = 1.0
	add_child(sun)

	moon = MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(28, 28)
	var mm := StandardMaterial3D.new()
	mm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mm.albedo_texture = Atlas.moon_texture
	mm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	mm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	mm.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	mm.disable_fog = true
	moon.mesh = q
	moon.material_override = mm
	moon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(moon)

	rain = CPUParticles3D.new()
	rain.amount = 450
	rain.lifetime = 1.0
	rain.emitting = false
	rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain.emission_box_extents = Vector3(16, 0.5, 16)
	rain.direction = Vector3(0, -1, 0)
	rain.spread = 2.0
	rain.initial_velocity_min = 20.0
	rain.initial_velocity_max = 24.0
	rain.gravity = Vector3.ZERO
	var rb := BoxMesh.new()
	rb.size = Vector3(0.02, 0.6, 0.02)
	rain.mesh = rb
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = Color(0.7, 0.8, 1.0, 0.55)
	rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rain.material_override = rm
	rain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(rain)

	menu_cam = Camera3D.new()
	add_child(menu_cam)
	menu_cam.make_current()


func _setup_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	hud = HUD.new()
	ui.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.inv = inv
	inv_ui = InventoryUI.new()
	ui.add_child(inv_ui)
	inv_ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu = MenuUI.new()
	ui.add_child(menu)
	hud.inventory_pressed.connect(_open_inventory)
	hud.menu_pressed.connect(_open_pause)
	hud.respawn_pressed.connect(_on_respawn)
	inv_ui.closed.connect(_close_overlay)
	menu.new_game.connect(_begin.bind(false))
	menu.continue_game.connect(_begin.bind(true))
	menu.resume.connect(_close_overlay)
	menu.save_quit.connect(_save_and_quit)
	menu.settings_changed.connect(_apply_settings)


# ------------------------------------------------------------------ game flow

func _begin(load_save: bool) -> void:
	if state != State.MENU:
		return
	start_data = {}
	save_failed = false
	loading_t = 0.0
	if load_save:
		var loaded := SaveSystem.load_game()
		if _valid_save(loaded):
			start_data = loaded
		else:
			save_failed = true # damaged / old save: start a fresh world instead of crashing
	is_new = start_data.is_empty()
	inv = Inventory.new()
	hud.inv = inv
	var edits: Dictionary = {}
	if is_new:
		seed_value = randi() % 900000 + 1
		time_of_day = 0.3
		var sp := _find_spawn(seed_value)
		start_pos = Vector3(sp.x + 0.5, 0.0, sp.y + 0.5)
		spawn_point = start_pos
	else:
		seed_value = int(start_data["seed"])
		time_of_day = clampf(float(start_data.get("time", 0.3)), 0.0, 1.0)
		edits = _sanitize_edits(start_data.get("edits"))
		var pd: Dictionary = start_data["player"]
		start_pos = pd["pos"]
		spawn_point = start_pos
		var sp_saved: Variant = start_data.get("spawn")
		if sp_saved is Vector3:
			spawn_point = sp_saved
		var inv_saved: Variant = start_data.get("inv")
		if inv_saved is Dictionary:
			inv.from_dict(inv_saved)
	world = World.new()
	add_child(world)
	world.setup(seed_value, edits, Settings.view_radius)
	world.focus = start_pos
	menu.show_loading("Generating terrain... 0%")
	state = State.LOADING
	_apply_settings()


func _valid_save(d: Dictionary) -> bool:
	if d.is_empty() or not d.has("seed") or not d.has("player"):
		return false
	var sd: Variant = d["seed"]
	if not (sd is int or sd is float):
		return false
	var pd: Variant = d["player"]
	if not (pd is Dictionary):
		return false
	var pos: Variant = pd.get("pos")
	if not (pos is Vector3):
		return false
	var v: Vector3 = pos
	return is_finite(v.x) and is_finite(v.y) and is_finite(v.z)


## Keeps only well-formed block edits: Vector2i chunk key -> {index: block id}.
func _sanitize_edits(raw: Variant) -> Dictionary:
	var out: Dictionary = {}
	if not (raw is Dictionary):
		return out
	var src: Dictionary = raw
	for k in src:
		var v: Variant = src[k]
		if k is Vector2i and v is Dictionary:
			out[k] = v
	return out


func _start_play() -> void:
	if is_new:
		start_pos = _find_standing(floori(start_pos.x), floori(start_pos.z))
		spawn_point = start_pos
	player = Player.new()
	add_child(player)
	player.setup(world, hud, inv, self)
	player.position = start_pos
	player.spawn_point = spawn_point
	player.fall_peak = start_pos.y
	if not is_new:
		var pd: Dictionary = start_data["player"]
		player.yaw = float(pd.get("yaw", 0.0))
		player.pitch = float(pd.get("pitch", 0.0))
		player.health = float(pd.get("health", 20.0))
		player.hunger = float(pd.get("hunger", 20.0))
		if player.health <= 0.0:
			player.health = 20.0
	player.died.connect(_on_player_died)
	hud.player = player
	hud.active = true
	hud.modal = false
	hud.dead = false
	menu_cam.queue_free()
	menu.hide_menu()
	paused = false
	state = State.PLAYING
	_apply_settings()
	if save_failed:
		hud.show_toast("Save was damaged - started a new world")
	elif is_new:
		hud.show_toast("Hold BREAK on a tree trunk to collect logs")


func _find_spawn(sd: int) -> Vector2i:
	var tg := TerrainGen.new(sd)
	for r in range(0, 600, 8):
		for k in 8:
			var a := k * TAU / 8.0
			var x := int(cos(a) * r)
			var z := int(sin(a) * r)
			var h := tg.height_at(x, z)
			if h > TerrainGen.SEA + 2 and h < 38 \
					and tg.surface_block(h, tg.n_temp.get_noise_2d(x, z)) == Blocks.GRASS:
				return Vector2i(x, z)
	return Vector2i.ZERO


func _find_standing(bx: int, bz: int) -> Vector3:
	for r in range(0, 9):
		for dz in range(-r, r + 1):
			for dx in range(-r, r + 1):
				if maxi(absi(dx), absi(dz)) != r:
					continue
				var x := bx + dx
				var z := bz + dz
				var ty := world.top_y(x, z)
				if ty < 0:
					continue
				var b := world.get_block(x, ty, z)
				var ok := b == Blocks.GRASS or b == Blocks.SAND or b == Blocks.DIRT or b == Blocks.STONE
				if ok and world.get_block(x, ty + 1, z) == 0 and world.get_block(x, ty + 2, z) == 0:
					return Vector3(x + 0.5, ty + 1.0, z + 0.5)
	return Vector3(bx + 0.5, 62.0, bz + 0.5)


func _open_pause() -> void:
	if state != State.PLAYING or paused:
		return
	paused = true
	hud.modal = true
	hud.reset_inputs()
	menu.show_pause()


func _open_inventory() -> void:
	if state != State.PLAYING or paused:
		return
	paused = true
	hud.modal = true
	hud.reset_inputs()
	inv_ui.open(inv, player.near_table())


func _close_overlay() -> void:
	paused = false
	hud.modal = false
	menu.hide_menu()
	inv_ui.visible = false


func _apply_settings() -> void:
	sun.shadow_enabled = Settings.shadows
	var dist := Settings.view_radius * 16.0
	if world != null:
		world.set_view_radius(Settings.view_radius)
	if player != null:
		player.cam.far = maxf(dist + 48.0, 320.0)
	Settings.save_settings()


func _on_player_died() -> void:
	hud.dead = true
	hud.reset_inputs()


func _on_respawn() -> void:
	if state == State.PLAYING and not player.alive:
		player.respawn()
		hud.dead = false
		for m in mobs.duplicate():
			_remove_mob(m)
		mobs.clear()


# ------------------------------------------------------------------ saving

func _save() -> void:
	if state != State.PLAYING or player == null or world == null:
		return
	var data := {
		"v": 1,
		"seed": seed_value,
		"time": time_of_day,
		"spawn": spawn_point,
		"player": {
			"pos": player.position,
			"yaw": player.yaw,
			"pitch": player.pitch,
			"health": player.health,
			"hunger": player.hunger,
		},
		"inv": inv.to_dict(),
		"edits": world.edits,
	}
	SaveSystem.save_game(data)


func _save_and_quit() -> void:
	_save()
	get_tree().reload_current_scene()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if state == State.PLAYING:
			if paused:
				_close_overlay()
			else:
				_open_pause()
		elif state == State.MENU:
			get_tree().quit()
	elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		_save()


# ------------------------------------------------------------------ per-frame

func _process(delta: float) -> void:
	if state == State.LOADING:
		loading_t += delta
		var p := world.ready_progress(start_pos, 2)
		menu.set_loading_text("Generating terrain... %d%%" % int(p * 100.0))
		# The timeout only exists so a very slow device can never sit on this screen forever.
		if p >= 1.0 or loading_t > 90.0:
			_start_play()
	elif state == State.PLAYING:
		if not paused:
			time_of_day = fposmod(time_of_day + delta / DAY_LENGTH, 1.0)
			_update_weather(delta)
			_update_mobs(delta)
			autosave_t -= delta
			if autosave_t <= 0.0:
				autosave_t = AUTOSAVE_EVERY
				_save()
		world.focus = player.position
	elif state == State.MENU and menu_cam != null:
		menu_cam.rotation.y += delta * 0.05
	_update_environment(delta)


func _update_environment(delta: float) -> void:
	var a := time_of_day * TAU
	var s := sin(a)
	var sun_dir := Vector3(cos(a), s, 0.35).normalized()
	var day := smoothstep(-0.12, 0.25, s)
	daylight = day
	sun.basis = Basis.looking_at(-sun_dir, Vector3.UP)
	sun.light_energy = lerpf(0.0, 1.15, day) * (1.0 - 0.5 * rain_level)
	sun.light_color = Color(1.0, 0.62, 0.4).lerp(Color(1.0, 0.97, 0.9), smoothstep(0.0, 0.45, s))
	sun.shadow_enabled = Settings.shadows and day > 0.05
	sun.visible = day > 0.01
	var cam_pos := Vector3.ZERO
	if player != null:
		cam_pos = player.cam.global_position
	moon.visible = s < 0.1
	moon.global_position = cam_pos - sun_dir * 250.0

	var dist := Settings.view_radius * 16.0
	var under := player != null and player.head_in_water
	if under:
		env.fog_light_color = Color(0.1, 0.25, 0.45)
		env.fog_density = 0.12
	env_t -= delta
	if env_t <= 0.0:
		env_t = 0.25
		var top := Color(0.02, 0.03, 0.09).lerp(Color(0.25, 0.46, 0.85), day)
		var hor := Color(0.05, 0.07, 0.15).lerp(Color(0.62, 0.78, 0.95), day)
		var dusk := 1.0 - clampf(absf(s) * 5.0, 0.0, 1.0)
		hor = hor.lerp(Color(0.95, 0.55, 0.35), dusk * 0.55)
		var g := 0.25 + 0.75 * day
		var gray := Color(0.45 * g, 0.48 * g, 0.52 * g)
		top = top.lerp(gray, rain_level * 0.7)
		hor = hor.lerp(gray, rain_level * 0.8)
		sky_mat.sky_top_color = top
		sky_mat.sky_horizon_color = hor
		sky_mat.ground_horizon_color = hor
		sky_mat.ground_bottom_color = hor.darkened(0.4)
		env.ambient_light_color = Color(0.10, 0.12, 0.24).lerp(Color(0.62, 0.66, 0.74), day)
		if not under:
			env.fog_light_color = hor
			env.fog_density = (1.5 + rain_level) / dist


func _update_weather(delta: float) -> void:
	weather_t -= delta
	if weather_t <= 0.0:
		raining = (not raining) and randf() < 0.45
		weather_t = randf_range(80.0, 200.0)
	rain_level = move_toward(rain_level, 1.0 if raining else 0.0, delta * 0.2)
	rain.emitting = rain_level > 0.05
	rain.global_position = player.position + Vector3(0, 12, 0)


func _update_mobs(delta: float) -> void:
	mob_t -= delta
	if mob_t <= 0.0:
		mob_t = 2.5
		if daylight < 0.3 and mobs.size() < 5 and player.alive:
			_try_spawn_mob()
	for m in mobs.duplicate():
		if not is_instance_valid(m):
			mobs.erase(m)
		elif m.position.distance_to(player.position) > 56.0:
			_remove_mob(m)


func _try_spawn_mob() -> void:
	var a := randf() * TAU
	var d := randf_range(14.0, 26.0)
	var x := floori(player.position.x + cos(a) * d)
	var z := floori(player.position.z + sin(a) * d)
	var ty := world.top_y(x, z)
	if ty < 0 or ty > World.CH - 4:
		return
	if world.get_block(x, ty, z) == Blocks.LEAVES:
		return
	if world.get_block(x, ty + 1, z) != 0 or world.get_block(x, ty + 2, z) != 0:
		return
	var m := Mob.new()
	add_child(m)
	m.setup(world, player, self)
	m.position = Vector3(x + 0.5, ty + 1.0, z + 0.5)
	m.died.connect(_on_mob_died)
	mobs.append(m)


func _on_mob_died(m: Mob) -> void:
	mobs.erase(m)
	if randf() < 0.5:
		inv.add(Items.FLESH, 1)
		hud.show_toast("Rotten Flesh +1")


func _remove_mob(m: Variant) -> void:
	mobs.erase(m)
	if is_instance_valid(m):
		m.queue_free()


## One-shot burst of little cubes (block breaking, splashes, mob poofs).
func burst(p: Vector3, col: Color, amount: int = 12, speed: float = 3.0) -> void:
	var cp := CPUParticles3D.new()
	cp.emitting = false
	cp.one_shot = true
	cp.amount = amount
	cp.lifetime = 0.7
	cp.explosiveness = 1.0
	cp.mesh = _particle_mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.roughness = 1.0
	cp.material_override = mat
	cp.direction = Vector3.UP
	cp.spread = 180.0
	cp.initial_velocity_min = 1.5
	cp.initial_velocity_max = speed
	cp.gravity = Vector3(0, -14, 0)
	cp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	cp.position = p
	add_child(cp)
	cp.emitting = true
	get_tree().create_timer(1.3).timeout.connect(cp.queue_free)
