class_name MenuUI
extends Control
## All menu screens (main, worlds, create world, world settings, delete confirmation,
## pause, loading, diagnostics). Real Button/LineEdit controls sized for fingers.
## Worlds are managed through WorldStore; this class only emits play_world(id).

signal play_world(id: String)
signal resume
signal save_quit
signal settings_changed
signal diagnostics_requested
signal reset_safe_mode

const VIEW_STEPS := [2, 3, 4, 5, 6]
const LOOK_STEPS := [0.10, 0.16, 0.24, 0.34]

var _vbox: VBoxContainer
var _progress_label: Label

# state of the "create world" form (kept when you go back and forth)
var _c_name := ""
var _c_seed := ""
var _c_type := 0
var _c_mode := 0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.05, 0.07, 0.12, 0.95)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	_vbox = VBoxContainer.new()
	_vbox.add_theme_constant_override("separation", 12)
	center.add_child(_vbox)
	visible = false


# ------------------------------------------------------------------ helpers

func _clear() -> void:
	for c in _vbox.get_children():
		_vbox.remove_child(c)
		c.queue_free()
	_progress_label = null


func _label(text: String, fsize: int, col: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", fsize)
	l.add_theme_color_override("font_color", col)
	_vbox.add_child(l)
	return l


func _button(text: String, cb: Callable, width: float = 460.0, parent: Node = null) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(width, 62)
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(cb)
	if parent == null:
		_vbox.add_child(b)
	else:
		parent.add_child(b)
	return b


func _edit(placeholder: String, text: String, width: float) -> LineEdit:
	var e := LineEdit.new()
	e.placeholder_text = placeholder
	e.text = text
	e.custom_minimum_size = Vector2(width, 58)
	e.add_theme_font_size_override("font_size", 24)
	return e


func _hbox() -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	_vbox.add_child(h)
	return h


# ------------------------------------------------------------------ main menu

func show_main() -> void:
	_clear()
	visible = true
	_label("VOXEL SANDBOX", 60, Color(0.55, 0.9, 0.45))
	_label("Добывай. Строй. Выживай.", 22, Color(1, 1, 1, 0.75))
	_label("Подсказка: BREAK — добыть · PLACE — поставить · BAG — инвентарь", 16, Color(0.72, 0.86, 0.72))
	_label("Творческий чат: /help · /tp village · /weather clear|rain · /time day|night", 15, Color(0.75, 0.82, 1.0))
	_vbox.add_child(Control.new())
	var worlds := WorldStore.list()
	if not worlds.is_empty():
		var last: Dictionary = worlds[0]
		_button("Продолжить: %s" % str(last["name"]), _emit_play.bind(str(last["id"])))
	_button("Создать мир", show_create)
	_button("Мои миры", show_worlds)
	_button("Диагностика", func() -> void: diagnostics_requested.emit())
	if Settings.crash_count > 0:
		_label("Безопасный режим %d: прошлый запуск упал при загрузке" % Settings.crash_count, 18, Color(1.0, 0.7, 0.3))


func _emit_play(id: String) -> void:
	play_world.emit(id)


# ------------------------------------------------------------------ create world

func show_create() -> void:
	_clear()
	visible = true
	_label("Создать мир", 40)
	var name_edit := _edit("Название мира", _c_name, 760)
	name_edit.max_length = WorldStore.MAX_NAME
	_vbox.add_child(name_edit)
	var row := _hbox()
	var seed_edit := _edit("Сид мира (пусто = случайный)", _c_seed, 540)
	row.add_child(seed_edit)
	_button("Случайный сид", _random_seed.bind(seed_edit), 210, row)
	var type_btn := _button("", func() -> void: pass, 760)
	var mode_btn := _button("", func() -> void: pass, 760)
	var desc := _label("", 18, Color(1, 1, 1, 0.8))
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.custom_minimum_size = Vector2(760, 70)
	var err := _label("", 20, Color(1.0, 0.45, 0.4))
	var refresh := func() -> void:
		if _c_type == 3:
			_c_mode = 1
		type_btn.text = "Тип мира: %s" % WorldStore.TYPE_NAMES[_c_type]
		mode_btn.text = "Режим: %s%s" % [WorldStore.MODE_NAMES[_c_mode], " (задан типом мира)" if _c_type == 3 else ""]
		mode_btn.disabled = _c_type == 3
		desc.text = "%s\n%s" % [WorldStore.TYPE_DESC[_c_type], WorldStore.MODE_DESC[_c_mode]]
	type_btn.pressed.connect(func() -> void:
		_c_type = (_c_type + 1) % WorldStore.TYPE_NAMES.size()
		refresh.call())
	mode_btn.pressed.connect(func() -> void:
		_c_mode = (_c_mode + 1) % WorldStore.MODE_NAMES.size()
		refresh.call())
	refresh.call()
	var row2 := _hbox()
	_button("Создать мир", _do_create.bind(name_edit, seed_edit, err), 370, row2)
	_button("Назад", _form_back.bind(name_edit, seed_edit), 370, row2)


func _random_seed(seed_edit: LineEdit) -> void:
	seed_edit.text = str(WorldStore.random_seed())


func _form_back(name_edit: LineEdit, seed_edit: LineEdit) -> void:
	_c_name = name_edit.text
	_c_seed = seed_edit.text
	show_main()


func _do_create(name_edit: LineEdit, seed_edit: LineEdit, err: Label) -> void:
	_c_name = name_edit.text
	_c_seed = seed_edit.text
	var parsed := WorldStore.parse_seed(seed_edit.text)
	if not bool(parsed["ok"]):
		err.text = str(parsed["error"])
		return
	var sd := WorldStore.random_seed() if bool(parsed["random"]) else int(parsed["value"])
	var id := WorldStore.create(name_edit.text, sd, _c_type, _c_mode)
	if id == "":
		err.text = "Не удалось создать мир: нет доступа к хранилищу"
		return
	_c_name = ""
	_c_seed = ""
	play_world.emit(id)


# ------------------------------------------------------------------ worlds list

func show_worlds(message: String = "") -> void:
	_clear()
	visible = true
	_label("Мои миры", 40)
	if message != "":
		_label(message, 20, Color(1.0, 0.8, 0.4))
	var worlds := WorldStore.list()
	if worlds.is_empty():
		_label("Миров пока нет. Нажмите «Создать мир».", 22)
	else:
		var sc := ScrollContainer.new()
		sc.custom_minimum_size = Vector2(1140, 440)
		sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		_vbox.add_child(sc)
		var list := VBoxContainer.new()
		list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		list.add_theme_constant_override("separation", 10)
		sc.add_child(list)
		for w in worlds:
			list.add_child(_world_row(w))
	_button("Назад", show_main)


func _world_row(w: Dictionary) -> Control:
	var id: String = w["id"]
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(1120, 90)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	panel.add_child(h)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(info)
	var n := Label.new()
	n.text = str(w["name"])
	n.add_theme_font_size_override("font_size", 26)
	info.add_child(n)
	var d := Label.new()
	d.text = "Сид: %d · %s · %s · изменён %s" % [int(w["seed"]), WorldStore.TYPE_NAMES[int(w["type"])],
		WorldStore.MODE_NAMES[int(w["mode"])], WorldStore.format_time(int(w["modified"]))]
	d.add_theme_font_size_override("font_size", 16)
	d.add_theme_color_override("font_color", Color(1, 1, 1, 0.7))
	info.add_child(d)
	_button("Играть", _emit_play.bind(id), 130, h)
	_button("Настройки", show_world_settings.bind(id), 150, h)
	_button("Копировать", _do_copy.bind(id), 150, h)
	_button("Удалить", show_confirm_delete.bind(id), 130, h)
	return panel


func _do_copy(id: String) -> void:
	var nid := WorldStore.copy(id)
	show_worlds("Копия создана" if nid != "" else "Не удалось скопировать мир")


func show_world_settings(id: String) -> void:
	var m := WorldStore.read_meta(id)
	if m.is_empty():
		show_worlds("Мир не найден")
		return
	_clear()
	visible = true
	_label("Настройки мира", 40)
	var name_edit := _edit("Название мира", str(m["name"]), 760)
	name_edit.max_length = WorldStore.MAX_NAME
	_vbox.add_child(name_edit)
	_label("Сид: %d" % int(m["seed"]), 24)
	_label("Тип мира: %s     Режим: %s" % [WorldStore.TYPE_NAMES[int(m["type"])], WorldStore.MODE_NAMES[int(m["mode"])]], 22)
	_label("Создан: %s     Изменён: %s" % [WorldStore.format_time(int(m["created"])), WorldStore.format_time(int(m["modified"]))], 18, Color(1, 1, 1, 0.7))
	_label("Тип мира, сид и режим после создания не меняются.", 16, Color(1, 1, 1, 0.55))
	var info := _label("", 20, Color(0.6, 1.0, 0.6))
	var row := _hbox()
	_button("Копировать сид", _copy_seed.bind(int(m["seed"]), info), 250, row)
	_button("Сохранить название", _do_rename.bind(id, name_edit, info), 270, row)
	_button("Назад", show_worlds, 760)


func _copy_seed(sd: int, info: Label) -> void:
	DisplayServer.clipboard_set(str(sd))
	info.text = "Сид скопирован в буфер обмена"


func _do_rename(id: String, name_edit: LineEdit, info: Label) -> void:
	info.text = "Название сохранено" if WorldStore.rename(id, name_edit.text) else "Не удалось сохранить"


func show_confirm_delete(id: String) -> void:
	var m := WorldStore.read_meta(id)
	var nm := str(m.get("name", id))
	_clear()
	visible = true
	_label("Удалить мир?", 40, Color(1.0, 0.5, 0.45))
	_label("«%s» будет удалён безвозвратно." % nm, 24)
	var row := _hbox()
	_button("Да, удалить", _do_delete.bind(id), 300, row)
	_button("Отмена", show_worlds, 300, row)


func _do_delete(id: String) -> void:
	WorldStore.delete(id)
	show_worlds("Мир удалён")


func show_message(text: String) -> void:
	_clear()
	visible = true
	_label(text, 26, Color(1.0, 0.8, 0.4))
	_button("К списку миров", show_worlds)


# ------------------------------------------------------------------ pause / loading / diagnostics

func show_pause(info: String = "", sd: int = 0) -> void:
	_clear()
	visible = true
	_label("Пауза", 48)
	if info != "":
		_label(info, 18, Color(1, 1, 1, 0.75))
	_button("Продолжить", func() -> void: resume.emit())
	var cb := _button("Копировать сид", func() -> void: pass)
	cb.pressed.connect(func() -> void:
		DisplayServer.clipboard_set(str(sd))
		cb.text = "Сид скопирован")
	var sb := _button("", func() -> void: pass)
	sb.text = "Тени: %s" % ("ВКЛ" if Settings.shadows else "ВЫКЛ")
	sb.pressed.connect(func() -> void:
		Settings.shadows = not Settings.shadows
		sb.text = "Тени: %s" % ("ВКЛ" if Settings.shadows else "ВЫКЛ")
		Settings.save_settings()
		settings_changed.emit())
	var vb := _button("", func() -> void: pass)
	vb.text = "Дальность прорисовки: %d" % Settings.view_radius
	vb.pressed.connect(func() -> void:
		var i := VIEW_STEPS.find(Settings.view_radius)
		Settings.view_radius = VIEW_STEPS[(i + 1) % VIEW_STEPS.size()]
		vb.text = "Дальность прорисовки: %d" % Settings.view_radius
		Settings.save_settings()
		settings_changed.emit())
	var lb := _button("", func() -> void: pass)
	lb.text = "Скорость камеры: %d" % (LOOK_STEPS.find(_nearest_look()) + 1)
	lb.pressed.connect(func() -> void:
		var i := LOOK_STEPS.find(_nearest_look())
		Settings.look_speed = LOOK_STEPS[(i + 1) % LOOK_STEPS.size()]
		lb.text = "Скорость камеры: %d" % (LOOK_STEPS.find(_nearest_look()) + 1)
		Settings.save_settings())
	var tb := _button("", func() -> void: pass)
	tb.text = "Фоновые потоки: %s" % ("ВКЛ" if Settings.use_threads else "ВЫКЛ")
	tb.pressed.connect(func() -> void:
		Settings.use_threads = not Settings.use_threads
		tb.text = "Фоновые потоки: %s" % ("ВКЛ" if Settings.use_threads else "ВЫКЛ")
		Settings.save_settings()
		settings_changed.emit())
	_button("Сохранить и выйти в меню", func() -> void: save_quit.emit())


func _nearest_look() -> float:
	var best: float = LOOK_STEPS[0]
	for s in LOOK_STEPS:
		if absf(float(s) - Settings.look_speed) < absf(best - Settings.look_speed):
			best = float(s)
	return best


func show_loading(text: String) -> void:
	_clear()
	visible = true
	_label("VOXEL SANDBOX", 48, Color(0.55, 0.9, 0.45))
	_progress_label = _label(text, 26)


func set_loading_text(text: String) -> void:
	if _progress_label != null:
		_progress_label.text = text


func hide_menu() -> void:
	visible = false


func show_diagnostics(text: String) -> void:
	_clear()
	visible = true
	_label("Диагностика", 36)
	_label("Безопасный режим: %d   потоки: %s   дальность: %d   тени: %s" % [
		Settings.crash_count, "вкл" if Settings.effective_threads() else "выкл",
		Settings.effective_radius(), "вкл" if Settings.effective_shadows() else "выкл"], 18, Color(1, 1, 1, 0.8))
	var l := _label(text, 12, Color(0.85, 0.95, 0.85))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	l.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	l.custom_minimum_size = Vector2(1000, 0)
	_button("Сбросить безопасный режим", func() -> void: reset_safe_mode.emit())
	_button("Назад", show_main)
