class_name MenuUI
extends Control
## Main menu, pause menu and loading screen. Uses real Button controls sized for fingers.

signal new_game
signal continue_game
signal resume
signal save_quit
signal settings_changed

const VIEW_STEPS := [2, 3, 4, 5, 6]
const LOOK_STEPS := [0.10, 0.16, 0.24, 0.34]

var _vbox: VBoxContainer
var _progress_label: Label


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = Color(0.05, 0.07, 0.12, 0.93)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	_vbox = VBoxContainer.new()
	_vbox.add_theme_constant_override("separation", 14)
	center.add_child(_vbox)
	visible = false


func _clear() -> void:
	for c in _vbox.get_children():
		_vbox.remove_child(c)
		c.queue_free()
	_progress_label = null


func _label(text: String, fsize: int, col: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", fsize)
	l.add_theme_color_override("font_color", col)
	_vbox.add_child(l)
	return l


func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(460, 66)
	b.add_theme_font_size_override("font_size", 26)
	b.pressed.connect(cb)
	_vbox.add_child(b)
	return b


func show_main(has_save: bool) -> void:
	_clear()
	visible = true
	_label("VOXEL SANDBOX", 60, Color(0.55, 0.9, 0.45))
	_label("Mine. Build. Survive the night.", 22, Color(1, 1, 1, 0.75))
	_vbox.add_child(Control.new())
	if has_save:
		_button("Continue", func() -> void: continue_game.emit())
	_button("New World", func() -> void: new_game.emit())
	_label("Left stick: move   Right side: look   BREAK / PLACE: act", 18, Color(1, 1, 1, 0.55))


func show_pause() -> void:
	_clear()
	visible = true
	_label("Paused", 48)
	_button("Resume", func() -> void: resume.emit())
	var sb := _button("", func() -> void: pass)
	sb.text = "Shadows: %s" % ("ON" if Settings.shadows else "OFF")
	sb.pressed.connect(func() -> void:
		Settings.shadows = not Settings.shadows
		sb.text = "Shadows: %s" % ("ON" if Settings.shadows else "OFF")
		Settings.save_settings()
		settings_changed.emit())
	var vb := _button("", func() -> void: pass)
	vb.text = "View distance: %d chunks" % Settings.view_radius
	vb.pressed.connect(func() -> void:
		var i := VIEW_STEPS.find(Settings.view_radius)
		Settings.view_radius = VIEW_STEPS[(i + 1) % VIEW_STEPS.size()]
		vb.text = "View distance: %d chunks" % Settings.view_radius
		Settings.save_settings()
		settings_changed.emit())
	var lb := _button("", func() -> void: pass)
	lb.text = "Look speed: %d" % (LOOK_STEPS.find(_nearest_look()) + 1)
	lb.pressed.connect(func() -> void:
		var i := LOOK_STEPS.find(_nearest_look())
		Settings.look_speed = LOOK_STEPS[(i + 1) % LOOK_STEPS.size()]
		lb.text = "Look speed: %d" % (LOOK_STEPS.find(_nearest_look()) + 1)
		Settings.save_settings())
	_button("Save and Quit to Menu", func() -> void: save_quit.emit())


func _nearest_look() -> float:
	var best: float = LOOK_STEPS[0]
	for s in LOOK_STEPS:
		if absf(float(s) - Settings.look_speed) < absf(best - Settings.look_speed):
			best = float(s)
	return best


func show_loading(text: String) -> void:
	_clear()
	visible = true
	_label("VOXEL SANDBOX", 48, Color(0.55, 0.9, 0.45))
	_progress_label = _label(text, 26)


func set_loading_text(text: String) -> void:
	if _progress_label != null:
		_progress_label.text = text


func hide_menu() -> void:
	visible = false
