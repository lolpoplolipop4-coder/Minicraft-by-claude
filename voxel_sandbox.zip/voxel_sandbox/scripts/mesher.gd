class_name Mesher
extends RefCounted
## Turns chunk block data into two meshes (opaque + water). Runs on worker threads.
## Only faces that touch air/water/leaves are emitted, so interior blocks cost nothing.
##
## Index layout of a chunk:  i = (y * 16 + z) * 16 + x
## Godot front faces are CLOCKWISE, so FACE_V lists corners counter-clockwise
## (seen from outside) and _emit() writes the triangles in reverse order.

const CS := 16
const CH := 64
const EPS := 0.0006

# Directions: 0 +X, 1 -X, 2 +Y, 3 -Y, 4 +Z, 5 -Z
const FACE_V := [
	[Vector3(1, 0, 0), Vector3(1, 1, 0), Vector3(1, 1, 1), Vector3(1, 0, 1)],
	[Vector3(0, 0, 1), Vector3(0, 1, 1), Vector3(0, 1, 0), Vector3(0, 0, 0)],
	[Vector3(0, 1, 0), Vector3(0, 1, 1), Vector3(1, 1, 1), Vector3(1, 1, 0)],
	[Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(1, 0, 1), Vector3(0, 0, 1)],
	[Vector3(1, 0, 1), Vector3(1, 1, 1), Vector3(0, 1, 1), Vector3(0, 0, 1)],
	[Vector3(0, 0, 0), Vector3(0, 1, 0), Vector3(1, 1, 0), Vector3(1, 0, 0)],
]
const FACE_N := [
	Vector3(1, 0, 0), Vector3(-1, 0, 0), Vector3(0, 1, 0),
	Vector3(0, -1, 0), Vector3(0, 0, 1), Vector3(0, 0, -1),
]
# Cheap directional shading baked into vertex colours.
const FACE_SHADE := [0.82, 0.74, 1.0, 0.55, 0.90, 0.68]
# UV corner selectors (0 = min, 1 = max) matching the corner order above.
const UV_SIDE := [[1, 1], [1, 0], [0, 0], [0, 1]]
const UV_TOP := [[0, 0], [0, 1], [1, 1], [1, 0]]
const UV_BOT := [[0, 0], [1, 0], [1, 1], [0, 1]]


class Buf:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var c := PackedColorArray()
	var uv := PackedVector2Array()
	var i := PackedInt32Array()


static func build(blocks: PackedByteArray, nxb: PackedByteArray, pxb: PackedByteArray,
		nzb: PackedByteArray, pzb: PackedByteArray) -> Dictionary:
	var opaque := Buf.new()
	var water := Buf.new()
	var tile_top := PackedInt32Array(Blocks.TILE_TOP)
	var tile_side := PackedInt32Array(Blocks.TILE_SIDE)
	var tile_bot := PackedInt32Array(Blocks.TILE_BOTTOM)
	var opq := PackedByteArray(Blocks.OPAQUE)

	# Per-column "sky" height (first block that is not air/water/leaves) for cheap
	# cave darkening, plus the highest non-air block so we can stop looping early.
	var tops := PackedInt32Array()
	tops.resize(CS * CS)
	var maxy := 0
	for z in CS:
		for x in CS:
			var y := CH - 1
			var seen := false
			while y > 0:
				var bb: int = blocks[(y * CS + z) * CS + x]
				if bb != 0 and not seen:
					seen = true
					if y > maxy:
						maxy = y
				if bb != 0 and opq[bb] == 1:
					break
				y -= 1
			tops[z * CS + x] = y

	for y in range(0, maxy + 1):
		for z in CS:
			for x in CS:
				var i := (y * CS + z) * CS + x
				var b: int = blocks[i]
				if b == 0:
					continue
				var n0: int = blocks[i + 1] if x < CS - 1 else pxb[i - 15]
				var n1: int = blocks[i - 1] if x > 0 else nxb[i + 15]
				var n2: int = blocks[i + 256] if y < CH - 1 else 0
				var n3: int = blocks[i - 256] if y > 0 else 1
				var n4: int = blocks[i + 16] if z < CS - 1 else pzb[i - 240]
				var n5: int = blocks[i - 16] if z > 0 else nzb[i + 240]

				if b == Blocks.WATER:
					var drop := 0.12 if n2 == 0 else 0.0
					var wt: int = tile_top[b]
					if n0 == 0:
						_emit(water, 0, x, y, z, wt, 1.0, drop)
					if n1 == 0:
						_emit(water, 1, x, y, z, wt, 1.0, drop)
					if n2 == 0:
						_emit(water, 2, x, y, z, wt, 1.0, drop)
					if n4 == 0:
						_emit(water, 4, x, y, z, wt, 1.0, drop)
					if n5 == 0:
						_emit(water, 5, x, y, z, wt, 1.0, drop)
					continue

				if opq[n0] == 0 and n0 != b:
					_emit(opaque, 0, x, y, z, tile_side[b], _light(0, x, y, z, tops), 0.0)
				if opq[n1] == 0 and n1 != b:
					_emit(opaque, 1, x, y, z, tile_side[b], _light(1, x, y, z, tops), 0.0)
				if opq[n2] == 0 and n2 != b:
					_emit(opaque, 2, x, y, z, tile_top[b], _light(2, x, y, z, tops), 0.0)
				if opq[n3] == 0 and n3 != b:
					_emit(opaque, 3, x, y, z, tile_bot[b], _light(3, x, y, z, tops), 0.0)
				if opq[n4] == 0 and n4 != b:
					_emit(opaque, 4, x, y, z, tile_side[b], _light(4, x, y, z, tops), 0.0)
				if opq[n5] == 0 and n5 != b:
					_emit(opaque, 5, x, y, z, tile_side[b], _light(5, x, y, z, tops), 0.0)

	return {"o": _to_arrays(opaque), "w": _to_arrays(water)}


## 1.0 in open air, darker the deeper the air cell in front of the face is below the sky.
static func _light(d: int, x: int, y: int, z: int, tops: PackedInt32Array) -> float:
	var cx := x
	var cz := z
	var ya := y
	match d:
		0:
			cx += 1
		1:
			cx -= 1
		2:
			ya += 1
		3:
			ya -= 1
		4:
			cz += 1
		5:
			cz -= 1
	if cx < 0 or cx >= CS or cz < 0 or cz >= CS:
		cx = x
		cz = z
	var depth := tops[cz * CS + cx] - ya
	if depth <= 0:
		return 1.0
	return clampf(1.0 - float(depth) * 0.15, 0.3, 1.0)


static func _uv_set(d: int) -> Array:
	if d == 2:
		return UV_TOP
	if d == 3:
		return UV_BOT
	return UV_SIDE


static func _emit(buf: Buf, d: int, x: int, y: int, z: int, tile: int, light: float, top_drop: float) -> void:
	var base := buf.v.size()
	var fv: Array = FACE_V[d]
	var uvs: Array = _uv_set(d)
	var u0 := float(tile & 15) / 16.0 + EPS
	var v0 := float(tile >> 4) / 16.0 + EPS
	var u1 := u0 + 1.0 / 16.0 - 2.0 * EPS
	var v1 := v0 + 1.0 / 16.0 - 2.0 * EPS
	var l: float = light * float(FACE_SHADE[d])
	var col := Color(l, l, l, 1.0)
	var nrm: Vector3 = FACE_N[d]
	for k in 4:
		var c: Vector3 = fv[k]
		var yy := y + c.y
		if top_drop > 0.0 and c.y > 0.5:
			yy -= top_drop
		buf.v.append(Vector3(x + c.x, yy, z + c.z))
		buf.n.append(nrm)
		buf.c.append(col)
		var uk: Array = uvs[k]
		buf.uv.append(Vector2(u1 if uk[0] == 1 else u0, v1 if uk[1] == 1 else v0))
	buf.i.append(base)
	buf.i.append(base + 2)
	buf.i.append(base + 1)
	buf.i.append(base)
	buf.i.append(base + 3)
	buf.i.append(base + 2)


static func _to_arrays(b: Buf) -> Array:
	if b.v.is_empty():
		return []
	var a := []
	a.resize(Mesh.ARRAY_MAX)
	a[Mesh.ARRAY_VERTEX] = b.v
	a[Mesh.ARRAY_NORMAL] = b.n
	a[Mesh.ARRAY_COLOR] = b.c
	a[Mesh.ARRAY_TEX_UV] = b.uv
	a[Mesh.ARRAY_INDEX] = b.i
	return a


## Cheap structural check of a surface (O(1)). Returns "" if OK, else a description.
## Run on the worker thread so a malformed mesh is never handed to the renderer.
static func validate(a: Array) -> String:
	if a.is_empty():
		return ""
	if a.size() != Mesh.ARRAY_MAX:
		return "array slots %d" % a.size()
	var n: int = (a[Mesh.ARRAY_VERTEX] as PackedVector3Array).size()
	if n == 0 or n % 4 != 0:
		return "vertex count %d" % n
	if (a[Mesh.ARRAY_NORMAL] as PackedVector3Array).size() != n:
		return "normal count mismatch"
	if (a[Mesh.ARRAY_COLOR] as PackedColorArray).size() != n:
		return "colour count mismatch"
	if (a[Mesh.ARRAY_TEX_UV] as PackedVector2Array).size() != n:
		return "uv count mismatch"
	if (a[Mesh.ARRAY_INDEX] as PackedInt32Array).size() != n / 4 * 6:
		return "index count mismatch"
	return ""


## Unit cube (centered on the origin) with 0..1 UVs per face; used for the block
## outline / mining-crack overlay. `grow` inflates it slightly to avoid z-fighting.
static func cube_mesh(grow: float) -> ArrayMesh:
	var b := Buf.new()
	for d in 6:
		var base := b.v.size()
		var fv: Array = FACE_V[d]
		var uvs: Array = _uv_set(d)
		for k in 4:
			var c: Vector3 = fv[k]
			b.v.append((c - Vector3(0.5, 0.5, 0.5)) * (1.0 + grow))
			b.n.append(FACE_N[d])
			b.c.append(Color.WHITE)
			var uk: Array = uvs[k]
			b.uv.append(Vector2(float(uk[0]), float(uk[1])))
		b.i.append(base)
		b.i.append(base + 2)
		b.i.append(base + 1)
		b.i.append(base)
		b.i.append(base + 3)
		b.i.append(base + 2)
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, _to_arrays(b))
	return m
