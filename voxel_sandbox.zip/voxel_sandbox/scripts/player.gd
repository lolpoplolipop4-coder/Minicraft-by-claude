class_name Player
extends Node3D
## First-person player. `position` is the position of the FEET.
## Input comes from the HUD (touch) with keyboard fallback for desktop testing.

signal died

const HALF_W := 0.3
const HEIGHT := 1.78
const EYE := 1.6
const GRAVITY := 30.0
const JUMP_V := 8.6
const WALK := 4.3
const SPRINT := 6.0
const SNEAK := 1.6
const REACH := 5.0

const OVERLAY_SHADER := """
shader_type spatial;
render_mode unshaded, depth_draw_never, cull_back, blend_mix;
uniform float progress = 0.0;
void fragment() {
	vec2 d = min(UV, vec2(1.0) - UV);
	float e = min(d.x, d.y);
	float edge = 1.0 - step(0.04, e);
	ALBEDO = vec3(0.0);
	ALPHA = clamp(edge * 0.85 + progress * 0.5, 0.0, 1.0);
}
"""

var world: World
var hud: HUD
var inv: Inventory
var main: Node
var cam: Camera3D

var vel := Vector3.ZERO
var yaw := 0.0
var pitch := 0.0
var on_ground := false
var in_water := false
var head_in_water := false
var health := 20.0
var hunger := 20.0
var alive := true
var spawn_point := Vector3.ZERO

var target: Dictionary = {}
var mining := false
var mining_pos := Vector3i.ZERO
var mining_t := 0.0
var mine_pause := 0.0
var attack_cd := 0.0
var place_cd := 0.0
var hurt_timer := 0.0
var regen_t := 0.0
var starve_t := 0.0
var fall_peak := 0.0
var sprinting := false
var creative := false   # creative mode: no damage/hunger, flight, instant break, unlimited blocks
var flying := false
var _jump_prev := false
var _last_jump_ms := -10000
var _look := Vector2.ZERO
var _was_in_water := false
var _fishing_active := false
var _fishing_bite := false
var _fishing_timer := 0.0
var _fishing_timeout := 0.0
var _outline: MeshInstance3D
var _outline_mat: ShaderMaterial


func _ready() -> void:
	cam = Camera3D.new()
	cam.position = Vector3(0, EYE, 0)
	cam.fov = 72.0
	cam.near = 0.08
	cam.far = 160.0
	add_child(cam)
	cam.make_current()
	var sh := Shader.new()
	sh.code = OVERLAY_SHADER
	_outline_mat = ShaderMaterial.new()
	_outline_mat.shader = sh
	_outline = MeshInstance3D.new()
	_outline.mesh = Mesher.cube_mesh(0.006)
	_outline.material_override = _outline_mat
	_outline.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_outline.top_level = true
	_outline.visible = false
	add_child(_outline)


func setup(w: World, h: HUD, i: Inventory, m: Node) -> void:
	world = w
	hud = h
	inv = i
	main = m
	fall_peak = position.y


func _process(delta: float) -> void:
	if world == null or main.paused:
		_outline.visible = false
		return
	_apply_look(delta)
	if alive:
		_update_flight_toggle()
		var remaining := minf(delta, 0.1)
		while remaining > 0.0:
			var dt := minf(remaining, 1.0 / 60.0)
			_physics_step(dt)
			remaining -= dt
		_update_target()
		_handle_actions(delta)
		_update_vitals(delta)
		_update_fishing(delta)
	else:
		_outline.visible = false
	_update_camera(delta)


# ------------------------------------------------------------------ look

func _apply_look(delta: float) -> void:
	_look += hud.consume_look() * Settings.look_speed
	var k := 1.0 - exp(-delta * 28.0)
	var step := _look * k
	_look -= step
	yaw -= step.x
	pitch = clampf(pitch - step.y, -89.0, 89.0)
	rotation_degrees.y = yaw
	cam.rotation_degrees.x = pitch


func _update_camera(delta: float) -> void:
	var sneak := hud.sneak_held or Input.is_key_pressed(KEY_SHIFT)
	var eye := EYE - (0.2 if sneak else 0.0)
	cam.position.y = lerpf(cam.position.y, eye, minf(1.0, delta * 12.0))
	var fov := 72.0
	if sprinting:
		fov = 80.0
	cam.fov = lerpf(cam.fov, fov, minf(1.0, delta * 8.0))
	hud.underwater = head_in_water
	hud.hurt_flash = maxf(hurt_timer, 0.0)
	hurt_timer -= delta


## Creative: double-tap JUMP toggles flight.
func _update_flight_toggle() -> void:
	var j := hud.jump_held or Input.is_key_pressed(KEY_SPACE)
	if creative and j and not _jump_prev:
		var now := Time.get_ticks_msec()
		if now - _last_jump_ms < 350:
			flying = not flying
			vel.y = 0.0
			hud.show_toast("Полёт включён" if flying else "Полёт выключен")
			_last_jump_ms = -10000
		else:
			_last_jump_ms = now
	_jump_prev = j


func _key_vec() -> Vector2:
	var v := Vector2.ZERO
	if Input.is_key_pressed(KEY_A):
		v.x -= 1.0
	if Input.is_key_pressed(KEY_D):
		v.x += 1.0
	if Input.is_key_pressed(KEY_W):
		v.y -= 1.0
	if Input.is_key_pressed(KEY_S):
		v.y += 1.0
	return v


# ------------------------------------------------------------------ movement

func _physics_step(dt: float) -> void:
	# If the chunk under the player is not loaded yet, wait instead of falling into the void.
	if world.get_block(floori(position.x), clampi(floori(position.y), 0, World.CH - 1), floori(position.z)) == -1:
		vel = Vector3.ZERO
		fall_peak = position.y
		return
	var mv := hud.move_vec + _key_vec()
	if mv.length() > 1.0:
		mv = mv.normalized()
	var bs := global_transform.basis
	var wish := bs.x * mv.x + (-bs.z) * (-mv.y)
	wish.y = 0.0

	in_water = world.get_block(floori(position.x), floori(position.y + 0.3), floori(position.z)) == Blocks.WATER
	head_in_water = world.get_block(floori(position.x), floori(position.y + EYE), floori(position.z)) == Blocks.WATER
	if in_water and not _was_in_water and absf(vel.y) > 1.0:
		main.burst(position + Vector3(0, 0.9, 0), Color(0.55, 0.75, 1.0), 16, 4.0)
		if main.has_method("play_sfx"):
			main.play_sfx("splash")
	_was_in_water = in_water

	var sneaking := (hud.sneak_held or Input.is_key_pressed(KEY_SHIFT)) and not in_water
	if mv.length() < 0.05 and hud.sprint_on:
		hud.sprint_on = false
	sprinting = (hud.sprint_on or Input.is_key_pressed(KEY_CTRL)) and hunger > 6.0 and mv.y < -0.2 and not sneaking
	var speed := WALK
	if sprinting:
		speed = SPRINT
	elif sneaking:
		speed = SNEAK
	if in_water:
		speed *= 0.6
	if flying:
		speed *= 1.8

	var tv := wish * speed
	var accel := 60.0 if on_ground else 18.0
	if in_water:
		accel = 14.0 if Settings.water_physics else 20.0
		vel.x = move_toward(vel.x, tv.x, accel * dt)
		vel.z = move_toward(vel.z, tv.z, accel * dt)
		var drag := 0.65 if Settings.water_physics else 0.2
		vel.x *= 1.0 - drag * dt
		vel.z *= 1.0 - drag * dt
	else:
		vel.x = move_toward(vel.x, tv.x, accel * dt)
		vel.z = move_toward(vel.z, tv.z, accel * dt)

	var jump := hud.jump_held or Input.is_key_pressed(KEY_SPACE)
	if flying:
		var fy := 0.0
		if jump:
			fy += 7.0
		if hud.sneak_held or Input.is_key_pressed(KEY_SHIFT):
			fy -= 7.0
		vel.y = move_toward(vel.y, fy, 40.0 * dt)
	elif in_water:
		vel.y -= (4.0 if Settings.water_physics else 8.0) * dt
		if Settings.water_physics and head_in_water:
			vel.y += 1.6 * dt
		if jump:
			vel.y += 18.0 * dt
		vel.y = clampf(vel.y, -2.0 if Settings.water_physics else -5.0, 3.2)
	else:
		vel.y = maxf(vel.y - GRAVITY * dt, -45.0)
		if jump and on_ground:
			vel.y = JUMP_V
			on_ground = false

	# Sneaking never walks off an edge.
	if sneaking and on_ground and not flying:
		if not _has_ground(position + Vector3(vel.x, 0, 0) * dt):
			vel.x = 0.0
		if not _has_ground(position + Vector3(0, 0, vel.z) * dt):
			vel.z = 0.0

	var r := world.move_box(position, vel, HALF_W, HEIGHT, dt)
	position = r["pos"]
	vel = r["vel"]
	on_ground = r["grounded"]
	if flying and on_ground and (hud.sneak_held or Input.is_key_pressed(KEY_SHIFT)):
		flying = false # landed

	# Auto-jump over single-block steps: essential for touch controls.
	if r["walled"] and on_ground and mv.length() > 0.3 and not sneaking and not flying and wish.length() > 0.01:
		var f := wish.normalized() * (HALF_W + 0.35)
		var bx := floori(position.x + f.x)
		var bz := floori(position.z + f.z)
		var by := floori(position.y + 0.05)
		if world.is_solid(bx, by, bz) and not world.is_solid(bx, by + 1, bz) \
				and not world.is_solid(bx, by + 2, bz) \
				and not world.is_solid(floori(position.x), by + 2, floori(position.z)):
			vel.y = JUMP_V - 0.3
			on_ground = false

	# Fall damage.
	if flying:
		fall_peak = position.y
	elif on_ground or in_water:
		var fall := fall_peak - position.y
		if fall > 3.5 and not in_water:
			damage(floorf(fall - 3.0), position + Vector3(0, 1, 0), false)
		fall_peak = position.y
	else:
		fall_peak = maxf(fall_peak, position.y)

	if position.y < -20.0:
		damage(100.0, position, false)


func _has_ground(p: Vector3) -> bool:
	return world.is_solid(floori(p.x), floori(p.y - 0.5), floori(p.z))


# ------------------------------------------------------------------ interaction

func _update_target() -> void:
	var o := cam.global_position
	var dir := -cam.global_transform.basis.z
	target = world.raycast(o, dir, REACH)
	if target.get("hit", false) and not main.paused:
		var bp: Vector3i = target["pos"]
		_outline.visible = true
		_outline.global_position = Vector3(bp) + Vector3(0.5, 0.5, 0.5)
	else:
		_outline.visible = false


func _handle_actions(delta: float) -> void:
	attack_cd -= delta
	place_cd -= delta
	mine_pause -= delta
	var held := inv.held_id()

	if hud.break_held:
		var mob := _target_mob()
		var ani: Animal = null
		if mob == null and main.has_method("nearest_animal"):
			ani = main.nearest_animal(cam.global_position, -cam.global_transform.basis.z, REACH)
		if mob != null:
			_mining_reset()
			if attack_cd <= 0.0:
				attack_cd = 0.45
				var dir := ((mob as Node3D).position - position)
				dir.y = 0.0
				(mob as Node3D).call("hurt", Items.attack_damage(held), dir.normalized())
		elif ani != null:
			_mining_reset()
			if attack_cd <= 0.0:
				attack_cd = 0.45
				var dir := (ani.position - position)
				dir.y = 0.0
				ani.hurt(Items.attack_damage(held), dir.normalized())
		elif target.get("hit", false) and mine_pause <= 0.0:
			_mine(delta, held)
		else:
			_mining_reset()
	else:
		_mining_reset()

	var tap := hud.consume_place_tap()
	if tap or (hud.place_held and place_cd <= 0.0):
		_place_or_use(held)
		place_cd = 0.14 if creative else 0.28


func _mining_reset() -> void:
	mining = false
	mining_t = 0.0
	_outline_mat.set_shader_parameter("progress", 0.0)


func _mine(delta: float, held: int) -> void:
	var bp: Vector3i = target["pos"]
	var id: int = target["id"]
	if not mining or bp != mining_pos:
		mining = true
		mining_pos = bp
		mining_t = 0.0
	var bt := Blocks.break_time(id, held)
	if creative and bt > 0.0:
		bt = 0.05
	if bt < 0.0:
		return
	mining_t += delta
	hunger -= delta * 0.01
	_outline_mat.set_shader_parameter("progress", clampf(mining_t / bt, 0.0, 1.0))
	if mining_t >= bt:
		_break_block(bp, id, held)
		_mining_reset()
		mine_pause = 0.1 if creative else 0.15


func _break_block(bp: Vector3i, id: int, held: int) -> void:
	# Crop harvest gives wheat and a small seed return.
	if id == Blocks.WHEAT_MATURE and not creative:
		_give(Items.WHEAT)
		if randf() < 0.65: _give(Items.SEEDS)
		world.set_block(bp.x, bp.y, bp.z, Blocks.AIR)
		return
	# Doors and beds occupy two cells; mining either half removes the complete object.
	if id == Blocks.DOOR or id == Blocks.DOOR_OPEN:
		var door_y := bp.y
		if bp.y > 0 and (world.get_block(bp.x, bp.y - 1, bp.z) == Blocks.DOOR or world.get_block(bp.x, bp.y - 1, bp.z) == Blocks.DOOR_OPEN):
			door_y -= 1
		world.set_block(bp.x, door_y, bp.z, Blocks.AIR)
		world.set_block(bp.x, door_y + 1, bp.z, Blocks.AIR)
	elif id == Blocks.BED:
		world.set_block(bp.x, bp.y, bp.z, Blocks.AIR)
		if world.get_block(bp.x + 1, bp.y, bp.z) == Blocks.BED:
			world.set_block(bp.x + 1, bp.y, bp.z, Blocks.AIR)
		elif world.get_block(bp.x - 1, bp.y, bp.z) == Blocks.BED:
			world.set_block(bp.x - 1, bp.y, bp.z, Blocks.AIR)
	else:
		world.set_block(bp.x, bp.y, bp.z, Blocks.AIR)
	if main != null and main.has_method("play_sfx"):
		main.play_sfx("break", id)
	main.burst(Vector3(bp) + Vector3(0.5, 0.5, 0.5), Blocks.particle_color(id), 14, 3.5)
	if creative:
		return # creative mode collects nothing
	if id == Blocks.LEAVES:
		var roll := randf()
		if roll < 0.06:
			_give(Items.APPLE)
		elif roll < 0.18:
			_give(Items.STICK)
		elif roll < 0.34:
			_give(Blocks.SAPLING)
		elif roll < 0.50:
			_give(Items.SEEDS)
		return
	if Blocks.can_harvest(id, held):
		_give(Blocks.drop_for(id))


func _give(item: int) -> void:
	if item == 0:
		return
	var left := inv.add(item, 1)
	if left > 0:
		hud.show_toast("Inventory full!")


func _water_in_front() -> bool:
	var origin := cam.global_position
	var direction := -cam.global_transform.basis.z
	for step in range(1, 11):
		var p := origin + direction * (float(step) * 0.5)
		if world.get_block(floori(p.x), floori(p.y), floori(p.z)) == Blocks.WATER:
			return true
	return false


func _use_fishing_rod() -> void:
	if _fishing_active:
		if _fishing_bite:
			var caught := Items.FISH
			if randf() < 0.12:
				caught = Items.FEATHER
			_give(caught)
			if main.has_method("play_sfx"):
				main.play_sfx("splash")
			hud.show_toast("Улов: %s" % Items.item_name(caught))
		else:
			hud.show_toast("Рыба сорвалась!")
		_fishing_active = false
		_fishing_bite = false
		return
	if not _water_in_front():
		hud.show_toast("Закинь удочку в воду")
		return
	_fishing_active = true
	_fishing_bite = false
	_fishing_timer = 0.0
	_fishing_timeout = randf_range(2.5, 7.0)
	hud.show_toast("Поплавок в воде… жди поклёвку")


func _update_fishing(delta: float) -> void:
	if not _fishing_active or _fishing_bite:
		return
	_fishing_timer += delta
	if _fishing_timer >= _fishing_timeout:
		_fishing_bite = true
		hud.show_toast("ПОКЛЁВКА! Нажми PLACE!")
		if main.has_method("play_sfx"):
			main.play_sfx("splash")


func _place_or_use(held: int) -> void:
	# Basic voxel farming: a shovel tills grass/dirt, seeds are planted on tilled soil.
	if target.get("hit", false):
		var farm_target: Vector3i = target["pos"]
		var farm_id := int(target["id"])
		if Items.is_tool(held) and Items.tool_kind(held) == 2 and farm_id in [Blocks.GRASS, Blocks.DIRT]:
			if world.get_block(farm_target.x, farm_target.y + 1, farm_target.z) == Blocks.AIR:
				world.set_block(farm_target.x, farm_target.y, farm_target.z, Blocks.FARMLAND_WET if _farm_has_water(farm_target) else Blocks.FARMLAND)
				hud.show_toast("Земля вспахана")
			return
		if farm_id in [Blocks.FARMLAND, Blocks.FARMLAND_WET] and held == Items.SEEDS:
			var crop_pos := farm_target + Vector3i.UP
			if world.get_block(crop_pos.x, crop_pos.y, crop_pos.z) == Blocks.AIR:
				if world.set_block(crop_pos.x, crop_pos.y, crop_pos.z, Blocks.WHEAT_SEEDLING) and not creative:
					inv.consume_held()
				hud.show_toast("Семена посажены")
			return
	if held == Items.FISHING_ROD:
		_use_fishing_rod()
		return
	# Interactions work when either half of a two-block door/bed is targeted.
	if target.get("hit", false):
		var target_pos: Vector3i = target["pos"]
		var target_id: int = int(target["id"])
		if target_id == Blocks.TABLE:
			main.open_station("table", target_pos)
			return
		if target_id == Blocks.FURNACE:
			main.open_station("furnace", target_pos)
			return
		if target_id == Blocks.CHEST:
			main.open_station("chest", target_pos)
			return
		if target_id == Blocks.BED:
			if main != null:
				main.time_of_day = 0.25
				main.hud.show_toast("Утро! Вы поспали")
				if main.has_method("play_sfx"):
					main.play_sfx("sleep")
			return
		if target_id == Blocks.LEVER or target_id == Blocks.LEVER_ON:
			var lever_id := Blocks.LEVER_ON if target_id == Blocks.LEVER else Blocks.LEVER
			world.set_block(target_pos.x, target_pos.y, target_pos.z, lever_id)
			if main.has_method("play_sfx"):
				main.play_sfx("door")
			return
		if target_id == Blocks.BUTTON:
			world.set_block(target_pos.x, target_pos.y, target_pos.z, Blocks.PRESSURE_PLATE)
			if main.has_method("play_sfx"):
				main.play_sfx("place", target_id)
			return
		if target_id == Blocks.DOOR or target_id == Blocks.DOOR_OPEN:
			var low_y := target_pos.y
			if target_pos.y > 0 and world.get_block(target_pos.x, target_pos.y - 1, target_pos.z) in [Blocks.DOOR, Blocks.DOOR_OPEN]:
				low_y -= 1
			var next_id := Blocks.DOOR_OPEN if target_id == Blocks.DOOR else Blocks.DOOR
			world.set_block(target_pos.x, low_y, target_pos.z, next_id)
			world.set_block(target_pos.x, low_y + 1, target_pos.z, next_id)
			main.hud.show_toast("Дверь открыта" if next_id == Blocks.DOOR_OPEN else "Дверь закрыта")
			if main.has_method("play_sfx"):
				main.play_sfx("door")
			return
	if held == 0:
		return
	if Items.is_food(held):
		if hunger < 20.0:
			hunger = minf(20.0, hunger + Items.food_value(held))
			inv.consume_held()
			if main.has_method("play_sfx"):
				main.play_sfx("eat")
		return
	if not Items.is_block(held) or not target.get("hit", false):
		return
	var np: Vector3i = Vector3i(target["pos"]) + Vector3i(target["normal"])
	if np.y < 0 or np.y >= World.CH:
		return
	if held == Blocks.DOOR:
		if np.y + 1 >= World.CH or world.get_block(np.x, np.y, np.z) not in [Blocks.AIR, Blocks.WATER] or world.get_block(np.x, np.y + 1, np.z) not in [Blocks.AIR, Blocks.WATER]:
			return
		if _intersects_player(np) or _intersects_player(np + Vector3i.UP):
			return
		if world.set_block(np.x, np.y, np.z, Blocks.DOOR) and world.set_block(np.x, np.y + 1, np.z, Blocks.DOOR):
			if not creative:
				inv.consume_held()
			if main.has_method("play_sfx"):
				main.play_sfx("place", held)
		return
	if held == Blocks.BED:
		var second := np + Vector3i(1, 0, 0)
		if world.get_block(np.x, np.y, np.z) not in [Blocks.AIR, Blocks.WATER] or world.get_block(second.x, second.y, second.z) not in [Blocks.AIR, Blocks.WATER]:
			return
		if _intersects_player(np) or _intersects_player(second):
			return
		if world.set_block(np.x, np.y, np.z, Blocks.BED) and world.set_block(second.x, second.y, second.z, Blocks.BED):
			if not creative:
				inv.consume_held()
			if main.has_method("play_sfx"):
				main.play_sfx("place", held)
		return
	var cur := world.get_block(np.x, np.y, np.z)
	if cur != Blocks.AIR and cur != Blocks.WATER:
		return
	if _intersects_player(np):
		return
	if world.set_block(np.x, np.y, np.z, held):
		if not creative:
			inv.consume_held()
		if main.has_method("play_sfx"):
			main.play_sfx("place", held)


func _farm_has_water(at: Vector3i) -> bool:
	# Classic 4-block horizontal irrigation radius.
	for dz in range(-4, 5):
		for dx in range(-4, 5):
			if world.get_block(at.x + dx, at.y, at.z + dz) == Blocks.WATER or world.get_block(at.x + dx, at.y + 1, at.z + dz) == Blocks.WATER:
				return true
	return false


func _intersects_player(b: Vector3i) -> bool:
	var mn := Vector3(position.x - HALF_W, position.y, position.z - HALF_W)
	var mx := Vector3(position.x + HALF_W, position.y + HEIGHT, position.z + HALF_W)
	return mx.x > b.x and mn.x < b.x + 1 and mx.y > b.y and mn.y < b.y + 1 and mx.z > b.z and mn.z < b.z + 1


func _target_mob() -> Node3D:
	var best: Node3D = null
	var best_d := 3.6
	var look := -cam.global_transform.basis.z
	for m in main.mobs:
		if not is_instance_valid(m):
			continue
		var to: Vector3 = (m.position + Vector3(0, 0.9, 0)) - cam.global_position
		var d := to.length()
		if d < best_d and to.normalized().dot(look) > 0.92:
			best = m
			best_d = d
	return best


func near_table() -> bool:
	var px := floori(position.x)
	var py := floori(position.y)
	var pz := floori(position.z)
	for dy in range(-2, 4):
		for dz in range(-4, 5):
			for dx in range(-4, 5):
				if world.get_block(px + dx, py + dy, pz + dz) == Blocks.TABLE:
					return true
	return false


func near_furnace() -> bool:
	var px := floori(position.x)
	var py := floori(position.y)
	var pz := floori(position.z)
	for dy in range(-2, 4):
		for dz in range(-3, 4):
			for dx in range(-3, 4):
				if world.get_block(px + dx, py + dy, pz + dz) == Blocks.FURNACE:
					return true
	return false


# ------------------------------------------------------------------ vitals

func _update_vitals(delta: float) -> void:
	if creative:
		health = 20.0
		hunger = 20.0
		return
	var drain := 0.02
	if sprinting:
		drain += 0.03
	hunger = maxf(0.0, hunger - drain * delta)
	if hunger >= 16.0 and health < 20.0:
		regen_t += delta
		if regen_t >= 2.5:
			regen_t = 0.0
			health = minf(20.0, health + 1.0)
			hunger = maxf(0.0, hunger - 0.3)
	elif hunger <= 0.0:
		starve_t += delta
		if starve_t >= 4.0:
			starve_t = 0.0
			damage(1.0, position, false)


func damage(amount: float, from: Vector3, knockback: bool = true) -> void:
	if creative or not alive or amount <= 0.0:
		return
	health -= amount
	hurt_timer = 0.4
	if knockback:
		var d := position - from
		d.y = 0.0
		if d.length() > 0.01:
			vel += d.normalized() * 5.0
		vel.y = 4.5
	if health <= 0.0:
		health = 0.0
		alive = false
		died.emit()


## Lifts a position upward until there is room to stand (the spawn spot may have been built over).
func _free_spot(p: Vector3) -> Vector3:
	var x := floori(p.x)
	var z := floori(p.z)
	var y := clampi(floori(p.y), 1, World.CH - 3)
	var start_y := y
	for k in 12:
		if world.get_block(x, y, z) == -1:
			break # chunk not loaded: keep the spot, physics waits for it
		if not world.is_solid(x, y, z) and not world.is_solid(x, y + 1, z):
			break
		if y >= World.CH - 3:
			break
		y += 1
	if y == start_y:
		return p
	return Vector3(p.x, float(y), p.z)


func respawn() -> void:
	position = _free_spot(spawn_point)
	vel = Vector3.ZERO
	health = 20.0
	hunger = 20.0
	alive = true
	fall_peak = position.y
