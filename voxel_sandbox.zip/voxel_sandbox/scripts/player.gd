class_name Player
extends Node3D
## First-person player. `position` is the position of the FEET.
## Input comes from the HUD (touch) with keyboard fallback for desktop testing.

signal died

const HALF_W := 0.3
const HEIGHT := 1.78
const EYE := 1.6
const GRAVITY := 30.0
const JUMP_V := 8.6
const WALK := 4.3
const SPRINT := 6.0
const SNEAK := 1.6
const REACH := 5.0

const OVERLAY_SHADER := """
shader_type spatial;
render_mode unshaded, depth_draw_never, cull_back, blend_mix;
uniform float progress = 0.0;
void fragment() {
	vec2 d = min(UV, vec2(1.0) - UV);
	float e = min(d.x, d.y);
	float edge = 1.0 - step(0.04, e);
	ALBEDO = vec3(0.0);
	ALPHA = clamp(edge * 0.85 + progress * 0.5, 0.0, 1.0);
}
"""

var world: World
var hud: HUD
var inv: Inventory
var main: Node
var cam: Camera3D

var vel := Vector3.ZERO
var yaw := 0.0
var pitch := 0.0
var on_ground := false
var in_water := false
var head_in_water := false
var health := 20.0
var hunger := 20.0
var alive := true
var spawn_point := Vector3.ZERO

var target: Dictionary = {}
var mining := false
var mining_pos := Vector3i.ZERO
var mining_t := 0.0
var mine_pause := 0.0
var attack_cd := 0.0
var place_cd := 0.0
var hurt_timer := 0.0
var regen_t := 0.0
var starve_t := 0.0
var fall_peak := 0.0
var sprinting := false
var _look := Vector2.ZERO
var _was_in_water := false
var _outline: MeshInstance3D
var _outline_mat: ShaderMaterial


func _ready() -> void:
	cam = Camera3D.new()
	cam.position = Vector3(0, EYE, 0)
	cam.fov = 72.0
	cam.near = 0.08
	cam.far = 160.0
	add_child(cam)
	cam.make_current()
	var sh := Shader.new()
	sh.code = OVERLAY_SHADER
	_outline_mat = ShaderMaterial.new()
	_outline_mat.shader = sh
	_outline = MeshInstance3D.new()
	_outline.mesh = Mesher.cube_mesh(0.006)
	_outline.material_override = _outline_mat
	_outline.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_outline.top_level = true
	_outline.visible = false
	add_child(_outline)


func setup(w: World, h: HUD, i: Inventory, m: Node) -> void:
	world = w
	hud = h
	inv = i
	main = m
	fall_peak = position.y


func _process(delta: float) -> void:
	if world == null or main.paused:
		_outline.visible = false
		return
	_apply_look(delta)
	if alive:
		var remaining := minf(delta, 0.1)
		while remaining > 0.0:
			var dt := minf(remaining, 1.0 / 60.0)
			_physics_step(dt)
			remaining -= dt
		_update_target()
		_handle_actions(delta)
		_update_vitals(delta)
	else:
		_outline.visible = false
	_update_camera(delta)


# ------------------------------------------------------------------ look

func _apply_look(delta: float) -> void:
	_look += hud.consume_look() * Settings.look_speed
	var k := 1.0 - exp(-delta * 28.0)
	var step := _look * k
	_look -= step
	yaw -= step.x
	pitch = clampf(pitch - step.y, -89.0, 89.0)
	rotation_degrees.y = yaw
	cam.rotation_degrees.x = pitch


func _update_camera(delta: float) -> void:
	var sneak := hud.sneak_held or Input.is_key_pressed(KEY_SHIFT)
	var eye := EYE - (0.2 if sneak else 0.0)
	cam.position.y = lerpf(cam.position.y, eye, minf(1.0, delta * 12.0))
	var fov := 72.0
	if sprinting:
		fov = 80.0
	cam.fov = lerpf(cam.fov, fov, minf(1.0, delta * 8.0))
	hud.underwater = head_in_water
	hud.hurt_flash = maxf(hurt_timer, 0.0)
	hurt_timer -= delta


func _key_vec() -> Vector2:
	var v := Vector2.ZERO
	if Input.is_key_pressed(KEY_A):
		v.x -= 1.0
	if Input.is_key_pressed(KEY_D):
		v.x += 1.0
	if Input.is_key_pressed(KEY_W):
		v.y -= 1.0
	if Input.is_key_pressed(KEY_S):
		v.y += 1.0
	return v


# ------------------------------------------------------------------ movement

func _physics_step(dt: float) -> void:
	var mv := hud.move_vec + _key_vec()
	if mv.length() > 1.0:
		mv = mv.normalized()
	var bs := global_transform.basis
	var wish := bs.x * mv.x + (-bs.z) * (-mv.y)
	wish.y = 0.0

	in_water = world.get_block(floori(position.x), floori(position.y + 0.3), floori(position.z)) == Blocks.WATER
	head_in_water = world.get_block(floori(position.x), floori(position.y + EYE), floori(position.z)) == Blocks.WATER
	if in_water and not _was_in_water and absf(vel.y) > 2.0:
		main.burst(position + Vector3(0, 0.9, 0), Color(0.55, 0.75, 1.0), 16, 4.0)
	_was_in_water = in_water

	var sneaking := (hud.sneak_held or Input.is_key_pressed(KEY_SHIFT)) and not in_water
	if mv.length() < 0.05 and hud.sprint_on:
		hud.sprint_on = false
	sprinting = (hud.sprint_on or Input.is_key_pressed(KEY_CTRL)) and hunger > 6.0 and mv.y < -0.2 and not sneaking
	var speed := WALK
	if sprinting:
		speed = SPRINT
	elif sneaking:
		speed = SNEAK
	if in_water:
		speed *= 0.6

	var tv := wish * speed
	var accel := 60.0 if on_ground else 18.0
	if in_water:
		accel = 14.0
	vel.x = move_toward(vel.x, tv.x, accel * dt)
	vel.z = move_toward(vel.z, tv.z, accel * dt)

	var jump := hud.jump_held or Input.is_key_pressed(KEY_SPACE)
	if in_water:
		vel.y -= 4.0 * dt
		if jump:
			vel.y += 18.0 * dt
		vel.y = clampf(vel.y, -2.0, 3.2)
	else:
		vel.y = maxf(vel.y - GRAVITY * dt, -45.0)
		if jump and on_ground:
			vel.y = JUMP_V
			on_ground = false

	# Sneaking never walks off an edge.
	if sneaking and on_ground:
		if not _has_ground(position + Vector3(vel.x, 0, 0) * dt):
			vel.x = 0.0
		if not _has_ground(position + Vector3(0, 0, vel.z) * dt):
			vel.z = 0.0

	var r := world.move_box(position, vel, HALF_W, HEIGHT, dt)
	position = r["pos"]
	vel = r["vel"]
	on_ground = r["grounded"]

	# Auto-jump over single-block steps: essential for touch controls.
	if r["walled"] and on_ground and mv.length() > 0.3 and not sneaking and wish.length() > 0.01:
		var f := wish.normalized() * (HALF_W + 0.35)
		var bx := floori(position.x + f.x)
		var bz := floori(position.z + f.z)
		var by := floori(position.y + 0.05)
		if world.is_solid(bx, by, bz) and not world.is_solid(bx, by + 1, bz) \
				and not world.is_solid(bx, by + 2, bz) \
				and not world.is_solid(floori(position.x), by + 2, floori(position.z)):
			vel.y = JUMP_V - 0.3
			on_ground = false

	# Fall damage.
	if on_ground or in_water:
		var fall := fall_peak - position.y
		if fall > 3.5 and not in_water:
			damage(floorf(fall - 3.0), position + Vector3(0, 1, 0), false)
		fall_peak = position.y
	else:
		fall_peak = maxf(fall_peak, position.y)

	if position.y < -20.0:
		damage(100.0, position, false)


func _has_ground(p: Vector3) -> bool:
	return world.is_solid(floori(p.x), floori(p.y - 0.5), floori(p.z))


# ------------------------------------------------------------------ interaction

func _update_target() -> void:
	var o := cam.global_position
	var dir := -cam.global_transform.basis.z
	target = world.raycast(o, dir, REACH)
	if target.get("hit", false) and not main.paused:
		var bp: Vector3i = target["pos"]
		_outline.visible = true
		_outline.global_position = Vector3(bp) + Vector3(0.5, 0.5, 0.5)
	else:
		_outline.visible = false


func _handle_actions(delta: float) -> void:
	attack_cd -= delta
	place_cd -= delta
	mine_pause -= delta
	var held := inv.held_id()

	if hud.break_held:
		var mob := _target_mob()
		if mob != null:
			_mining_reset()
			if attack_cd <= 0.0:
				attack_cd = 0.45
				var dir := (mob.position - position)
				dir.y = 0.0
				mob.hurt(Items.attack_damage(held), dir.normalized())
		elif target.get("hit", false) and mine_pause <= 0.0:
			_mine(delta, held)
		else:
			_mining_reset()
	else:
		_mining_reset()

	var tap := hud.consume_place_tap()
	if tap or (hud.place_held and place_cd <= 0.0):
		_place_or_use(held)
		place_cd = 0.28


func _mining_reset() -> void:
	mining = false
	mining_t = 0.0
	_outline_mat.set_shader_parameter("progress", 0.0)


func _mine(delta: float, held: int) -> void:
	var bp: Vector3i = target["pos"]
	var id: int = target["id"]
	if not mining or bp != mining_pos:
		mining = true
		mining_pos = bp
		mining_t = 0.0
	var bt := Blocks.break_time(id, held)
	if bt < 0.0:
		return
	mining_t += delta
	hunger -= delta * 0.01
	_outline_mat.set_shader_parameter("progress", clampf(mining_t / bt, 0.0, 1.0))
	if mining_t >= bt:
		_break_block(bp, id, held)
		_mining_reset()
		mine_pause = 0.15


func _break_block(bp: Vector3i, id: int, held: int) -> void:
	world.set_block(bp.x, bp.y, bp.z, Blocks.AIR)
	main.burst(Vector3(bp) + Vector3(0.5, 0.5, 0.5), Blocks.particle_color(id), 14, 3.5)
	if id == Blocks.LEAVES:
		var roll := randf()
		if roll < 0.06:
			_give(Items.APPLE)
		elif roll < 0.18:
			_give(Items.STICK)
		return
	if Blocks.can_harvest(id, held):
		_give(Blocks.drop_for(id))


func _give(item: int) -> void:
	if item == 0:
		return
	var left := inv.add(item, 1)
	if left > 0:
		hud.show_toast("Inventory full!")


func _place_or_use(held: int) -> void:
	if held == 0:
		return
	if Items.is_food(held):
		if hunger < 20.0:
			hunger = minf(20.0, hunger + Items.food_value(held))
			inv.consume_held()
		return
	if not Items.is_block(held) or not target.get("hit", false):
		return
	var np: Vector3i = Vector3i(target["pos"]) + Vector3i(target["normal"])
	if np.y < 0 or np.y >= World.CH:
		return
	var cur := world.get_block(np.x, np.y, np.z)
	if cur != Blocks.AIR and cur != Blocks.WATER:
		return
	if _intersects_player(np):
		return
	if world.set_block(np.x, np.y, np.z, held):
		inv.consume_held()


func _intersects_player(b: Vector3i) -> bool:
	var mn := Vector3(position.x - HALF_W, position.y, position.z - HALF_W)
	var mx := Vector3(position.x + HALF_W, position.y + HEIGHT, position.z + HALF_W)
	return mx.x > b.x and mn.x < b.x + 1 and mx.y > b.y and mn.y < b.y + 1 and mx.z > b.z and mn.z < b.z + 1


func _target_mob() -> Node3D:
	var best: Node3D = null
	var best_d := 3.6
	var look := -cam.global_transform.basis.z
	for m in main.mobs:
		if not is_instance_valid(m):
			continue
		var to: Vector3 = (m.position + Vector3(0, 0.9, 0)) - cam.global_position
		var d := to.length()
		if d < best_d and to.normalized().dot(look) > 0.92:
			best = m
			best_d = d
	return best


func near_table() -> bool:
	var px := floori(position.x)
	var py := floori(position.y)
	var pz := floori(position.z)
	for dy in range(-2, 4):
		for dz in range(-4, 5):
			for dx in range(-4, 5):
				if world.get_block(px + dx, py + dy, pz + dz) == Blocks.TABLE:
					return true
	return false


# ------------------------------------------------------------------ vitals

func _update_vitals(delta: float) -> void:
	var drain := 0.02
	if sprinting:
		drain += 0.03
	hunger = maxf(0.0, hunger - drain * delta)
	if hunger >= 16.0 and health < 20.0:
		regen_t += delta
		if regen_t >= 2.5:
			regen_t = 0.0
			health = minf(20.0, health + 1.0)
			hunger = maxf(0.0, hunger - 0.3)
	elif hunger <= 0.0:
		starve_t += delta
		if starve_t >= 4.0:
			starve_t = 0.0
			damage(1.0, position, false)


func damage(amount: float, from: Vector3, knockback: bool = true) -> void:
	if not alive or amount <= 0.0:
		return
	health -= amount
	hurt_timer = 0.4
	if knockback:
		var d := position - from
		d.y = 0.0
		if d.length() > 0.01:
			vel += d.normalized() * 5.0
		vel.y = 4.5
	if health <= 0.0:
		health = 0.0
		alive = false
		died.emit()


func respawn() -> void:
	position = spawn_point
	vel = Vector3.ZERO
	health = 20.0
	hunger = 20.0
	alive = true
	fall_peak = position.y
