class_name SaveSystem
extends RefCounted
## Local world storage. Terrain is regenerated from the seed, so only the
## player state, inventory and block edits are written to user://world.dat

const PATH := "user://world.dat"


static func exists() -> bool:
	return FileAccess.file_exists(PATH)


static func save_game(data: Dictionary) -> bool:
	var f := FileAccess.open(PATH + ".tmp", FileAccess.WRITE)
	if f == null:
		push_warning("Could not open save file: %s" % error_string(FileAccess.get_open_error()))
		return false
	f.store_var(data)
	f.close()
	# Write to a temp file first so a crash mid-save never corrupts the old save.
	var dir := DirAccess.open("user://")
	if dir == null:
		return false
	# Try to replace in one step first; only delete the old file if the platform refuses.
	if dir.rename("world.dat.tmp", "world.dat") == OK:
		return true
	if dir.file_exists("world.dat"):
		dir.remove("world.dat")
	return dir.rename("world.dat.tmp", "world.dat") == OK


static func load_game() -> Dictionary:
	if not exists():
		return {}
	var f := FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return {}
	if f.get_length() < 4:
		f.close()
		return {}
	var v: Variant = f.get_var()
	f.close()
	if v is Dictionary:
		return v
	return {}


static func delete_save() -> void:
	var dir := DirAccess.open("user://")
	if dir != null and dir.file_exists("world.dat"):
		dir.remove("world.dat")
