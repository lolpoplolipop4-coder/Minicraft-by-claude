class_name Settings
extends RefCounted
## User-adjustable settings, stored in user://settings.cfg

const PATH := "user://settings.cfg"

static var view_radius: int = 4
static var shadows: bool = true
static var look_speed: float = 0.16


static func load_settings() -> void:
	if OS.has_feature("pc"):
		view_radius = 6
	var cf := ConfigFile.new()
	if cf.load(PATH) != OK:
		return
	view_radius = clampi(int(cf.get_value("game", "view_radius", view_radius)), 2, 8)
	shadows = bool(cf.get_value("game", "shadows", shadows))
	look_speed = clampf(float(cf.get_value("game", "look_speed", look_speed)), 0.05, 0.5)


static func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("game", "view_radius", view_radius)
	cf.set_value("game", "shadows", shadows)
	cf.set_value("game", "look_speed", look_speed)
	cf.save(PATH)
