class_name Settings
extends RefCounted
## User-adjustable settings, stored in user://settings.cfg

const PATH := "user://settings.cfg"

static var view_radius: int = 4
static var shadows: bool = true
static var look_speed: float = 0.16
static var use_threads: bool = true
## Number of consecutive runs that died while loading a world (see GenLog guard file).
## It automatically switches on safer modes: 1 = no worker threads, 2 = + view distance <= 3,
## 3 = + shadows off. Reset by "Reset safe mode" in Diagnostics or after 30 s of stable play.
static var crash_count: int = 0


static func load_settings() -> void:
	if OS.has_feature("pc"):
		view_radius = 6
	var cf := ConfigFile.new()
	if cf.load(PATH) != OK:
		return
	view_radius = clampi(int(cf.get_value("game", "view_radius", view_radius)), 2, 8)
	shadows = bool(cf.get_value("game", "shadows", shadows))
	look_speed = clampf(float(cf.get_value("game", "look_speed", look_speed)), 0.05, 0.5)
	use_threads = bool(cf.get_value("game", "use_threads", use_threads))
	crash_count = clampi(int(cf.get_value("game", "crash_count", 0)), 0, 9)


static func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("game", "view_radius", view_radius)
	cf.set_value("game", "shadows", shadows)
	cf.set_value("game", "look_speed", look_speed)
	cf.set_value("game", "use_threads", use_threads)
	cf.set_value("game", "crash_count", crash_count)
	cf.save(PATH)


static func effective_threads() -> bool:
	return use_threads and crash_count < 1


static func effective_radius() -> int:
	return mini(view_radius, 3) if crash_count >= 2 else view_radius


static func effective_shadows() -> bool:
	return shadows and crash_count < 3
