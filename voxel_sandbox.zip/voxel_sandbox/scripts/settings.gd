class_name Settings
extends RefCounted
## User-adjustable settings, stored in user://settings.cfg

const PATH := "user://settings.cfg"

static var view_radius: int = 2
static var shadows: bool = false
static var graphics_quality: int = 0 # Start low on mobile; user can raise it in Settings.
static var show_fps: bool = false
static var look_speed: float = 0.16
static var use_threads: bool = false
static var water_physics: bool = true
## Number of consecutive runs that died while loading a world (see GenLog guard file).
## It automatically switches on safer modes: 1 = no worker threads, 2 = + view distance <= 3,
## 3 = + shadows off. Reset by "Reset safe mode" in Diagnostics or after 30 s of stable play.
static var crash_count: int = 0


static func load_settings() -> void:
	if OS.has_feature("pc"):
		view_radius = 6
	else:
		# Conservative startup defaults prevent a blank screen/OOM on Android.
		view_radius = 2
		shadows = false
		graphics_quality = 0
		use_threads = false
	var cf := ConfigFile.new()
	if cf.load(PATH) != OK:
		return
	view_radius = clampi(int(cf.get_value("game", "view_radius", view_radius)), 2, 8)
	shadows = bool(cf.get_value("game", "shadows", shadows))
	graphics_quality = clampi(int(cf.get_value("game", "graphics_quality", graphics_quality)), 0, 2)
	show_fps = bool(cf.get_value("game", "show_fps", show_fps))
	look_speed = clampf(float(cf.get_value("game", "look_speed", look_speed)), 0.05, 0.5)
	use_threads = bool(cf.get_value("game", "use_threads", use_threads))
	water_physics = bool(cf.get_value("game", "water_physics", water_physics))
	crash_count = clampi(int(cf.get_value("game", "crash_count", 0)), 0, 9)


static func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("game", "view_radius", view_radius)
	cf.set_value("game", "shadows", shadows)
	cf.set_value("game", "graphics_quality", graphics_quality)
	cf.set_value("game", "show_fps", show_fps)
	cf.set_value("game", "look_speed", look_speed)
	cf.set_value("game", "use_threads", use_threads)
	cf.set_value("game", "water_physics", water_physics)
	cf.set_value("game", "crash_count", crash_count)
	cf.save(PATH)


static func effective_threads() -> bool:
	return OS.has_feature("pc") and use_threads and crash_count < 1


static func effective_radius() -> int:
	var quality_radius := [2, 4, 6][graphics_quality]
	var chosen := mini(view_radius, quality_radius)
	if OS.has_feature("pc"):
		return mini(chosen, 3) if crash_count >= 2 else chosen
	# Keep startup lightweight on phones; players can still increase view distance
	# from settings after the game has launched.
	return mini(chosen, 2) if crash_count < 2 else 2


static func effective_shadows() -> bool:
	return shadows and graphics_quality >= 1 and crash_count < 3
