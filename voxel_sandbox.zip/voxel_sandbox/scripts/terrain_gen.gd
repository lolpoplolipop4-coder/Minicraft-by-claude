class_name TerrainGen
extends RefCounted
## Deterministic terrain: everything is a pure function of (seed, x, y, z), so
## chunks can be generated on worker threads and re-generated after unloading.
## Only player edits need to be saved.

const CS := 16
const CH := 64
const SEA := 20
const CAVE_THR := 0.5
const CAVE_SURFACE_THR := 0.64

var seed_value: int
var n_cont: FastNoiseLite
var n_hill: FastNoiseLite
var n_mount: FastNoiseLite
var n_temp: FastNoiseLite
var n_forest: FastNoiseLite
var n_cave: FastNoiseLite


func _init(sd: int) -> void:
	seed_value = sd
	n_cont = _mk(sd, 0.0045, 3)
	n_hill = _mk(sd + 1, 0.020, 3)
	n_mount = _mk(sd + 2, 0.0075, 3)
	n_temp = _mk(sd + 3, 0.004, 1)
	n_forest = _mk(sd + 4, 0.012, 1)
	n_cave = _mk(sd + 5, 0.050, 2)


func _mk(s: int, freq: float, octaves: int) -> FastNoiseLite:
	var n := FastNoiseLite.new()
	n.seed = s
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.frequency = freq
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = octaves
	return n


static func generate(cx: int, cz: int, sd: int, ed: Dictionary) -> PackedByteArray:
	var g := TerrainGen.new(sd)
	return g.build_chunk(cx, cz, ed)


func _hash3(x: int, y: int, z: int) -> int:
	var h: int = x * 374761393 + y * 668265263 + z * 1274126177 + seed_value * 2147483629
	h = (h ^ (h >> 13)) * 1103515245
	h = h ^ (h >> 16)
	return h & 0x7fffffff


func _hash2(x: int, z: int) -> int:
	return _hash3(x, 9157, z)


func height_at(wx: int, wz: int) -> int:
	var c := n_cont.get_noise_2d(wx, wz)
	var h := n_hill.get_noise_2d(wx, wz)
	var m := n_mount.get_noise_2d(wx, wz)
	var base := 24.0 + c * 14.0 + h * 5.0
	var mt := maxf(0.0, m - 0.12)
	base += mt * mt * 120.0
	return clampi(int(base), 3, CH - 6)


func surface_block(h: int, temp: float) -> int:
	if h <= SEA + 1:
		return Blocks.SAND
	if temp > 0.38 and h < 38:
		return Blocks.SAND
	if h > 46:
		return Blocks.STONE
	return Blocks.GRASS


func build_chunk(cx: int, cz: int, ed: Dictionary) -> PackedByteArray:
	var blocks := PackedByteArray()
	blocks.resize(CS * CH * CS)
	var ox := cx * CS
	var oz := cz * CS

	for z in CS:
		for x in CS:
			var wx := ox + x
			var wz := oz + z
			var h := height_at(wx, wz)
			var temp := n_temp.get_noise_2d(wx, wz)
			var top := surface_block(h, temp)
			var sub := Blocks.DIRT
			if top == Blocks.SAND:
				sub = Blocks.SAND
			elif top == Blocks.STONE:
				sub = Blocks.STONE
			for y in range(0, h + 1):
				var depth := h - y
				# Caves (never carve near bedrock; only open to the surface on dry land).
				if y > 4 and (depth >= 2 or h > SEA + 3):
					var thr := CAVE_THR if depth >= 4 else CAVE_SURFACE_THR
					if n_cave.get_noise_3d(wx, y * 1.5, wz) > thr:
						continue
				var b := Blocks.STONE
				if y == 0:
					b = Blocks.BEDROCK
				elif y == h:
					b = top
				elif y >= h - 3:
					b = sub
				else:
					var r := _hash3(wx, y, wz) % 1000
					if r < 2 and y < 12:
						b = Blocks.DIAMOND_ORE
					elif r < 7 and y < 22:
						b = Blocks.GOLD_ORE
					elif r < 21 and y < 40:
						b = Blocks.IRON_ORE
					elif r < 51 and y < 52:
						b = Blocks.COAL_ORE
				blocks[(y * CS + z) * CS + x] = b
			for y in range(h + 1, SEA + 1):
				blocks[(y * CS + z) * CS + x] = Blocks.WATER

	# Trees: evaluate every candidate root within 2 blocks of the chunk so
	# canopies cross chunk borders consistently.
	for tz in range(oz - 2, oz + CS + 2):
		for tx in range(ox - 2, ox + CS + 2):
			var r := _hash2(tx, tz)
			var f := r % 1000
			if f >= 45:
				continue
			var thr := 6
			if n_forest.get_noise_2d(tx, tz) > 0.1:
				thr = 35
			if f >= thr:
				continue
			var h := height_at(tx, tz)
			if h > 44:
				continue
			if surface_block(h, n_temp.get_noise_2d(tx, tz)) != Blocks.GRASS:
				continue
			if n_cave.get_noise_3d(tx, h * 1.5, tz) > CAVE_SURFACE_THR:
				continue
			_place_tree(blocks, ox, oz, tx, tz, h, 4 + (r / 1000) % 3)

	for k in ed:
		blocks[int(k)] = int(ed[k])
	return blocks


func _place_tree(blocks: PackedByteArray, ox: int, oz: int, tx: int, tz: int, h: int, th: int) -> void:
	if tx >= ox and tx < ox + CS and tz >= oz and tz < oz + CS:
		for y in range(h + 1, h + th + 1):
			if y < CH:
				blocks[(y * CS + (tz - oz)) * CS + (tx - ox)] = Blocks.WOOD
	var top := h + th
	for ly in range(top - 2, top + 2):
		if ly >= CH:
			continue
		var rad := 2 if ly <= top - 1 else 1
		for dz in range(-rad, rad + 1):
			for dx in range(-rad, rad + 1):
				if rad == 2 and absi(dx) == 2 and absi(dz) == 2 and ((tx + dx * 7 + tz + dz * 13 + ly) & 1) == 0:
					continue
				var lx := tx + dx - ox
				var lz := tz + dz - oz
				if lx < 0 or lx >= CS or lz < 0 or lz >= CS:
					continue
				var i := (ly * CS + lz) * CS + lx
				if blocks[i] == Blocks.AIR:
					blocks[i] = Blocks.LEAVES
