class_name VillageGen
extends RefCounted
## Deterministic village placement.  A village is a small cluster of box-houses, a
## central well, dirt paths and a fence perimeter.  Everything is a pure function of
## (seed, village_id), so the same seed always produces the same village at the same
## location.  The generator writes directly into a chunk's block array when the chunk
## overlaps the village footprint.
##
## Design constraints:
##   – No shared mutable state: safe to call from worker threads.
##   – Maximum footprint 40×40 blocks so villages never overlap at the default spacing.
##   – Structures are built top-down so later blocks (roofs) overwrite earlier ones
##     (walls), which naturally handles overlapping house boxes.
##   – Only normal-type worlds get villages (TYPE_NORMAL = 0).

const CS := 16
const CH := 64
const SPACING := 80          # one village per SPACING×SPACING world-block region
const MIN_HOUSES := 3
const MAX_HOUSES := 6
const HOUSE_GAP := 6         # blocks between house footprints
const PATH_BLOCK := Blocks.DIRT
const WELL_BLOCK := Blocks.COBBLE
const FENCE_BLOCK := Blocks.WOOD


## Returns a list of village dictionaries that MIGHT overlap chunk (cx, cz).
## Each dict: {cx_centre, cz_centre, seed, id}.
static func villages_near(cx: int, cz: int, world_seed: int) -> Array:
	var out: Array = []
	# Check all village-grid cells that a 40-block radius could touch.
	var r := 3   # in grid cells
	var gcx := cx * CS / SPACING
	var gcz := cz * CS / SPACING
	for dz in range(-r, r + 1):
		for dx in range(-r, r + 1):
			var gx := gcx + dx
			var gz := gcz + dz
			var h := _hash2(gx, gz, world_seed)
			if h % 5 != 0:   # ~20% of cells get a village
				continue
			var wx := gx * SPACING + (h >> 8) % (SPACING - 40) + 20
			var wz := gz * SPACING + ((h >> 16) % (SPACING - 40)) + 20
			out.append({"wx": wx, "wz": wz, "vseed": h ^ world_seed, "gx": gx, "gz": gz})
	return out


## Apply all villages that overlap this chunk into blocks[].
## tg is a TerrainGen for height queries.
static func apply(blocks: PackedByteArray, cx: int, cz: int, world_seed: int, tg: TerrainGen) -> void:
	for v in villages_near(cx, cz, world_seed):
		_apply_village(blocks, cx, cz, v["wx"], v["wz"], v["vseed"], tg)


static func _apply_village(blocks: PackedByteArray, cx: int, cz: int,
		vx: int, vz: int, vseed: int, tg: TerrainGen) -> void:
	# The village footprint is at most vx/vz +-20. Skip villages that cannot touch this chunk:
	# the result is identical (writes outside the chunk are discarded anyway) but chunk
	# generation no longer pays for ~7 invisible villages per chunk on a phone.
	var chunk_x0 := cx * CS
	var chunk_z0 := cz * CS
	if vx + 20 < chunk_x0 or vx - 20 >= chunk_x0 + CS or vz + 20 < chunk_z0 or vz - 20 >= chunk_z0 + CS:
		return
	var rng := _rng(vseed)
	var ground := tg.height_at(vx, vz)
	# Skip villages in the sea, in sand deserts, or on very steep slopes.
	if ground <= TerrainGen.SEA + 2 or ground > 42:
		return
	var surf := tg.surface_block(ground, tg.n_temp.get_noise_2d(vx, vz))
	if surf != Blocks.GRASS:
		return
	# Check slope: all four corners within 3 blocks of the centre height.
	for dx in [-16, 16]:
		for dz2 in [-16, 16]:
			if absi(tg.height_at(vx + dx, vz + dz2) - ground) > 4:
				return
	var gy := ground + 1
	var num_houses := rng.randi_range(MIN_HOUSES, MAX_HOUSES)
	var houses: Array = _layout_houses(vx, vz, num_houses, rng)
	# Fence perimeter.
	_rect_outline(blocks, cx, cz, vx - 18, vz - 18, 36, 36, gy, FENCE_BLOCK)
	# Dirt paths.
	_fill_rect(blocks, cx, cz, vx - 18, vz - 18, 36, 2, gy - 1, PATH_BLOCK)  # N border path
	_fill_rect(blocks, cx, cz, vx - 18, vz + 16, 36, 2, gy - 1, PATH_BLOCK)  # S border path
	_fill_rect(blocks, cx, cz, vx - 18, vz - 18, 2, 36, gy - 1, PATH_BLOCK)  # W border path
	_fill_rect(blocks, cx, cz, vx + 16, vz - 18, 2, 36, gy - 1, PATH_BLOCK)  # E border path
	_fill_rect(blocks, cx, cz, vx - 1, vz - 18, 2, 36, gy - 1, PATH_BLOCK)   # N–S central path
	_fill_rect(blocks, cx, cz, vx - 18, vz - 1, 36, 2, gy - 1, PATH_BLOCK)   # E–W central path
	# Well at the centre.
	_place_well(blocks, cx, cz, vx, vz, gy)
	# Houses.
	for h in houses:
		_place_house(blocks, cx, cz, h["x"], h["z"], gy, h["w"], h["d"], rng)


static func _layout_houses(vx: int, vz: int, n: int, rng: RandomNumberGenerator) -> Array:
	var slots: Array = [
		[-12, -12], [4, -12], [-12, 4], [4, 4], [-12, -4], [4, -4],
	]
	var out: Array = []
	for i in mini(n, slots.size()):
		var s: Array = slots[i]
		var w := rng.randi_range(5, 8)
		var d := rng.randi_range(5, 7)
		out.append({"x": vx + int(s[0]), "z": vz + int(s[1]), "w": w, "d": d})
	return out


static func _place_house(blocks: PackedByteArray, cx: int, cz: int,
		hx: int, hz: int, gy: int, w: int, d: int, rng: RandomNumberGenerator) -> void:
	var wall := Blocks.PLANKS
	var roof := Blocks.WOOD
	var floor_b := Blocks.PLANKS
	# Floor
	_fill_rect(blocks, cx, cz, hx, hz, w, d, gy, floor_b)
	# Walls (4 sides, height 3)
	for h in 3:
		_fill_rect(blocks, cx, cz, hx, hz, w, 1, gy + 1 + h, wall)
		_fill_rect(blocks, cx, cz, hx, hz + d - 1, w, 1, gy + 1 + h, wall)
		_fill_rect(blocks, cx, cz, hx, hz, 1, d, gy + 1 + h, wall)
		_fill_rect(blocks, cx, cz, hx + w - 1, hz, 1, d, gy + 1 + h, wall)
	# Door gap (front wall, middle column, bottom 2 blocks)
	var door_x := hx + w / 2
	_set(blocks, cx, cz, door_x, gy + 1, hz, Blocks.DOOR)
	_set(blocks, cx, cz, door_x, gy + 2, hz, Blocks.DOOR)
	# Roof (flat slab on top)
	_fill_rect(blocks, cx, cz, hx - 1, hz - 1, w + 2, d + 2, gy + 4, roof)
	# Window holes (sides)
	var wx1 := hx + w / 4
	var wx2 := hx + (w * 3) / 4
	_set(blocks, cx, cz, wx1, gy + 2, hz, Blocks.GLASS)
	_set(blocks, cx, cz, wx2, gy + 2, hz, Blocks.GLASS)
	_set(blocks, cx, cz, wx1, gy + 2, hz + d - 1, Blocks.GLASS)
	_set(blocks, cx, cz, wx2, gy + 2, hz + d - 1, Blocks.GLASS)


static func _place_well(blocks: PackedByteArray, cx: int, cz: int,
		vx: int, vz: int, gy: int) -> void:
	# 3×3 stone ring, 2 high, water inside, wood cross on top
	for dz2 in range(-1, 2):
		for dx in range(-1, 2):
			var is_edge := dx == -1 or dx == 1 or dz2 == -1 or dz2 == 1
			if is_edge:
				_set(blocks, cx, cz, vx + dx, gy, vz + dz2, WELL_BLOCK)
				_set(blocks, cx, cz, vx + dx, gy + 1, vz + dz2, WELL_BLOCK)
			else:
				_set(blocks, cx, cz, vx, gy, vz, WELL_BLOCK)
				_set(blocks, cx, cz, vx, gy + 1, vz, Blocks.WATER)
	# Two crossed logs above
	for dx in range(-1, 2):
		_set(blocks, cx, cz, vx + dx, gy + 2, vz, Blocks.WOOD)
	for dz2 in range(-1, 2):
		_set(blocks, cx, cz, vx, gy + 2, vz + dz2, Blocks.WOOD)


# ------------------------------------------------------------------ primitives

static func _set(blocks: PackedByteArray, cx: int, cz: int,
		wx: int, wy: int, wz: int, bid: int) -> void:
	var lx := wx - cx * CS
	var lz := wz - cz * CS
	if lx < 0 or lx >= CS or lz < 0 or lz >= CS or wy < 0 or wy >= CH:
		return
	blocks[(wy * CS + lz) * CS + lx] = bid


static func _fill_rect(blocks: PackedByteArray, cx: int, cz: int,
		wx0: int, wz0: int, w: int, d: int, wy: int, bid: int) -> void:
	for dz2 in d:
		for dx in w:
			_set(blocks, cx, cz, wx0 + dx, wy, wz0 + dz2, bid)


static func _rect_outline(blocks: PackedByteArray, cx: int, cz: int,
		wx0: int, wz0: int, w: int, d: int, wy: int, bid: int) -> void:
	for dx in w:
		_set(blocks, cx, cz, wx0 + dx, wy, wz0, bid)
		_set(blocks, cx, cz, wx0 + dx, wy, wz0 + d - 1, bid)
	for dz2 in d:
		_set(blocks, cx, cz, wx0, wy, wz0 + dz2, bid)
		_set(blocks, cx, cz, wx0 + w - 1, wy, wz0 + dz2, bid)


# ------------------------------------------------------------------ helpers

static func _hash2(x: int, z: int, sd: int) -> int:
	var h: int = x * 374761393 + z * 1274126177 + sd * 668265263
	h = (h ^ (h >> 13)) * 1103515245
	h = h ^ (h >> 16)
	return h & 0x7fffffff


static func _rng(seed_v: int) -> RandomNumberGenerator:
	var r := RandomNumberGenerator.new()
	r.seed = seed_v
	return r
