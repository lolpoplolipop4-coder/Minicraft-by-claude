class_name Villager
extends Node3D
## Lightweight voxel-collision villager. Kept deliberately cheap for Android:
## primitive meshes, no rigid bodies, bounded local wandering and throttled decisions.

const HW := 0.30
const BODY_H := 1.72
const ROLE_VILLAGER := 0
const ROLE_FARMER := 1
const ROLE_TRADER := 2
const ROLE_WORKER := 3
const ROLE_GUARD := 4
const ROLE_NAMES := ["Житель", "Фермер", "Торговец", "Рабочий", "Охранник"]

var role := ROLE_VILLAGER
var world: World
var main: Node
var village_center := Vector3.ZERO
var home := Vector3.ZERO
var hp := 20.0
var food := 18.0
var inventory: Dictionary = {Items.APPLE: 2}
var velocity := Vector3.ZERO
var grounded := false
var _goal := Vector3.ZERO
var _think := 0.0
var _anim := 0.0
var _phase := 0.0
var _legs: Array[Node3D] = []
var _body_mat: StandardMaterial3D
var _head: Node3D

func setup(w: World, m: Node, centre: Vector3, assigned_role: int) -> void:
	world = w
	main = m
	village_center = centre
	home = centre + Vector3(randf_range(-10.0, 10.0), 0, randf_range(-10.0, 10.0))
	role = clampi(assigned_role, 0, ROLE_NAMES.size() - 1)
	_phase = randf() * 24.0
	_build()
	_choose_goal()

func _material(color: Color) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 1.0
	return mat

func _part(parent: Node3D, size: Vector3, at: Vector3, mat: Material) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.material_override = mat
	node.position = at
	node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(node)
	return node

func _build() -> void:
	var robe := [Color("#8a6547"), Color("#547b42"), Color("#765c91"), Color("#777777"), Color("#52677d")][role]
	_body_mat = _material(robe)
	var skin := _material(Color("#c99b75"))
	var dark := _material(Color("#40352d"))
	_part(self, Vector3(0.58, 0.82, 0.34), Vector3(0, 0.92, 0), _body_mat)
	_head = Node3D.new()
	_head.position = Vector3(0, 1.55, 0)
	add_child(_head)
	_part(_head, Vector3(0.42, 0.42, 0.42), Vector3.ZERO, skin)
	_part(_head, Vector3(0.44, 0.12, 0.44), Vector3(0, 0.19, 0), dark)
	for side in [-1.0, 1.0]:
		_part(_head, Vector3(0.055, 0.055, 0.025), Vector3(0.10 * side, 0.02, -0.215), dark)
		var leg := Node3D.new()
		leg.position = Vector3(side * 0.16, 0.48, 0)
		add_child(leg)
		_part(leg, Vector3(0.17, 0.52, 0.20), Vector3(0, -0.20, 0), dark)
		_legs.append(leg)
	_part(self, Vector3(0.16, 0.72, 0.18), Vector3(-0.38, 0.98, 0), skin)
	_part(self, Vector3(0.16, 0.72, 0.18), Vector3(0.38, 0.98, 0), skin)

func _process(delta: float) -> void:
	if world == null or main == null or main.paused:
		return
	var dt := minf(delta, 1.0 / 25.0)
	_phase += dt
	food = maxf(0.0, food - dt * 0.012)
	if food < 4.0 and _phase > 0.0:
		_eat()
	_think -= dt
	if _think <= 0.0:
		_think = 1.0 if position.distance_to((main as Node3D).position) > 28.0 else randf_range(2.0, 4.0)
		_choose_goal()
	var dir := _goal - position
	dir.y = 0
	var night := float(main.get("daylight")) < 0.12 if main != null else false
	if dir.length() < 0.7 or (night and dir.length() < 1.8):
		velocity.x = move_toward(velocity.x, 0.0, 8.0 * dt)
		velocity.z = move_toward(velocity.z, 0.0, 8.0 * dt)
	else:
		dir = dir.normalized()
		var speed := 1.15 if role == ROLE_GUARD else 0.85
		velocity.x = move_toward(velocity.x, dir.x * speed, 5.0 * dt)
		velocity.z = move_toward(velocity.z, dir.z * speed, 5.0 * dt)
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, dt * 5.0))
	velocity.y = maxf(velocity.y - 24.0 * dt, -22.0)
	var result := world.move_box(position, velocity, HW, BODY_H, dt)
	position = result["pos"]
	velocity = result["vel"]
	grounded = result["grounded"]
	if result["walled"] and grounded and dir.length() > 0.1:
		velocity.y = 5.0
	_anim += Vector2(velocity.x, velocity.z).length() * dt * 5.0
	for i in _legs.size():
		_legs[i].rotation.x = sin(_anim) * 0.55 * (1.0 if i == 0 else -1.0)
	if position.y < -20.0:
		var safe_y := world.top_y(floori(village_center.x), floori(village_center.z))
		position = Vector3(village_center.x, safe_y + 1.0, village_center.z)
		velocity = Vector3.ZERO

func _choose_goal() -> void:
	if world == null:
		return
	# Night schedule: return to the assigned home point and remain still until dawn.
	var daylight_now := float(main.get("daylight")) if main != null else 1.0
	if daylight_now < 0.12:
		_goal = home
		return
	# Villagers remain in their village footprint. Guards patrol its edge; farmers
	# bias their route toward the central working area.
	var radius := 13.0 if role == ROLE_GUARD else (5.0 if role == ROLE_FARMER else 10.0)
	for _attempt in 8:
		var candidate := village_center + Vector3(randf_range(-radius, radius), 0, randf_range(-radius, radius))
		var x := floori(candidate.x)
		var z := floori(candidate.z)
		var top := world.top_y(x, z)
		if top < 1 or top > World.CH - 4:
			continue
		if world.get_block(x, top + 1, z) != Blocks.AIR or world.get_block(x, top + 2, z) != Blocks.AIR:
			continue
		_goal = Vector3(x + 0.5, top + 1.0, z + 0.5)
		return
	_goal = home

func _eat() -> void:
	for id in [Items.APPLE, Items.COOKED_MEAT, Items.FLESH]:
		var count := int(inventory.get(id, 0))
		if count > 0:
			inventory[id] = count - 1
			food = minf(20.0, food + float(Items.food_value(id)))
			return
	# Shared food is only taken when the villager is genuinely hungry.
	if main != null:
		var shared_inventory := main.get("inv") as Inventory
		if shared_inventory != null and shared_inventory.has(Items.APPLE, 1):
			shared_inventory.remove(Items.APPLE, 1)
			food = minf(20.0, food + 4.0)

func take_damage(amount: float) -> void:
	hp -= amount
	if hp <= 0.0:
		queue_free()

func get_role_name() -> String:
	return ROLE_NAMES[role]
