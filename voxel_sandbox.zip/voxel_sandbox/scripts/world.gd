class_name World
extends Node3D
## Chunk streaming. Terrain generation and meshing run on WorkerThreadPool; the main
## thread only creates MeshInstance3D nodes (max 2 per frame).
## Collision is done directly against the voxel grid (see move_box) - no physics
## bodies or collision shapes are created, which is the cheapest option possible.

const CS := 16
const CH := 64

const WATER_SHADER := """
shader_type spatial;
render_mode blend_mix, cull_back;
uniform sampler2D atlas : source_color, filter_nearest;
uniform float alpha = 0.6;
void vertex() {
	if (NORMAL.y > 0.5) {
		vec3 w = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
		VERTEX.y += sin(TIME * 1.7 + w.x * 1.1 + w.z * 0.8) * 0.025;
	}
}
void fragment() {
	vec4 t = texture(atlas, UV);
	ALBEDO = t.rgb * COLOR.rgb;
	ALPHA = alpha;
	ROUGHNESS = 0.2;
	METALLIC = 0.0;
	SPECULAR = 0.5;
}
"""

var seed_value := 0
var world_type := 0   # TerrainGen.TYPE_*; set before setup()
var view_radius := 4
var focus := Vector3.ZERO

var chunks: Dictionary = {}   # Vector2i -> Chunk
var edits: Dictionary = {}    # Vector2i -> Dictionary(index:int -> block:int)
var edit_queue: Array[Vector2i] = []
var offsets: Array[Vector2i] = []
var mesh_limit := 17
var data_limit := 26

var opaque_mat: StandardMaterial3D
var water_mat: ShaderMaterial

## false = "safe mode": generation and meshing run on the main thread in small time slices.
var threaded := true
var max_tasks := 1
var stats := {"gen_ok": 0, "gen_fail": 0, "mesh_ok": 0, "mesh_fail": 0, "stale": 0, "unloaded": 0}

var _mutex := Mutex.new()
var _results: Array = []          # written by workers, always under _mutex
var _ready_meshes: Array = []     # main thread only
var _tasks: Array[int] = []       # main thread only
var _solid_fill := PackedByteArray()
var _center := Vector2i(1000000, 1000000)
var _next_serial := 1
var _frame_t0 := 0
var _started := 0
var _last_stat_ms := 0


func setup(sd: int, saved_edits: Dictionary, radius: int) -> void:
	seed_value = sd
	edits = saved_edits
	threaded = Settings.effective_threads()
	# Mobile: ONE worker leaves the other cores to the render thread and the OS.
	max_tasks = 3 if OS.has_feature("pc") else 1
	_solid_fill.resize(CS * CH * CS)
	_solid_fill.fill(Blocks.STONE)
	_make_materials()
	_warm_up()
	set_view_radius(radius)
	GenLog.info("world", "setup seed=%d type=%d radius=%d threaded=%s workers=%d safe_level=%d mem=%.1fMB" % [
		sd, world_type, view_radius, str(threaded), max_tasks, Settings.crash_count, GenLog.mem_mb()])


## Runs the whole generate -> mesh pipeline once on the MAIN thread before any worker
## starts. This initialises every script class / constant table single-threaded, so the
## workers never race on first use, and it logs how fast this device is.
func _warm_up() -> void:
	var t0 := Time.get_ticks_usec()
	var tg := TerrainGen.generate(0, 0, 1, {})
	var t1 := Time.get_ticks_usec()
	var m := Mesher.build(tg, tg, tg, tg, tg)
	var t2 := Time.get_ticks_usec()
	var err := Mesher.validate(m["o"])
	GenLog.info("warmup", "gen=%.1fms mesh=%.1fms valid=%s" % [float(t1 - t0) / 1000.0, float(t2 - t1) / 1000.0, "yes" if err == "" else err])


func _drain_workers() -> void:
	for id in _tasks:
		WorkerThreadPool.wait_for_task_completion(id)
	_tasks.clear()
	_mutex.lock()
	_results.clear()
	_mutex.unlock()


func _exit_tree() -> void:
	_drain_workers()
	GenLog.info("world", "exit stats=%s" % str(stats))


func set_view_radius(r: int) -> void:
	r = clampi(r, 2, 8)
	view_radius = r
	mesh_limit = r * r + 1
	data_limit = r * r + 2 * r + 3
	offsets.clear()
	var lim := r + 2
	for dz in range(-lim, lim + 1):
		for dx in range(-lim, lim + 1):
			if dx * dx + dz * dz <= data_limit:
				offsets.append(Vector2i(dx, dz))
	offsets.sort_custom(func(a: Vector2i, b: Vector2i) -> bool: return a.length_squared() < b.length_squared())
	_center = Vector2i(1000000, 1000000)


func _make_materials() -> void:
	opaque_mat = StandardMaterial3D.new()
	opaque_mat.albedo_texture = Atlas.texture
	opaque_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	opaque_mat.vertex_color_use_as_albedo = true
	opaque_mat.roughness = 1.0
	opaque_mat.metallic_specular = 0.0
	opaque_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	opaque_mat.alpha_scissor_threshold = 0.5
	var sh := Shader.new()
	sh.code = WATER_SHADER
	water_mat = ShaderMaterial.new()
	water_mat.shader = sh
	water_mat.set_shader_parameter("atlas", Atlas.texture)


# ------------------------------------------------------------------ streaming

func _process(_delta: float) -> void:
	_frame_t0 = Time.get_ticks_usec()
	_started = 0
	_collect_results()
	_clean_tasks()
	var c := Vector2i(floori(focus.x) >> 4, floori(focus.z) >> 4)
	if c != _center:
		_center = c
		_unload_far()
	_schedule()
	_apply_pending_meshes()
	_log_stats()


func _unload_far() -> void:
	var lim := data_limit + 8
	var gone: Array[Vector2i] = []
	for key in chunks:
		var k: Vector2i = key
		if (k - _center).length_squared() > lim:
			gone.append(k)
	for k in gone:
		var ch: Chunk = chunks[k]
		ch.free_nodes()
		chunks.erase(k)
	if not gone.is_empty():
		stats["unloaded"] += gone.size()
		GenLog.info("world", "unloaded %d chunks, %d remain, center=(%d,%d)" % [gone.size(), chunks.size(), _center.x, _center.y])


## Threaded: at most max_tasks in flight. Safe mode: ~8 ms of work per frame (always >= 1 job).
func _can_start() -> bool:
	if threaded:
		return _tasks.size() < max_tasks
	return _started == 0 or Time.get_ticks_usec() - _frame_t0 < 8000


func _schedule() -> void:
	_mutex.lock()
	var queued := _results.size() + _ready_meshes.size()
	_mutex.unlock()
	if queued > 10 or not _can_start():
		return
	# Edited chunks first so digging feels responsive. A chunk is only re-meshed when all
	# four neighbours have data, otherwise its border faces would be missing.
	while not edit_queue.is_empty() and _can_start():
		var ek: Vector2i = edit_queue.pop_front()
		var ech: Chunk = chunks.get(ek)
		if ech != null and ech.has_data and ech.dirty and not ech.mesh_pending and _neighbors_have_data(ek):
			_start_mesh(ech)
	for off in offsets:
		if not _can_start():
			break
		var k := _center + off
		var ch: Chunk = chunks.get(k)
		if ch == null:
			ch = Chunk.new(k)
			ch.serial = _next_serial
			_next_serial += 1
			chunks[k] = ch
			_start_gen(ch)
		elif not ch.has_data and not ch.gen_pending:
			_start_gen(ch) # a previous attempt failed validation: retry
		elif ch.has_data and (not ch.meshed or ch.dirty) and not ch.mesh_pending \
				and off.length_squared() <= mesh_limit and _neighbors_have_data(k):
			_start_mesh(ch)


func _neighbors_have_data(k: Vector2i) -> bool:
	for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		var n: Chunk = chunks.get(k + d)
		if n == null or not n.has_data:
			return false
	return true


func _start_gen(ch: Chunk) -> void:
	ch.gen_pending = true
	ch.t_queued = Time.get_ticks_msec()
	var ed: Dictionary = {}
	if edits.has(ch.pos):
		ed = (edits[ch.pos] as Dictionary).duplicate()
	GenLog.info("gen", "queue chunk=(%d,%d) serial=%d edits=%d try=%d" % [ch.pos.x, ch.pos.y, ch.serial, ed.size(), ch.gen_retries + 1])
	_started += 1
	if threaded:
		_tasks.append(WorkerThreadPool.add_task(_gen_job.bind(ch.serial, ch.pos.x, ch.pos.y, seed_value, ed, world_type), false, "voxel_gen"))
	else:
		_gen_job(ch.serial, ch.pos.x, ch.pos.y, seed_value, ed, world_type)


func _start_mesh(ch: Chunk) -> void:
	# mesh_pending stays true until the mesh has been APPLIED (not just computed);
	# otherwise the scheduler would queue duplicate jobs for the same chunk.
	ch.mesh_pending = true
	ch.dirty = false
	ch.t_queued = Time.get_ticks_msec()
	var p := ch.pos
	GenLog.info("mesh", "queue chunk=(%d,%d) serial=%d" % [p.x, p.y, ch.serial])
	_started += 1
	var b := ch.blocks.duplicate()
	var nx := _nb(p + Vector2i(-1, 0))
	var px := _nb(p + Vector2i(1, 0))
	var nz := _nb(p + Vector2i(0, -1))
	var pz := _nb(p + Vector2i(0, 1))
	if threaded:
		_tasks.append(WorkerThreadPool.add_task(_mesh_job.bind(ch.serial, p, b, nx, px, nz, pz), false, "voxel_mesh"))
	else:
		_mesh_job(ch.serial, p, b, nx, px, nz, pz)


func _nb(k: Vector2i) -> PackedByteArray:
	var c: Chunk = chunks.get(k)
	if c != null and c.has_data:
		return c.blocks.duplicate()
	return _solid_fill


func _push(r: Dictionary) -> void:
	_mutex.lock()
	_results.append(r)
	_mutex.unlock()


# These two run on worker threads: they only use ints, copies of arrays and pure
# static functions - never nodes, chunks, the scene tree or shared mutable state
# (except the mutex-guarded result list and the mutex-guarded log).
func _gen_job(serial: int, cx: int, cz: int, sd: int, ed: Dictionary, wt: int) -> void:
	var t0 := Time.get_ticks_usec()
	GenLog.info("gen", "begin chunk=(%d,%d) serial=%d" % [cx, cz, serial])
	var data := TerrainGen.generate(cx, cz, sd, ed, wt)
	var ok := data.size() == CS * CH * CS
	if not ok:
		GenLog.error("gen", "chunk=(%d,%d) produced %d bytes, expected %d" % [cx, cz, data.size(), CS * CH * CS])
	_push({"t": 0, "serial": serial, "pos": Vector2i(cx, cz), "blocks": data, "ok": ok, "us": Time.get_ticks_usec() - t0})


func _mesh_job(serial: int, p: Vector2i, b: PackedByteArray, nx: PackedByteArray, px: PackedByteArray,
		nz: PackedByteArray, pz: PackedByteArray) -> void:
	var t0 := Time.get_ticks_usec()
	GenLog.info("mesh", "begin chunk=(%d,%d) serial=%d" % [p.x, p.y, serial])
	var ok := b.size() == CS * CH * CS and nx.size() == b.size() and px.size() == b.size() \
			and nz.size() == b.size() and pz.size() == b.size()
	var m: Dictionary = {"o": [], "w": []}
	if ok:
		m = Mesher.build(b, nx, px, nz, pz)
		var e1 := Mesher.validate(m["o"])
		var e2 := Mesher.validate(m["w"])
		if e1 != "" or e2 != "":
			ok = false
			GenLog.error("mesh", "chunk=(%d,%d) invalid mesh arrays: %s %s" % [p.x, p.y, e1, e2])
	else:
		GenLog.error("mesh", "chunk=(%d,%d) bad input array sizes" % [p.x, p.y])
	_push({"t": 1, "serial": serial, "pos": p, "mesh": m, "ok": ok, "us": Time.get_ticks_usec() - t0})


func _clean_tasks() -> void:
	var i := 0
	while i < _tasks.size():
		if WorkerThreadPool.is_task_completed(_tasks[i]):
			WorkerThreadPool.wait_for_task_completion(_tasks[i])
			_tasks.remove_at(i)
		else:
			i += 1


func _collect_results() -> void:
	_mutex.lock()
	var batch := _results
	_results = []
	_mutex.unlock()
	for r in batch:
		var rd: Dictionary = r
		var k: Vector2i = rd["pos"]
		var ch: Chunk = chunks.get(k)
		# Results of chunks that were unloaded (or unloaded and re-created) are dropped.
		if ch == null or ch.serial != int(rd["serial"]):
			stats["stale"] += 1
			GenLog.info("result", "dropped stale %s chunk=(%d,%d)" % ["gen" if int(rd["t"]) == 0 else "mesh", k.x, k.y])
			continue
		var ms := float(int(rd["us"])) / 1000.0
		if int(rd["t"]) == 0:
			ch.gen_pending = false
			if bool(rd["ok"]):
				ch.blocks = rd["blocks"]
				ch.has_data = true
				stats["gen_ok"] += 1
				GenLog.info("gen", "done chunk=(%d,%d) %.1fms wait=%dms" % [k.x, k.y, ms, Time.get_ticks_msec() - ch.t_queued])
			else:
				stats["gen_fail"] += 1
				ch.gen_retries += 1
				if ch.gen_retries >= 3:
					GenLog.error("gen", "chunk=(%d,%d) failed %d times - using flat fallback terrain" % [k.x, k.y, ch.gen_retries])
					ch.blocks = _fallback_blocks()
					ch.has_data = true
		else:
			if bool(rd["ok"]):
				stats["mesh_ok"] += 1
				_ready_meshes.append({"ch": ch, "serial": ch.serial, "mesh": rd["mesh"], "ms": ms})
			else:
				# Never retry a mesh that failed validation forever: leave the chunk invisible.
				stats["mesh_fail"] += 1
				ch.mesh_pending = false
				ch.meshed = true
				GenLog.error("mesh", "chunk=(%d,%d) mesh discarded" % [k.x, k.y])


func _fallback_blocks() -> PackedByteArray:
	var b := PackedByteArray()
	b.resize(CS * CH * CS)
	for y in range(0, 21):
		var id := Blocks.BEDROCK if y == 0 else (Blocks.STONE if y < 20 else Blocks.GRASS)
		for i in range(y * CS * CS, (y + 1) * CS * CS):
			b[i] = id
	return b


## Creates at most 3 MeshInstance3D per frame and stops after ~4 ms (always at least 1).
func _apply_pending_meshes() -> void:
	var t0 := Time.get_ticks_usec()
	var n := 0
	while not _ready_meshes.is_empty():
		if n >= 1 and (n >= 3 or Time.get_ticks_usec() - t0 > 4000):
			break
		var it: Dictionary = _ready_meshes.pop_front()
		var ch: Chunk = it["ch"]
		ch.mesh_pending = false
		if chunks.get(ch.pos) != ch or ch.serial != int(it["serial"]):
			continue
		var m: Dictionary = it["mesh"]
		_set_inst(ch, false, m["o"])
		_set_inst(ch, true, m["w"])
		ch.meshed = true
		n += 1
		GenLog.info("mesh", "applied chunk=(%d,%d) build=%.1fms upload=%.1fms total_wait=%dms" % [
			ch.pos.x, ch.pos.y, float(it["ms"]), float(Time.get_ticks_usec() - t0) / 1000.0, Time.get_ticks_msec() - ch.t_queued])


func _set_inst(ch: Chunk, is_water: bool, arrays: Array) -> void:
	var inst: MeshInstance3D = ch.winst if is_water else ch.inst
	if arrays.is_empty():
		if inst != null and is_instance_valid(inst):
			inst.queue_free()
		if is_water:
			ch.winst = null
		else:
			ch.inst = null
		return
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(0, water_mat if is_water else opaque_mat)
	if inst == null or not is_instance_valid(inst):
		inst = MeshInstance3D.new()
		inst.position = Vector3(ch.pos.x * CS, 0, ch.pos.y * CS)
		if is_water:
			inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(inst)
		if is_water:
			ch.winst = inst
		else:
			ch.inst = inst
	inst.mesh = mesh


func _log_stats() -> void:
	var now := Time.get_ticks_msec()
	if now - _last_stat_ms < 2000:
		return
	_last_stat_ms = now
	var meshed := 0
	var with_data := 0
	for key in chunks:
		var c: Chunk = chunks[key]
		if c.meshed:
			meshed += 1
		if c.has_data:
			with_data += 1
	GenLog.info("stats", "chunks=%d data=%d meshed=%d tasks=%d ready_meshes=%d %s mem=%.1fMB peak=%.1fMB" % [
		chunks.size(), with_data, meshed, _tasks.size(), _ready_meshes.size(), str(stats), GenLog.mem_mb(), GenLog.peak_mb()])


## 0..1: fraction of chunks around `pos` that are meshed (used by the loading screen).
## Chunks beyond mesh_limit are never meshed (small view distance), so they are not waited for.
func ready_progress(pos: Vector3, r: int) -> float:
	var cx := floori(pos.x) >> 4
	var cz := floori(pos.z) >> 4
	var total := 0
	var done := 0
	for dz in range(-r, r + 1):
		for dx in range(-r, r + 1):
			if dx * dx + dz * dz >= mesh_limit:
				continue
			total += 1
			var ch: Chunk = chunks.get(Vector2i(cx + dx, cz + dz))
			if ch != null and ch.meshed:
				done += 1
	if total == 0:
		return 1.0
	return float(done) / float(total)


# ------------------------------------------------------------------ block access

## Block id, or -1 if that chunk is not loaded.
func get_block(x: int, y: int, z: int) -> int:
	if y < 0:
		return Blocks.BEDROCK
	if y >= CH:
		return 0
	var ch: Chunk = chunks.get(Vector2i(x >> 4, z >> 4))
	if ch == null or not ch.has_data:
		return -1
	return ch.blocks[(y * 16 + (z & 15)) * 16 + (x & 15)]


## Solid for collision. Unloaded chunks count as solid so nobody falls into the void.
func is_solid(x: int, y: int, z: int) -> bool:
	var b := get_block(x, y, z)
	return b == -1 or (b != Blocks.AIR and b != Blocks.WATER)


func set_block(x: int, y: int, z: int, id: int) -> bool:
	if y < 0 or y >= CH:
		return false
	var key := Vector2i(x >> 4, z >> 4)
	var ch: Chunk = chunks.get(key)
	if ch == null or not ch.has_data:
		return false
	var lx := x & 15
	var lz := z & 15
	var idx := (y * 16 + lz) * 16 + lx
	ch.blocks[idx] = id
	var e: Dictionary = edits.get(key, {})
	e[idx] = id
	edits[key] = e
	_mark_dirty(key)
	if lx == 0:
		_mark_dirty(key + Vector2i(-1, 0))
	elif lx == 15:
		_mark_dirty(key + Vector2i(1, 0))
	if lz == 0:
		_mark_dirty(key + Vector2i(0, -1))
	elif lz == 15:
		_mark_dirty(key + Vector2i(0, 1))
	return true


func _mark_dirty(k: Vector2i) -> void:
	var ch: Chunk = chunks.get(k)
	if ch != null and ch.has_data:
		ch.dirty = true
		if not edit_queue.has(k):
			edit_queue.append(k)


## Y of the highest non-air block in a column, -1 if unloaded or the top is water.
func top_y(x: int, z: int) -> int:
	for y in range(CH - 1, -1, -1):
		var b := get_block(x, y, z)
		if b == -1:
			return -1
		if b == Blocks.WATER:
			return -1
		if b != Blocks.AIR:
			return y
	return -1


## Voxel DDA ray. Skips air and water. Returns {hit, pos, normal, id}.
func raycast(origin: Vector3, dir: Vector3, max_dist: float) -> Dictionary:
	var x := floori(origin.x)
	var y := floori(origin.y)
	var z := floori(origin.z)
	var sx := 1 if dir.x > 0.0 else -1
	var sy := 1 if dir.y > 0.0 else -1
	var sz := 1 if dir.z > 0.0 else -1
	var dx := absf(1.0 / dir.x) if dir.x != 0.0 else INF
	var dy := absf(1.0 / dir.y) if dir.y != 0.0 else INF
	var dz := absf(1.0 / dir.z) if dir.z != 0.0 else INF
	var tx := INF
	var ty := INF
	var tz := INF
	if dir.x > 0.0:
		tx = (x + 1 - origin.x) / dir.x
	elif dir.x < 0.0:
		tx = (origin.x - x) / -dir.x
	if dir.y > 0.0:
		ty = (y + 1 - origin.y) / dir.y
	elif dir.y < 0.0:
		ty = (origin.y - y) / -dir.y
	if dir.z > 0.0:
		tz = (z + 1 - origin.z) / dir.z
	elif dir.z < 0.0:
		tz = (origin.z - z) / -dir.z
	var normal := Vector3i.ZERO
	var t := 0.0
	while t <= max_dist:
		var b := get_block(x, y, z)
		if b > 0 and b != Blocks.WATER:
			return {"hit": true, "pos": Vector3i(x, y, z), "normal": normal, "id": b}
		if tx < ty and tx < tz:
			x += sx
			t = tx
			tx += dx
			normal = Vector3i(-sx, 0, 0)
		elif ty < tz:
			y += sy
			t = ty
			ty += dy
			normal = Vector3i(0, -sy, 0)
		else:
			z += sz
			t = tz
			tz += dz
			normal = Vector3i(0, 0, -sz)
	return {"hit": false}


# ------------------------------------------------------------------ collision

## Moves an axis-aligned box (feet position `pos`, half width `hw`, height `h`)
## through the voxel grid. Returns {pos, vel, grounded, walled}.
func move_box(pos: Vector3, vel: Vector3, hw: float, h: float, dt: float) -> Dictionary:
	var p := pos
	var v := vel
	var grounded := false
	var walled := false
	if v.x != 0.0:
		p.x += v.x * dt
		var l := _axis_limit(p, hw, h, 0, v.x)
		if not is_nan(l):
			p.x = l
			v.x = 0.0
			walled = true
	if v.z != 0.0:
		p.z += v.z * dt
		var l := _axis_limit(p, hw, h, 2, v.z)
		if not is_nan(l):
			p.z = l
			v.z = 0.0
			walled = true
	if v.y != 0.0:
		p.y += v.y * dt
		var l := _axis_limit(p, hw, h, 1, v.y)
		if not is_nan(l):
			if v.y < 0.0:
				grounded = true
			p.y = l
			v.y = 0.0
	return {"pos": p, "vel": v, "grounded": grounded, "walled": walled}


func _axis_limit(p: Vector3, hw: float, h: float, axis: int, d: float) -> float:
	var x0 := floori(p.x - hw)
	var x1 := floori(p.x + hw - 0.0001)
	var y0 := floori(p.y)
	var y1 := floori(p.y + h - 0.0001)
	var z0 := floori(p.z - hw)
	var z1 := floori(p.z + hw - 0.0001)
	var best := NAN
	for bx in range(x0, x1 + 1):
		for by in range(y0, y1 + 1):
			for bz in range(z0, z1 + 1):
				if not is_solid(bx, by, bz):
					continue
				var v: float
				if axis == 0:
					v = (bx - hw - 0.001) if d > 0.0 else (bx + 1.0 + hw + 0.001)
				elif axis == 1:
					v = (by - h - 0.001) if d > 0.0 else (by + 1.001)
				else:
					v = (bz - hw - 0.001) if d > 0.0 else (bz + 1.0 + hw + 0.001)
				if is_nan(best):
					best = v
				elif d > 0.0:
					best = minf(best, v)
				else:
					best = maxf(best, v)
	return best
