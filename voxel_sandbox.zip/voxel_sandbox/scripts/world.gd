class_name World
extends Node3D
## Chunk streaming. Terrain generation and meshing run on WorkerThreadPool; the main
## thread only creates MeshInstance3D nodes (max 2 per frame).
## Collision is done directly against the voxel grid (see move_box) - no physics
## bodies or collision shapes are created, which is the cheapest option possible.

const CS := 16
const CH := 64

const WATER_SHADER := """
shader_type spatial;
render_mode blend_mix, cull_back;
uniform sampler2D atlas : source_color, filter_nearest;
uniform float alpha = 0.6;
void vertex() {
	if (NORMAL.y > 0.5) {
		vec3 w = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
		VERTEX.y += sin(TIME * 1.7 + w.x * 1.1 + w.z * 0.8) * 0.025;
	}
}
void fragment() {
	vec4 t = texture(atlas, UV);
	ALBEDO = t.rgb * COLOR.rgb;
	ALPHA = alpha;
	ROUGHNESS = 0.2;
	METALLIC = 0.0;
	SPECULAR = 0.5;
}
"""

var seed_value := 0
var view_radius := 4
var focus := Vector3.ZERO

var chunks: Dictionary = {}   # Vector2i -> Chunk
var edits: Dictionary = {}    # Vector2i -> Dictionary(index:int -> block:int)
var edit_queue: Array[Vector2i] = []
var offsets: Array[Vector2i] = []
var mesh_limit := 17
var data_limit := 26

var opaque_mat: StandardMaterial3D
var water_mat: ShaderMaterial

var max_tasks := 2
var _mutex := Mutex.new()
var _results: Array = []
var _ready_meshes: Array = []
var _tasks: Array[int] = []
var _solid_fill := PackedByteArray()
var _center := Vector2i(1000000, 1000000)


func setup(sd: int, saved_edits: Dictionary, radius: int) -> void:
	seed_value = sd
	edits = saved_edits
	max_tasks = clampi(OS.get_processor_count() / 2, 1, 3)
	_solid_fill.resize(CS * CH * CS)
	_solid_fill.fill(Blocks.STONE)
	_make_materials()
	set_view_radius(radius)


func _exit_tree() -> void:
	for id in _tasks:
		WorkerThreadPool.wait_for_task_completion(id)


func set_view_radius(r: int) -> void:
	r = clampi(r, 2, 8)
	view_radius = r
	mesh_limit = r * r + 1
	data_limit = r * r + 2 * r + 3
	offsets.clear()
	var lim := r + 2
	for dz in range(-lim, lim + 1):
		for dx in range(-lim, lim + 1):
			if dx * dx + dz * dz <= data_limit:
				offsets.append(Vector2i(dx, dz))
	offsets.sort_custom(func(a: Vector2i, b: Vector2i) -> bool: return a.length_squared() < b.length_squared())
	_center = Vector2i(1000000, 1000000)


func _make_materials() -> void:
	opaque_mat = StandardMaterial3D.new()
	opaque_mat.albedo_texture = Atlas.texture
	opaque_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	opaque_mat.vertex_color_use_as_albedo = true
	opaque_mat.roughness = 1.0
	opaque_mat.metallic_specular = 0.0
	opaque_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	opaque_mat.alpha_scissor_threshold = 0.5
	var sh := Shader.new()
	sh.code = WATER_SHADER
	water_mat = ShaderMaterial.new()
	water_mat.shader = sh
	water_mat.set_shader_parameter("atlas", Atlas.texture)


# ------------------------------------------------------------------ streaming

func _process(_delta: float) -> void:
	_collect_results()
	_clean_tasks()
	var c := Vector2i(floori(focus.x) >> 4, floori(focus.z) >> 4)
	if c != _center:
		_center = c
		_unload_far()
	_schedule()
	_apply_pending_meshes(2)


func _unload_far() -> void:
	var lim := data_limit + 8
	var gone: Array[Vector2i] = []
	for key in chunks:
		var k: Vector2i = key
		if (k - _center).length_squared() > lim:
			gone.append(k)
	for k in gone:
		var ch: Chunk = chunks[k]
		ch.free_nodes()
		chunks.erase(k)


func _schedule() -> void:
	_mutex.lock()
	var queued := _results.size() + _ready_meshes.size()
	_mutex.unlock()
	if _tasks.size() >= max_tasks or queued > 10:
		return
	# Edited chunks first so digging feels responsive.
	while not edit_queue.is_empty() and _tasks.size() < max_tasks:
		var ek: Vector2i = edit_queue.pop_front()
		var ech: Chunk = chunks.get(ek)
		if ech != null and ech.has_data and ech.dirty and not ech.mesh_pending:
			_start_mesh(ech)
	for off in offsets:
		if _tasks.size() >= max_tasks:
			break
		var k := _center + off
		var ch: Chunk = chunks.get(k)
		if ch == null:
			ch = Chunk.new(k)
			chunks[k] = ch
			_start_gen(ch)
		elif ch.has_data and (not ch.meshed or ch.dirty) and not ch.mesh_pending \
				and off.length_squared() <= mesh_limit and _neighbors_have_data(k):
			_start_mesh(ch)


func _neighbors_have_data(k: Vector2i) -> bool:
	for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		var n: Chunk = chunks.get(k + d)
		if n == null or not n.has_data:
			return false
	return true


func _start_gen(ch: Chunk) -> void:
	ch.gen_pending = true
	var ed: Dictionary = {}
	if edits.has(ch.pos):
		ed = (edits[ch.pos] as Dictionary).duplicate()
	_tasks.append(WorkerThreadPool.add_task(_gen_job.bind(ch, ch.pos.x, ch.pos.y, seed_value, ed)))


func _start_mesh(ch: Chunk) -> void:
	ch.mesh_pending = true
	ch.dirty = false
	var p := ch.pos
	_tasks.append(WorkerThreadPool.add_task(_mesh_job.bind(ch, p, ch.blocks.duplicate(),
			_nb(p + Vector2i(-1, 0)), _nb(p + Vector2i(1, 0)),
			_nb(p + Vector2i(0, -1)), _nb(p + Vector2i(0, 1)))))


func _nb(k: Vector2i) -> PackedByteArray:
	var c: Chunk = chunks.get(k)
	if c != null and c.has_data:
		return c.blocks.duplicate()
	return _solid_fill


# These two run on worker threads: they must not touch the scene tree.
func _gen_job(ch: Chunk, cx: int, cz: int, sd: int, ed: Dictionary) -> void:
	var data := TerrainGen.generate(cx, cz, sd, ed)
	_mutex.lock()
	_results.append({"t": 0, "ch": ch, "pos": Vector2i(cx, cz), "blocks": data})
	_mutex.unlock()


func _mesh_job(ch: Chunk, p: Vector2i, b: PackedByteArray, nx: PackedByteArray, px: PackedByteArray,
		nz: PackedByteArray, pz: PackedByteArray) -> void:
	var m := Mesher.build(b, nx, px, nz, pz)
	_mutex.lock()
	_results.append({"t": 1, "ch": ch, "pos": p, "mesh": m})
	_mutex.unlock()


func _clean_tasks() -> void:
	var i := 0
	while i < _tasks.size():
		if WorkerThreadPool.is_task_completed(_tasks[i]):
			WorkerThreadPool.wait_for_task_completion(_tasks[i])
			_tasks.remove_at(i)
		else:
			i += 1


func _collect_results() -> void:
	_mutex.lock()
	var batch := _results
	_results = []
	_mutex.unlock()
	for r in batch:
		var rd: Dictionary = r
		var k: Vector2i = rd["pos"]
		var ch: Chunk = chunks.get(k)
		# Drop results of chunks that were unloaded (or unloaded and re-created) meanwhile.
		if ch == null or ch != rd["ch"]:
			continue
		if int(rd["t"]) == 0:
			ch.blocks = rd["blocks"]
			ch.has_data = true
			ch.gen_pending = false
		else:
			ch.mesh_pending = false
			_ready_meshes.append({"ch": ch, "mesh": rd["mesh"]})


func _apply_pending_meshes(max_n: int) -> void:
	var n := 0
	while n < max_n and not _ready_meshes.is_empty():
		var it: Dictionary = _ready_meshes.pop_front()
		var ch: Chunk = it["ch"]
		if chunks.get(ch.pos) != ch:
			continue
		var m: Dictionary = it["mesh"]
		_set_inst(ch, false, m["o"])
		_set_inst(ch, true, m["w"])
		ch.meshed = true
		n += 1


func _set_inst(ch: Chunk, is_water: bool, arrays: Array) -> void:
	var inst: MeshInstance3D = ch.winst if is_water else ch.inst
	if arrays.is_empty():
		if inst != null:
			inst.queue_free()
		if is_water:
			ch.winst = null
		else:
			ch.inst = null
		return
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mesh.surface_set_material(0, water_mat if is_water else opaque_mat)
	if inst == null:
		inst = MeshInstance3D.new()
		inst.position = Vector3(ch.pos.x * CS, 0, ch.pos.y * CS)
		if is_water:
			inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(inst)
		if is_water:
			ch.winst = inst
		else:
			ch.inst = inst
	inst.mesh = mesh


## 0..1: fraction of chunks around `pos` that are meshed (used by the loading screen).
func ready_progress(pos: Vector3, r: int) -> float:
	var cx := floori(pos.x) >> 4
	var cz := floori(pos.z) >> 4
	var total := 0
	var done := 0
	for dz in range(-r, r + 1):
		for dx in range(-r, r + 1):
			# Chunks outside mesh_limit are never meshed (small view distance) - don't wait for them.
			if dx * dx + dz * dz > mesh_limit:
				continue
			total += 1
			var ch: Chunk = chunks.get(Vector2i(cx + dx, cz + dz))
			if ch != null and ch.meshed:
				done += 1
	if total == 0:
		return 1.0
	return float(done) / float(total)


# ------------------------------------------------------------------ block access

## Block id, or -1 if that chunk is not loaded.
func get_block(x: int, y: int, z: int) -> int:
	if y < 0:
		return Blocks.BEDROCK
	if y >= CH:
		return 0
	var ch: Chunk = chunks.get(Vector2i(x >> 4, z >> 4))
	if ch == null or not ch.has_data:
		return -1
	return ch.blocks[(y * 16 + (z & 15)) * 16 + (x & 15)]


## Solid for collision. Unloaded chunks count as solid so nobody falls into the void.
func is_solid(x: int, y: int, z: int) -> bool:
	var b := get_block(x, y, z)
	return b == -1 or (b != Blocks.AIR and b != Blocks.WATER)


func set_block(x: int, y: int, z: int, id: int) -> bool:
	if y < 0 or y >= CH:
		return false
	var key := Vector2i(x >> 4, z >> 4)
	var ch: Chunk = chunks.get(key)
	if ch == null or not ch.has_data:
		return false
	var lx := x & 15
	var lz := z & 15
	var idx := (y * 16 + lz) * 16 + lx
	ch.blocks[idx] = id
	var e: Dictionary = edits.get(key, {})
	e[idx] = id
	edits[key] = e
	_mark_dirty(key)
	if lx == 0:
		_mark_dirty(key + Vector2i(-1, 0))
	elif lx == 15:
		_mark_dirty(key + Vector2i(1, 0))
	if lz == 0:
		_mark_dirty(key + Vector2i(0, -1))
	elif lz == 15:
		_mark_dirty(key + Vector2i(0, 1))
	return true


func _mark_dirty(k: Vector2i) -> void:
	var ch: Chunk = chunks.get(k)
	if ch != null and ch.has_data:
		ch.dirty = true
		if not edit_queue.has(k):
			edit_queue.append(k)


## Y of the highest non-air block in a column, -1 if unloaded or the top is water.
func top_y(x: int, z: int) -> int:
	for y in range(CH - 1, -1, -1):
		var b := get_block(x, y, z)
		if b == -1:
			return -1
		if b == Blocks.WATER:
			return -1
		if b != Blocks.AIR:
			return y
	return -1


## Voxel DDA ray. Skips air and water. Returns {hit, pos, normal, id}.
func raycast(origin: Vector3, dir: Vector3, max_dist: float) -> Dictionary:
	var x := floori(origin.x)
	var y := floori(origin.y)
	var z := floori(origin.z)
	var sx := 1 if dir.x > 0.0 else -1
	var sy := 1 if dir.y > 0.0 else -1
	var sz := 1 if dir.z > 0.0 else -1
	var dx := absf(1.0 / dir.x) if dir.x != 0.0 else INF
	var dy := absf(1.0 / dir.y) if dir.y != 0.0 else INF
	var dz := absf(1.0 / dir.z) if dir.z != 0.0 else INF
	var tx := INF
	var ty := INF
	var tz := INF
	if dir.x > 0.0:
		tx = (x + 1 - origin.x) / dir.x
	elif dir.x < 0.0:
		tx = (origin.x - x) / -dir.x
	if dir.y > 0.0:
		ty = (y + 1 - origin.y) / dir.y
	elif dir.y < 0.0:
		ty = (origin.y - y) / -dir.y
	if dir.z > 0.0:
		tz = (z + 1 - origin.z) / dir.z
	elif dir.z < 0.0:
		tz = (origin.z - z) / -dir.z
	var normal := Vector3i.ZERO
	var t := 0.0
	while t <= max_dist:
		var b := get_block(x, y, z)
		if b > 0 and b != Blocks.WATER:
			return {"hit": true, "pos": Vector3i(x, y, z), "normal": normal, "id": b}
		if tx < ty and tx < tz:
			x += sx
			t = tx
			tx += dx
			normal = Vector3i(-sx, 0, 0)
		elif ty < tz:
			y += sy
			t = ty
			ty += dy
			normal = Vector3i(0, -sy, 0)
		else:
			z += sz
			t = tz
			tz += dz
			normal = Vector3i(0, 0, -sz)
	return {"hit": false}


# ------------------------------------------------------------------ collision

## Moves an axis-aligned box (feet position `pos`, half width `hw`, height `h`)
## through the voxel grid. Returns {pos, vel, grounded, walled}.
func move_box(pos: Vector3, vel: Vector3, hw: float, h: float, dt: float) -> Dictionary:
	var p := pos
	var v := vel
	var grounded := false
	var walled := false
	if v.x != 0.0:
		p.x += v.x * dt
		var l := _axis_limit(p, hw, h, 0, v.x)
		if not is_nan(l):
			p.x = l
			v.x = 0.0
			walled = true
	if v.z != 0.0:
		p.z += v.z * dt
		var l := _axis_limit(p, hw, h, 2, v.z)
		if not is_nan(l):
			p.z = l
			v.z = 0.0
			walled = true
	if v.y != 0.0:
		p.y += v.y * dt
		var l := _axis_limit(p, hw, h, 1, v.y)
		if not is_nan(l):
			if v.y < 0.0:
				grounded = true
			p.y = l
			v.y = 0.0
	return {"pos": p, "vel": v, "grounded": grounded, "walled": walled}


func _axis_limit(p: Vector3, hw: float, h: float, axis: int, d: float) -> float:
	var x0 := floori(p.x - hw)
	var x1 := floori(p.x + hw - 0.0001)
	var y0 := floori(p.y)
	var y1 := floori(p.y + h - 0.0001)
	var z0 := floori(p.z - hw)
	var z1 := floori(p.z + hw - 0.0001)
	var best := NAN
	for bx in range(x0, x1 + 1):
		for by in range(y0, y1 + 1):
			for bz in range(z0, z1 + 1):
				if not is_solid(bx, by, bz):
					continue
				var v: float
				if axis == 0:
					v = (bx - hw - 0.001) if d > 0.0 else (bx + 1.0 + hw + 0.001)
				elif axis == 1:
					v = (by - h - 0.001) if d > 0.0 else (by + 1.001)
				else:
					v = (bz - hw - 0.001) if d > 0.0 else (bz + 1.0 + hw + 0.001)
				if is_nan(best):
					best = v
				elif d > 0.0:
					best = minf(best, v)
				else:
					best = maxf(best, v)
	return best
