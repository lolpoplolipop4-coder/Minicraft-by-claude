#!/usr/bin/env bash
# Local build:  tools/build_android.sh debug|release
# Requires: Godot 4.3 + export templates, JDK 17, Android SDK (see README).
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT="${GODOT:-godot}"
MODE="${1:-debug}"
mkdir -p build

validate_project() {
  local log_file
  log_file="$(mktemp)"
  # Do not ignore parse/import failures: exporting a broken project produces an APK
  # that may only show the boot splash / blue clear color on-device.
  "$GODOT" --headless --path "$PWD" --editor --quit 2>&1 | tee "$log_file"
  if grep -Eiq "(SCRIPT ERROR|Parse Error|Failed to load script|Failed loading resource)" "$log_file"; then
    echo "Godot reported a script/resource loading error; refusing to export APK." >&2
    rm -f "$log_file"
    return 1
  fi
  rm -f "$log_file"
}

if [ "$MODE" = "debug" ]; then
  KS="${GODOT_ANDROID_KEYSTORE_DEBUG_PATH:-$HOME/.android/debug.keystore}"
  if [ ! -f "$KS" ]; then
    mkdir -p "$(dirname "$KS")"
    keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore "$KS" \
      -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
  fi
  export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="$KS"
  export GODOT_ANDROID_KEYSTORE_DEBUG_USER="${GODOT_ANDROID_KEYSTORE_DEBUG_USER:-androiddebugkey}"
  export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD="${GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD:-android}"
  validate_project
  "$GODOT" --headless --export-debug "Android" build/VoxelSandbox-debug.apk
  echo "Built: build/VoxelSandbox-debug.apk"
elif [ "$MODE" = "release" ]; then
  : "${GODOT_ANDROID_KEYSTORE_RELEASE_PATH:?set GODOT_ANDROID_KEYSTORE_RELEASE_PATH to your .keystore}"
  : "${GODOT_ANDROID_KEYSTORE_RELEASE_USER:?set GODOT_ANDROID_KEYSTORE_RELEASE_USER (key alias)}"
  : "${GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD:?set GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD}"
  validate_project
  "$GODOT" --headless --export-release "Android" build/VoxelSandbox-release.apk
  echo "Built: build/VoxelSandbox-release.apk"
else
  echo "usage: $0 debug|release"; exit 1
fi
