from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "scripts/main.gd").read_text()
ui = (ROOT / "scripts/inventory_ui.gd").read_text()
inv = (ROOT / "scripts/inventory.gd").read_text()

checks = {
    "chest storage uses independent Inventory instances": "current_chest_inventory = Inventory.new()" in main,
    "chest data loaded from world save": 'start_data.get("chests", {})' in main,
    "chest data written to world save": '"chests": opened_chests' in main,
    "loot is added to chest inventory, not player inventory": "current_chest_inventory.add(Items.STICK" in main and "inv.add(Items.STICK" not in main,
    "chest UI presents 27 storage slots": "for i in 27:" in ui and "_chest_rects" in ui,
    "player and chest slots support transfer": "chest_inv.move(_picked - 100, i)" in ui and "inv.move(_picked, i)" in ui,
    "closing chest commits its contents": "if closing_chest:" in main and "_save()" in main,
    "inventory serialization persists slot ids and counts": '"ids": ids.duplicate(), "counts": counts.duplicate()' in inv,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " " + label)
assert all(checks.values())
print(f"All {len(checks)} chest integration checks passed.")
