#!/usr/bin/env python3
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
blocks = (ROOT / "scripts/blocks.gd").read_text()
player = (ROOT / "scripts/player.gd").read_text()
world = (ROOT / "scripts/world.gd").read_text()
items = (ROOT / "scripts/items.gd").read_text()
checks = {
    "farmland and crop IDs": all(x in blocks for x in ["FARMLAND := 33", "FARMLAND_WET := 34", "WHEAT_MATURE := 39"]),
    "seed, wheat and bread item definitions": all(x in items for x in ["SEEDS := 210", "WHEAT := 211", "BREAD := 212", "Wheat Seeds", "return \"Bread\""]),
    "shovel tilling": "Items.tool_kind(held) == 2" in player and "Blocks.FARMLAND" in player,
    "seed planting": "inv.consume_held()" in player and "Blocks.WHEAT_SEEDLING" in player,
    "mature crop harvest": "Blocks.WHEAT_MATURE" in player and "Items.WHEAT" in player,
    "growth persisted via set_block": "set_block(wx, y, wz, id + 1)" in world,
    "water irrigation": "_farm_has_water" in player and "Blocks.FARMLAND_WET" in player,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " - " + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f"{len(checks)} farming integration checks passed")
