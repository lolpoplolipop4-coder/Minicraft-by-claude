#!/usr/bin/env python3
"""Generates icon.png (192x192) and splash.png. Original art, pure Pillow."""
import random
from PIL import Image, ImageDraw, ImageFont

random.seed(7)

def shade(c, k, n=0.0):
    return tuple(max(0, min(255, int(v * k + random.uniform(-n, n)))) for v in c)

def cube(grid=32):
    """Isometric grass block drawn from explicit polygons on a 32x32 pixel canvas."""
    top = [(16, 3), (29, 9), (16, 15), (3, 9)]
    left = [(3, 9), (16, 15), (16, 29), (3, 23)]
    right = [(16, 15), (29, 9), (29, 23), (16, 29)]
    img = Image.new("RGBA", (grid, grid), (0, 0, 0, 0))
    grass, dirt = (96, 168, 64), (122, 86, 54)

    def mask(poly):
        m = Image.new("L", (grid, grid), 0)
        ImageDraw.Draw(m).polygon(poly, fill=255)
        return m

    mt, ml, mr = mask(top), mask(left), mask(right)
    px = img.load()
    for y in range(grid):
        for x in range(grid):
            if mt.getpixel((x, y)):
                px[x, y] = shade(grass, 1.0, 14) + (255,)
            elif ml.getpixel((x, y)) or mr.getpixel((x, y)):
                is_left = bool(ml.getpixel((x, y)))
                # grass fringe follows the top edge of each side face
                edge_y = 9 + (x - 3) * 6 / 13 if is_left else 15 - (x - 16) * 6 / 13
                base = grass if y - edge_y < 3.2 else dirt
                px[x, y] = shade(base, 0.80 if is_left else 0.60, 8) + (255,)
    return img

def icon():
    S = 192
    bg = Image.new("RGBA", (S, S), (22, 30, 48, 255))
    d = ImageDraw.Draw(bg)
    for y in range(S):  # sky gradient
        t = y / S
        d.line([(0, y), (S, y)], fill=(int(40 + 60 * t), int(80 + 70 * t), int(150 + 50 * t), 255))
    c = cube(32).resize((144, 144), Image.NEAREST)
    bg.alpha_composite(c, (24, 28))
    bg.save("icon.png")

def splash():
    W, H = 960, 540
    img = Image.new("RGBA", (W, H), (17, 22, 34, 255))
    c = cube(32).resize((256, 256), Image.NEAREST)
    img.alpha_composite(c, (W // 2 - 128, 60))
    d = ImageDraw.Draw(img)
    try:
        f = ImageFont.load_default(size=56)
        f2 = ImageFont.load_default(size=24)
    except TypeError:
        f = f2 = ImageFont.load_default()
    t = "VOXEL SANDBOX"
    tw = d.textlength(t, font=f)
    d.text(((W - tw) / 2, 340), t, font=f, fill=(140, 230, 115, 255))
    t2 = "Mine. Build. Survive."
    tw2 = d.textlength(t2, font=f2)
    d.text(((W - tw2) / 2, 420), t2, font=f2, fill=(200, 210, 225, 255))
    img.save("splash.png")

if __name__ == "__main__":
    icon()
    splash()
    print("wrote icon.png, splash.png")
