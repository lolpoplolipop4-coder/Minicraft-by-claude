#!/usr/bin/env python3
"""Static checks that run WITHOUT Godot. They cannot replace opening the project in
Godot, but they catch the most common authoring mistakes:

  1. GDScript indentation (tabs only) and bracket/quote balance
  2. Mesher geometry: face winding is clockwise (Godot front face) and matches the
     normal, UV corners follow the vertex order
  3. Block/item tables have consistent sizes; atlas pixel patterns are 8x8
  4. Every referenced class_name exists
  5. Every res:// path in project/export/scene files exists
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, "scripts")
errors = []
notes = []


def err(msg):
    errors.append(msg)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


# ---------------------------------------------------------------- 1. syntax-ish
def strip_strings_comments(src):
    """Remove comments, string literals (incl. triple-quoted) so brackets can be counted."""
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if src.startswith('"""', i):
            j = src.find('"""', i + 3)
            i = n if j < 0 else j + 3
            out.append('""')
        elif c in "\"'":
            j = i + 1
            while j < n and src[j] != c:
                if src[j] == "\\":
                    j += 1
                if src[j] == "\n":
                    break
                j += 1
            i = j + 1
            out.append('""')
        elif c == "#":
            while i < n and src[i] != "\n":
                i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


gd_files = sorted(f for f in os.listdir(SCRIPTS) if f.endswith(".gd"))
class_names = {}
for f in gd_files:
    src = read(os.path.join(SCRIPTS, f))
    m = re.search(r"^class_name\s+(\w+)", src, re.M)
    if m:
        class_names[m.group(1)] = f
    for ln, line in enumerate(src.split("\n"), 1):
        if line.startswith(" ") and line.strip() and not line.strip().startswith("#"):
            # continuation lines inside brackets are allowed to start with spaces only if
            # inside a multi-line literal; we never do that, so flag it.
            err(f"{f}:{ln}: line starts with spaces (use tabs)")
        if "\t " in line.lstrip("\t")[:0] + line[: len(line) - len(line.lstrip("\t"))]:
            err(f"{f}:{ln}: mixed tabs/spaces in indentation")
    clean = strip_strings_comments(src)
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    for ln, line in enumerate(clean.split("\n"), 1):
        for ch in line:
            if ch in "([{":
                stack.append((ch, ln))
            elif ch in ")]}":
                if not stack or stack[-1][0] != pairs[ch]:
                    err(f"{f}:{ln}: unbalanced '{ch}'")
                    stack = []
                    break
                stack.pop()
    if stack:
        err(f"{f}: unclosed '{stack[-1][0]}' opened on line {stack[-1][1]}")
    # a func/if/for/while/else/elif/match line must end with ':' (ignoring lambdas on one line)
    for ln, line in enumerate(clean.split("\n"), 1):
        s = line.strip()
        if re.match(r"^(if|elif|else|for|while|match)\b", s) and "func(" not in s:
            if not s.endswith(":") and not s.endswith("\\") and not s.endswith(",") and not s.endswith("(") \
                    and not re.search(r"\band$|\bor$", s):
                # allow multi-line conditions: next line continues; only flag clearly broken ones
                if not s.endswith(("and", "or", "not")):
                    notes.append(f"{f}:{ln}: '{s[:50]}' does not end with ':' (multi-line condition?)")

# ---------------------------------------------------------------- 4. class refs
all_src = {f: read(os.path.join(SCRIPTS, f)) for f in gd_files}
builtin_ok = set("""
Vector2 Vector3 Vector2i Vector3i Color Rect2 Basis Transform3D Callable Array Dictionary
String Image ImageTexture Node Node3D Control Camera3D Environment Sky WorldEnvironment
ProceduralSkyMaterial DirectionalLight3D MeshInstance3D BoxMesh QuadMesh ArrayMesh Mesh
StandardMaterial3D ShaderMaterial Shader BaseMaterial3D GeometryInstance3D CPUParticles3D
CanvasLayer CanvasItem Label Button ColorRect CenterContainer VBoxContainer FileAccess DirAccess
ConfigFile OS Input Time Engine ThemeDB DisplayServer WorkerThreadPool Mutex FastNoiseLite
RandomNumberGenerator InputEvent InputEventScreenTouch InputEventScreenDrag InputEventMouseButton
PackedInt32Array PackedByteArray PackedVector3Array PackedVector2Array PackedColorArray
Font Variant AABB Object RefCounted
""".split())
for f, src in all_src.items():
    clean = strip_strings_comments(src)
    for m in re.finditer(r"\b([A-Z][A-Za-z0-9]+)\.(?:new|[a-z_]+\()", clean):
        n = m.group(1)
        if n not in class_names and n not in builtin_ok and not n.isupper():
            notes.append(f"{f}: references '{n}' (not a project class; make sure it is a Godot built-in)")

# ---------------------------------------------------------------- 2. mesher geometry
mesher = all_src["mesher.gd"]


def vecs(block):
    return [tuple(float(v) for v in m) for m in re.findall(r"Vector3\(\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\)", block)]


fv_block = re.search(r"const FACE_V := \[(.*?)\n\]\nconst FACE_N", mesher, re.S).group(1)
fv_all = vecs(fv_block)
faces = [fv_all[i * 4:(i + 1) * 4] for i in range(6)]
fn_block = re.search(r"const FACE_N := \[(.*?)\]\n", mesher, re.S).group(1)
normals = vecs(fn_block)
assert len(faces) == 6 and len(normals) == 6, "face table size"


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


names = ["+X", "-X", "+Y", "-Y", "+Z", "-Z"]
for d in range(6):
    v = faces[d]
    n = normals[d]
    # corners must lie on the plane touching the cube face in the normal direction
    plane = [dot(c, n) for c in v]
    expect = 1.0 if sum(n) > 0 else 0.0
    if any(abs(p - expect) > 1e-9 for p in plane):
        err(f"face {names[d]}: corners not on the outer plane {plane}")
    # emitted triangles: (0,2,1) and (0,3,2). Godot front face = clockwise = cross points AWAY from normal.
    for tri in ((0, 2, 1), (0, 3, 2)):
        a, b, c = (v[i] for i in tri)
        cr = cross(sub(b, a), sub(c, a))
        if dot(cr, n) >= 0:
            err(f"face {names[d]} triangle {tri}: winding is counter-clockwise (would be culled)")
        if abs(abs(dot(cr, n)) - 1.0) > 1e-9:
            err(f"face {names[d]} triangle {tri}: degenerate/wrong area")
    notes.append(f"face {names[d]}: winding OK") if False else None

# UV checks: side faces must have texture-up == world +Y, and not be mirrored.
def parse_uv(name):
    body = re.search(r"const %s := \[(.*?)\]\n" % name, mesher, re.S).group(1)
    pairs = re.findall(r"\[\s*(\d)\s*,\s*(\d)\s*\]", body)
    return [(int(a), int(b)) for a, b in pairs]


uv_side = parse_uv("UV_SIDE")
uv_top = parse_uv("UV_TOP")
uv_bot = parse_uv("UV_BOT")
for nm, t in (("UV_SIDE", uv_side), ("UV_TOP", uv_top), ("UV_BOT", uv_bot)):
    if len(t) != 4 or len(set(t)) != 4:
        err(f"{nm} must list the 4 distinct corners, got {t}")
side_tables = {0: uv_side, 1: uv_side, 4: uv_side, 5: uv_side}
for d, uvs in side_tables.items():
    v = faces[d]
    # tex v increases downward: corners with uv.v==0 must be the ones with y==1
    for c, (u, t) in zip(v, uvs):
        if (t == 0) != (c[1] == 1.0):
            err(f"face {names[d]}: texture is upside down")
    # horizontal mirroring: viewed from outside, u must increase to the viewer's right.
    n = normals[d]
    up = (0.0, 1.0, 0.0)
    forward = tuple(-x for x in n)  # viewer looks against the normal
    right = cross(forward, up)
    for i in range(4):
        for j in range(i + 1, 4):
            du = uvs[j][0] - uvs[i][0]
            dpos = dot(sub(v[j], v[i]), right)
            if du != 0 and (du > 0) != (dpos > 0) and abs(dpos) > 1e-9:
                err(f"face {names[d]}: texture mirrored horizontally")
                break
        else:
            continue
        break

# ---------------------------------------------------------------- 3. tables & patterns
blocks = all_src["blocks.gd"]
count = int(re.search(r"const COUNT := (\d+)", blocks).group(1))
for tname in ("NAMES", "TILE_TOP", "TILE_SIDE", "TILE_BOTTOM", "OPAQUE", "HARDNESS", "PREF_TOOL", "REQ_TIER"):
    body = re.search(r"const %s := \[(.*?)\]\n" % tname, blocks, re.S).group(1)
    n = len([x for x in body.replace("\n", " ").replace("\t", " ").split(",") if x.strip()])
    if n != count:
        err(f"blocks.gd: {tname} has {n} entries, expected {count}")
ids = re.findall(r"^const ([A-Z_]+) := (\d+)", blocks, re.M)
vals = [int(v) for k, v in ids if k != "COUNT"]
if sorted(vals) != list(range(count)):
    err(f"blocks.gd: block ids are not 0..{count-1} without gaps: {sorted(vals)}")
atlas = all_src["atlas.gd"]
for m in re.finditer(r"const (PAT_\w+) := \[(.*?)\]", atlas):
    rows = re.findall(r'"([^"]*)"', m.group(2))
    if len(rows) != 8 or any(len(r) != 8 for r in rows):
        err(f"atlas.gd: {m.group(1)} must be 8 rows of 8 chars, got {[len(r) for r in rows]}")
hud = all_src["hud.gd"]
for m in re.finditer(r"const (HEART|FOOD) := \[(.*?)\]", hud):
    rows = re.findall(r'"([^"]*)"', m.group(2))
    if len({len(r) for r in rows}) != 1:
        err(f"hud.gd: {m.group(1)} rows differ in width")
# tile indices used by tables must be < 256 tiles and < 32 for terrain
for tname in ("TILE_TOP", "TILE_SIDE", "TILE_BOTTOM"):
    body = re.search(r"const %s := \[(.*?)\]\n" % tname, blocks, re.S).group(1)
    for x in body.split(","):
        if x.strip() and not (0 <= int(x) <= 17):
            err(f"blocks.gd: {tname} tile {x} outside terrain tiles 0..17")

# ---------------------------------------------------------------- 5. resource paths
for fname in ("project.godot", "export_presets.cfg", os.path.join("scenes", "main.tscn")):
    txt = read(os.path.join(ROOT, fname))
    for p in re.findall(r'"res://([^"]+)"', txt):
        if not os.path.exists(os.path.join(ROOT, p)):
            err(f"{fname}: missing resource res://{p}")

# ---------------------------------------------------------------- report
print(f"Checked {len(gd_files)} scripts, {len(class_names)} classes.")
for n in notes:
    print("note:", n)
if errors:
    print("\nFAILED:")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("All static checks passed.")
