#!/usr/bin/env python3
"""Static integration checks for lightweight village NPCs; not a Godot runtime test."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / "scripts/main.gd").read_text(encoding="utf-8")
villager = (root / "scripts/villager.gd").read_text(encoding="utf-8")
checks = {
    "villager class uses voxel collision": "world.move_box(position, velocity, HW, BODY_H, dt)" in villager,
    "five villager roles exist": all(x in villager for x in ["ROLE_VILLAGER", "ROLE_FARMER", "ROLE_TRADER", "ROLE_WORKER", "ROLE_GUARD"]),
    "villager health and food": "var hp := 20.0" in villager and "var food := 18.0" in villager,
    "villager carries inventory": "var inventory: Dictionary" in villager,
    "villagers spawned from nearby village candidates": "VillageGen.villages_near" in main and "Villager.new()" in main,
    "villager population bounded": "villagers.size() >= 8" in main,
    "far villagers are despawned": "v.position.distance_to(player.position) > 92.0" in main,
    "night home schedule": "daylight_now < 0.12" in villager,
    "food consumption uses item registry": "Items.food_value(id)" in villager,
    "AI only runs during gameplay": "main.paused" in villager,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " " + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f"All {len(checks)} villager integration checks passed (static only).")
